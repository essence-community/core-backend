"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const pluginmanager_1 = require("../core/pluginmanager");
const property_1 = require("../core/property");
const logger = Logger_1.default.getLogger("SchedulersNode");
class SchedulersNode {
    async start() {
        const dbScheduler = await property_1.default.getSchedulers();
        await pluginmanager_1.default.resetSchedulersClass();
        const confSchedulers = await dbScheduler.find();
        return Promise.all(confSchedulers.map(async (conf) => {
            const pluginClass = pluginmanager_1.default.getGateSchedulerClass(conf.ck_d_plugin.toLowerCase());
            if (pluginClass) {
                const plugin = new pluginClass(conf.ck_id, conf.cct_params, conf.cv_cron, !!conf.cl_enable);
                return plugin.init().then(() => {
                    pluginmanager_1.default.setGateScheduler(conf.ck_id, plugin);
                    return Promise.resolve();
                }, (err) => {
                    logger.error(`Not init scheduler plugin ${conf.ck_id}\n${err.message}`, err);
                    return Promise.resolve();
                });
            }
            return Promise.resolve();
        }));
    }
}
const schedulersNode = new SchedulersNode();
schedulersNode.start().then(() => {
    ProcessSender_1.sendProcess({
        command: "startedSchedulerNode",
        data: {},
        target: "master",
    });
    logger.info("Scheduler node started!");
}, (err) => logger.error(`Scheduler node fail start\n${err.message}`, err));
exports.default = schedulersNode;
