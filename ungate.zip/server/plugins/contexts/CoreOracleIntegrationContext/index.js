"use strict";
const CoreIntegration_1 = require("./CoreIntegration");
module.exports = CoreIntegration_1.default;
