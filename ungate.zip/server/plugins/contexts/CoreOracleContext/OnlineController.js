"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BreakException_1 = require("@ungate/plugininf/lib/errors/BreakException");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const CoreContext_1 = require("./CoreContext");
const OfflineController_1 = require("./OfflineController");
class OnlineController {
    constructor(name, dataSource, params) {
        this.sysSettings = "select s.ck_id, s.cv_value, s.cv_description from s_mt.t_sys_setting s";
        this.dataSource = dataSource;
        this.params = params;
        this.name = name;
        this.controller = new OfflineController_1.default(this.name, this.dataSource, this.params);
    }
    async getSetting(gateContext) {
        const { js } = gateContext.params;
        return new Promise((resolve, reject) => {
            this.dataSource
                .executeStmt(this.sysSettings, null, {}, {}, {
                resultSet: true,
            })
                .then((res) => {
                const data = [
                    {
                        ck_id: "core_gate_version",
                        cv_description: "Версия шлюза",
                        cv_value: gateContext.gateVersion,
                    },
                ];
                res.stream.on("data", (row) => {
                    data.push(row);
                });
                res.stream.on("end", () => {
                    if (js) {
                        const str = "window.SETTINGS = " +
                            JSON.stringify(data) +
                            ";";
                        gateContext.response.writeHead(200, {
                            "content-length": Buffer.byteLength(str),
                            "content-type": "application/javascript",
                        });
                        gateContext.response.end(str);
                        reject(new BreakException_1.default({
                            data: ResultStream_1.default(data
                                .sort(Util_1.sortFilesData(gateContext))
                                .filter(Util_1.filterFilesData(gateContext))),
                            type: "break",
                        }));
                    }
                    else {
                        reject(new BreakException_1.default({
                            data: ResultStream_1.default(data
                                .sort(Util_1.sortFilesData(gateContext))
                                .filter(Util_1.filterFilesData(gateContext))),
                            type: "success",
                        }));
                    }
                });
            });
        });
    }
    handleResult(gateContext, result) {
        return this.controller.handleResult(gateContext, result);
    }
    findModify(gateContext) {
        if (!gateContext.session) {
            return Promise.reject(CoreContext_1.default.accessDenied());
        }
        else if (!gateContext.params.page_object) {
            return Promise.reject(new ErrorException_1.default(-1, 'Not found require param "page_object"'));
        }
        const pageObject = (gateContext.params.page_object || "").toLowerCase();
        const caActions = gateContext.session.data.ca_actions || [];
        return this.controller.onlineFindModify(gateContext, pageObject, caActions);
    }
    findPages(gateContext, ckPage, caActions = []) {
        return this.controller.onlineFindPages(gateContext, ckPage, caActions);
    }
    findQuery(gateContext, name) {
        const caActions = (gateContext.session && gateContext.session.data.ca_actions) || [];
        const pageObject = (gateContext.params.page_object || "").toLowerCase();
        return this.controller.onlineFindQuery(name, pageObject, caActions);
    }
    init(reload) {
        return this.controller.init(reload);
    }
    destroy() {
        return this.controller.destroy();
    }
}
exports.default = OnlineController;
