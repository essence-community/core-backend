"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const postgres_1 = require("@ungate/plugininf/lib/db/postgres");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullContext_1 = require("@ungate/plugininf/lib/NullContext");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const createTempTable = global.createTempTable;
const querySql = "select q.* from t_interface q";
const queryFindSql = "select q.* from t_interface q where lower(q.ck_id) = lower(:ck_query)";
class CoreIntegration extends NullContext_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(CoreIntegration.getParamsInfo(), params);
        if (this.params.disableCache) {
            this.caller = this.onlineInitContext;
        }
        else {
            this.caller = this.offlineInitContext;
        }
        this.dataSource = new postgres_1.default(`${this.name}_context`, {
            connectString: this.params.connectString,
            partRows: this.params.partRows,
            poolMax: this.params.poolMax,
            queryTimeout: this.params.queryTimeout,
        });
    }
    static getParamsInfo() {
        return {
            ...NullContext_1.default.getParamsInfo(),
            ...postgres_1.default.getParamsInfo(),
            disableCache: {
                defaultValue: false,
                name: "Признак отключения кэша",
                type: "boolean",
            },
        };
    }
    async init(reload) {
        if (!this.dbQuery) {
            this.dbQuery = await createTempTable(`tt_core_integration_${this.name}`);
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        return this.loadQuery();
    }
    initContext(gateContext) {
        return this.caller.call(this, gateContext);
    }
    async destroy() {
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
    }
    loadQuery() {
        return this.dataSource
            .executeStmt(querySql, null, {}, {}, {
            resultSet: true,
        })
            .then((res) => {
            return new Promise((resolve, reject) => {
                const data = [];
                res.stream.on("error", (err) => reject(new Error(err.message)));
                res.stream.on("data", (row) => {
                    data.push({
                        ...row,
                        ck_id: row.ck_id.toLowerCase(),
                        cn_action: parseInt(row.cn_action, 10),
                    });
                });
                res.stream.on("end", () => {
                    this.dbQuery.insert(data).then(() => resolve(), (err) => reject(new Error(err.message)));
                });
            });
        });
    }
    async onlineInitContext(gateContext, isSave = false) {
        const res = await this.dataSource.executeStmt(queryFindSql, null, {
            ck_query: gateContext.queryName,
        });
        const resultContext = await new Promise((resolve, reject) => {
            const data = [];
            res.stream.on("error", (err) => reject(new Error(err.message)));
            res.stream.on("data", (row) => {
                data.push({
                    ...row,
                    ck_id: row.ck_id.toLowerCase(),
                    cn_action: parseInt(row.cn_action, 10),
                });
            });
            res.stream.on("end", () => {
                if (isSave) {
                    this.dbQuery.insert(data).then(lodash_1.noop, lodash_1.noop);
                }
                if (data.length) {
                    const row = data[0];
                    const result = {
                        defaultActionName: this.getAction(row.ck_d_interface),
                        metaData: {
                            in_params: {
                                ...gateContext.params,
                                json: gateContext.params.json
                                    ? JSON.parse(gateContext.params.json)
                                    : undefined,
                            },
                        },
                        providerName: row.ck_d_provider,
                        query: {
                            extraOutParams: [
                                {
                                    cv_name: "result",
                                    outType: "DEFAULT",
                                },
                                {
                                    cv_name: "cur_result",
                                    outType: "CURSOR",
                                },
                            ],
                            needSession: row.ck_d_interface !== "auth",
                            queryData: row,
                        },
                    };
                    if (row.ck_d_interface !== "auth" &&
                        gateContext.actionName !== "auth" &&
                        !this.checkAccess(gateContext, row.cn_action)) {
                        return reject(new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED));
                    }
                    return resolve(result);
                }
                return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
            });
        });
        return resultContext;
    }
    async offlineInitContext(gateContext) {
        const row = await this.dbQuery.findOne({
            ck_id: gateContext.queryName,
        }, true);
        if (!row) {
            return this.onlineInitContext(gateContext, true);
        }
        const result = {
            defaultActionName: this.getAction(row.ck_d_interface),
            metaData: {
                in_params: {
                    ...gateContext.params,
                    json: gateContext.params.json
                        ? JSON.parse(gateContext.params.json)
                        : undefined,
                },
            },
            providerName: row.ck_d_provider,
            query: {
                extraOutParams: [
                    { cv_name: "result", outType: "DEFAULT" },
                    { cv_name: "cur_result", outType: "CURSOR" },
                ],
                needSession: row.ck_d_interface !== "auth",
                queryData: row,
            },
        };
        if (row.ck_d_interface !== "auth" &&
            gateContext.actionName !== "auth" &&
            !this.checkAccess(gateContext, row.cn_action)) {
            throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
        }
        return result;
    }
    checkAccess(gateContext, cnAction) {
        if (gateContext.session &&
            gateContext.session.data.ca_actions.includes(cnAction)) {
            return true;
        }
        return false;
    }
    getAction(name) {
        switch (name) {
            case "select":
            case "streamselect":
                return "sql";
            case "dml":
            case "streamdml":
                return "dml";
            case "auth":
                return "auth";
            case "file":
            case "file_download":
                return "file";
            case "upload":
            case "file_upload":
                return "upload";
            default:
                return "sql";
        }
    }
}
exports.default = CoreIntegration;
