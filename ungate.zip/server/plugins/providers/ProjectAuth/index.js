"use strict";
const ProjectTiiAuth_1 = require("./ProjectTiiAuth");
module.exports = ProjectTiiAuth_1.default;
