"use strict";
const ProxyTransparent_1 = require("./ProxyTransparent");
module.exports = ProxyTransparent_1.default;
