"use strict";
const PKOAuth_1 = require("./PKOAuth");
module.exports = PKOAuth_1.default;
