"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("@ungate/plugininf/lib/db/postgres/index");
const BreakException_1 = require("@ungate/plugininf/lib/errors/BreakException");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullProvider_1 = require("@ungate/plugininf/lib/NullProvider");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const request = require("request");
const URL = require("url");
class CoreIntegration extends NullProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = {
            ...this.params,
            ...Util_1.initParams(CoreIntegration.getParamsInfo(), params),
        };
        this.dataSource = new index_1.default(`${this.name}_provider`, {
            connectString: this.params.connectString,
            partRows: this.params.partRows,
            poolMax: this.params.poolMax,
            queryTimeout: this.params.queryTimeout,
        });
    }
    static getParamsInfo() {
        return {
            ...index_1.default.getParamsInfo(),
            ...NullProvider_1.default.getParamsInfo(),
            proxy: {
                name: "Прокси сервер",
                type: "string",
            },
            timeout: {
                name: "Время ожидания внешнего сервиса",
                type: "integer",
            },
        };
    }
    async initContext(context, preQuery) {
        const query = await super.initContext(context, preQuery);
        const conn = await this.dataSource.getConnection();
        try {
            context.connection = conn;
            if (query.queryStr) {
                query.extraOutParams.push({
                    cv_name: "result",
                    outType: "DEFAULT",
                });
                query.extraOutParams.push({
                    cv_name: "cur_result",
                    outType: "CURSOR",
                });
                const inParam = {};
                if (context.session) {
                    inParam.sess_session = context.session.session;
                    Object.keys(context.session.data).forEach((key) => {
                        inParam[`sess_${key}`] = context.session.data[key];
                    });
                }
                return conn
                    .executeStmt(query.queryStr, {
                    ck_query: context.queryName,
                    ...context.params,
                    ...inParam,
                }, {
                    cur_result: "",
                    result: "",
                })
                    .then((res) => new Promise((resolve, reject) => {
                    const data = [];
                    res.stream.on("error", (err) => reject(err));
                    res.stream.on("data", (chunk) => data.push(chunk));
                    res.stream.on("end", () => {
                        if (data.length) {
                            const doc = data[0];
                            query.queryData.querys = data;
                            query.queryStr = doc.cc_request;
                            return resolve(query);
                        }
                        return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                    });
                }));
            }
            return conn
                .executeStmt("with recursive ot_interface as (\n" +
                "select\n" +
                "    i.ck_id,\n" +
                "    i.ck_d_interface,\n" +
                "    i.ck_d_provider,\n" +
                "    i.cc_request,\n" +
                "    i.cc_response,\n" +
                "    i.cn_action,\n" +
                "    i.cv_url_request,\n" +
                "    i.cv_url_response,\n" +
                "    i.cv_description,\n" +
                "    1 as lvl,\n" +
                "    i.ck_parent\n" +
                "from\n" +
                "    s_it.t_interface i\n" +
                "where\n" +
                "    lower(i.ck_id) = lower(:ck_query)\n" +
                "union all\n" +
                "select\n" +
                "    i.ck_id,\n" +
                "    i.ck_d_interface,\n" +
                "    i.ck_d_provider,\n" +
                "    i.cc_request,\n" +
                "    i.cc_response,\n" +
                "    i.cn_action,\n" +
                "    i.cv_url_request,\n" +
                "    i.cv_url_response,\n" +
                "    i.cv_description,\n" +
                "    oi.lvl + 1 as lvl,\n" +
                "    i.ck_parent\n" +
                "from\n" +
                "    s_it.t_interface i\n" +
                "join ot_interface oi on\n" +
                "    oi.ck_id = i.ck_parent )\n" +
                "select\n" +
                "    ck_id,\n" +
                "    ck_d_interface,\n" +
                "    ck_d_provider,\n" +
                "    cc_request,\n" +
                "    cc_response,\n" +
                "    cn_action,\n" +
                "    cv_url_request,\n" +
                "    cv_url_response,\n" +
                "    cv_description,\n" +
                "    ck_parent\n" +
                "from\n" +
                "    ot_interface\n" +
                "order by\n" +
                "    lvl desc\n", {
                ck_query: context.queryName,
            }, {
                cur_result: "",
                result: "",
            })
                .then((res) => new Promise((resolve, reject) => {
                const data = [];
                res.stream.on("error", (err) => reject(err));
                res.stream.on("data", (chunk) => data.push(chunk));
                res.stream.on("end", () => {
                    if (data.length) {
                        const [doc] = data;
                        query.queryData.querys = data;
                        query.queryStr = doc.cc_request;
                        return resolve(query);
                    }
                    return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                });
            }));
        }
        catch (err) {
            await conn.rollbackAndRelease().then(() => Promise.reject(err));
        }
        return query;
    }
    processSql(context, query) {
        return this.sequenceQuery(context, query);
    }
    processDml(context, query) {
        return this.sequenceQuery(context, query);
    }
    sequenceQuery(gateContext, query) {
        return query.queryData.querys
            .slice(1)
            .reduce((current, queryData) => current.then((res) => {
            if (res.res) {
                return Promise.resolve(res);
            }
            return this.processIntegration(gateContext, queryData, {
                resultSet: this.getResultSet(queryData.ck_d_interface),
            }, { ...res.params, ...query.inParams });
        }), this.processIntegration(gateContext, query.queryData.querys[0], {
            resultSet: this.getResultSet(query.queryData.querys[0].ck_d_interface),
        }, query.inParams))
            .then(async (res) => {
            return res.row
                ? { stream: ResultStream_1.default([res.row]) }
                : res.res;
        }, async (err) => {
            gateContext.connection.rollbackAndRelease().then(lodash_1.noop);
            throw err;
        });
    }
    getResultSet(name) {
        switch (name) {
            case "select":
            case "streamselect":
                return true;
            default:
                return false;
        }
    }
    async init(reload) {
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
    }
    async processIntegration(gateContext, queryData, opt, inParams = {}) {
        if (gateContext.isDebugEnabled()) {
            gateContext.debug(`step db cc_request sql: ${queryData.cc_request}` +
                `\ninParam: ${JSON.stringify(inParams)}\noutParam: ${JSON.stringify(gateContext.query.outParams)}`);
        }
        let executeRes = await gateContext.connection.executeStmt(queryData.cc_request, inParams, gateContext.query.outParams, {
            ...opt,
            autoCommit: false,
        });
        let result = await this.checkResult(gateContext, inParams, executeRes, queryData.cv_url_request);
        if (!result.res && queryData.cc_response) {
            const responseInParams = this.prepareParams({
                ...inParams,
                ...result.params,
            });
            if (gateContext.isDebugEnabled()) {
                gateContext.debug(`step db cc_response sql: ${queryData.cc_response}\ninParam: ${JSON.stringify(responseInParams)}` +
                    `\noutParam: ${JSON.stringify(gateContext.query.outParams)}`);
            }
            executeRes = await gateContext.connection.executeStmt(queryData.cc_response, responseInParams, gateContext.query.outParams, {
                ...opt,
                autoCommit: false,
            });
            result = await this.checkResult(gateContext, responseInParams, executeRes, queryData.cv_url_response);
        }
        return result;
    }
    checkResult(gateContext, params, executeRes, url) {
        const result = {
            params,
            res: executeRes,
        };
        const stream = executeRes.stream;
        return new Promise((resolve, reject) => {
            stream.on("error", reject);
            stream.on("readable", onReadable);
            const self = this;
            function onReadable() {
                stream.removeListener("readable", onReadable);
                const chunk = stream.read();
                if (chunk && chunk.result) {
                    self.request(gateContext, chunk, result, url).then((res) => {
                        stream.on("data", lodash_1.noop);
                        resolve(res);
                    }, (err) => {
                        stream.on("data", lodash_1.noop);
                        reject(err);
                    });
                }
                else {
                    if (chunk) {
                        stream.unshift(chunk);
                    }
                    resolve(result);
                }
            }
        });
    }
    async request(gateContext, row, result, url) {
        let param = {};
        try {
            param = JSON.parse(row.result) || {};
        }
        catch (e) {
            gateContext.error(`${row.result}\n${e.message}`, e);
            throw e;
        }
        if (param.cv_error) {
            throw new BreakException_1.default({
                data: ResultStream_1.default([param]),
                type: "success",
            });
        }
        else if (url) {
            return new Promise((resolve, reject) => {
                const urlDB = URL.parse(url);
                const length = Util_2.isEmpty(param.body)
                    ? 0
                    : Buffer.byteLength(param.body);
                const method = param.method
                    ? param.method.toUpperCase()
                    : "POST";
                const headers = Object.assign(method === "GET"
                    ? {}
                    : {
                        "Content-Length": length,
                        "Content-Type": "application/json",
                    }, Util_2.isEmpty(param.headers) ? {} : param.headers);
                const params = {
                    body: param.body,
                    headers,
                    method,
                    timeout: this.params.timeout ? this.params.timeout : 660000,
                    url: URL.format(urlDB),
                };
                if (this.params.proxy) {
                    params.proxy = this.params.proxy;
                }
                if (gateContext.isDebugEnabled()) {
                    gateContext.debug(`step request params: ${JSON.stringify(params)}`);
                }
                request(params, (err, res, bodyResponse) => {
                    if (err) {
                        gateContext.error(`Error query ${gateContext.queryName} request ${this.name} params ${param}`, err);
                        return reject(new ErrorException_1.default(-1, "Ошибка вызова внешнего сервиса"));
                    }
                    if (gateContext.isDebugEnabled()) {
                        gateContext.debug(`step response body: ${bodyResponse}\nheaders: ${JSON.stringify(res.headers)}`);
                    }
                    if (bodyResponse) {
                        return resolve({
                            params: {
                                ...result.params,
                                ...param,
                                headers_response: res.headers,
                                json_response: lodash_1.isObject(bodyResponse)
                                    ? JSON.stringify(bodyResponse)
                                    : bodyResponse,
                            },
                        });
                    }
                });
            });
        }
        return {
            params: {
                ...result.params,
                ...param,
            },
            row,
        };
    }
    prepareParams(params = {}) {
        return Object.entries(params).reduce((obj, arr) => {
            obj[arr[0]] = lodash_1.isObject(arr[1]) ? JSON.stringify(arr[1]) : arr[1];
            return obj;
        }, {});
    }
}
exports.default = CoreIntegration;
