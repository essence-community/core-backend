"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
class Oracle {
    constructor(name, params, dataSource) {
        this.name = name;
        this.params = params;
        this.dataSource = dataSource;
    }
    async init() {
        return;
    }
    async getConnection(context) {
        const conn = await this.dataSource.getConnection();
        return conn;
    }
    processSql(context, query) {
        return context.connection
            .executeStmt(query.queryStr, query.inParams, query.outParams, {
            resultSet: true,
        })
            .catch((err) => {
            if (err && (err.message || "").indexOf("ORA-04061") > -1) {
                return context.connection
                    .rollbackAndClose()
                    .then(async () => {
                    context.connection = await this.getConnection(context);
                    return;
                })
                    .then(() => this.processSql(context, query));
            }
            return Promise.reject(err);
        });
    }
    processDml(context, query) {
        return context.connection
            .executeStmt(query.queryStr, query.inParams, query.outParams)
            .catch((err) => {
            if (err && (err.message || "").indexOf("ORA-04061") > -1) {
                return context.connection
                    .rollbackAndClose()
                    .then(async () => {
                    context.connection = await this.getConnection(context);
                    return;
                })
                    .then(() => this.processDml(context, query));
            }
            return Promise.reject(err);
        });
    }
    async initContext(context, connection, query) {
        if (!query.queryStr && query.modifyMethod !== "_") {
            throw new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY);
        }
        return query;
    }
}
exports.default = Oracle;
