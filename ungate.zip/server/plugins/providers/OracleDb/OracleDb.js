"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const oracle_1 = require("@ungate/plugininf/lib/db/oracle");
const NullProvider_1 = require("@ungate/plugininf/lib/NullProvider");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const moment = require("moment");
const CoreOracle_1 = require("./CoreOracle");
const OldOracle_1 = require("./OldOracle");
const Oracle_1 = require("./Oracle");
class OracleDBPlugin extends NullProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = {
            ...this.params,
            ...Util_1.initParams(OracleDBPlugin.getParamsInfo(), params),
        };
        this.dataSource = new oracle_1.default(`${this.name}_provider`, {
            connectString: this.params.connectString,
            maxRows: this.params.maxRows,
            partRows: this.params.partRows,
            password: this.params.password,
            poolMax: this.params.poolMax,
            poolMin: this.params.poolMin,
            prefetchRows: this.params.prefetchRows,
            queryTimeout: this.params.queryTimeout,
            queueTimeout: this.params.queueTimeout,
            user: this.params.user,
        });
        if (params.core) {
            this.controller = new CoreOracle_1.default(this.name, this.params, this.dataSource);
        }
        else if (params.old) {
            this.controller = new OldOracle_1.default(this.name, this.params, this.dataSource);
        }
        else {
            this.controller = new Oracle_1.default(this.name, this.params, this.dataSource);
        }
    }
    static getParamsInfo() {
        return {
            ...oracle_1.default.getParamsInfo(),
            ...NullProvider_1.default.getParamsInfo(),
            core: {
                defaultValue: false,
                name: "Инициализация согласно проекту Core",
                type: "boolean",
            },
            defaultSchema: {
                description: "Схема по умолчаниюв режиме old",
                name: "Схема по умолчанию в режиме old",
                type: "string",
            },
            old: {
                defaultValue: false,
                name: "Работа по аналогии Java json",
                type: "boolean",
            },
        };
    }
    arrayInParams(array) {
        return {
            dir: this.dataSource.oracledb.BIND_IN,
            val: array,
        };
    }
    dateInParams(value) {
        return Util_2.isEmpty(value)
            ? ""
            : {
                dir: this.dataSource.oracledb.BIND_IN,
                type: this.dataSource.oracledb.DATE,
                val: moment(value).toDate(),
            };
    }
    fileInParams(value) {
        return {
            dir: this.dataSource.oracledb.BIND_IN,
            type: this.dataSource.oracledb.BLOB,
            val: value,
        };
    }
    processSql(context, query) {
        return this.controller.processSql(context, query);
    }
    processDml(context, query) {
        return this.controller.processDml(context, query);
    }
    async init(reload) {
        await this.dataSource.createPool();
        return this.controller.init();
    }
    async initContext(context, query = {}) {
        const res = await super.initContext(context, query);
        context.connection = await this.controller.getConnection(context);
        if (!Util_2.isEmpty(res.modifyMethod) && res.modifyMethod !== "_") {
            res.queryStr =
                "begin\n" +
                    `:result := ${res.modifyMethod}(:sess_ck_id, :sess_session, :json);\n` +
                    "end;";
            return res;
        }
        else if (res.modifyMethod === "_") {
            return res;
        }
        if (!Util_2.isEmpty(query.queryStr)) {
            return res;
        }
        return this.controller.initContext(context, context.connection, res);
    }
    destroy() {
        return this.dataSource.resetPool();
    }
}
exports.default = OracleDBPlugin;
