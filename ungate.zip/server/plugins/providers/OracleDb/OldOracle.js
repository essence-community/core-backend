"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const lodash_1 = require("lodash");
const wsQuerySQL = "select vl_query, kd_type, pr_auth from report.wd_sqlstore where upper(nm_query) = upper(:nm_query)";
class OldOracle {
    constructor(name, params, dataSource) {
        this.name = name;
        this.params = params;
        this.dataSource = dataSource;
    }
    async init() {
        return;
    }
    getConnection(context) {
        return this.dataSource.getConnection();
    }
    async processSql(context, query) {
        const newSchema = query.inParams.schema ||
            this.params.defaultSchema ||
            this.params.user;
        await this.alterSchemaConnection(context, query, newSchema, this.params.user);
        return context.connection
            .executeStmt(query.queryStr, query.inParams, query.outParams, {
            resultSet: true,
        })
            .then(async (res) => {
            await this.alterSchemaConnection(context, query, this.params.user, newSchema);
            return res;
        })
            .catch((err) => {
            if (err && (err.message || "").indexOf("ORA-04061") > -1) {
                return context.connection
                    .rollbackAndClose()
                    .then(async () => {
                    context.connection = await this.getConnection(context);
                    return;
                })
                    .then(() => this.processSql(context, query));
            }
            return Promise.reject(err);
        });
    }
    async processDml(context, query) {
        const newSchema = query.inParams.schema ||
            this.params.defaultSchema ||
            this.params.user;
        await this.alterSchemaConnection(context, query, newSchema, this.params.user);
        return context.connection
            .executeStmt(query.queryStr, query.inParams, query.outParams)
            .then(async (res) => {
            await this.alterSchemaConnection(context, query, this.params.user, newSchema);
            return res;
        })
            .catch((err) => {
            if (err && (err.message || "").indexOf("ORA-04061") > -1) {
                return context.connection
                    .rollbackAndClose()
                    .then(async () => {
                    context.connection = await this.getConnection(context);
                    return;
                })
                    .then(() => this.processDml(context, query));
            }
            return Promise.reject(err);
        });
    }
    async initContext(context, connection, query) {
        if (!query.queryStr) {
            return this.dataSource
                .executeStmt(wsQuerySQL, connection.getCurrentConnection(), {
                query: context.queryName,
            })
                .then((res) => {
                return new Promise((resolve, reject) => {
                    const data = [];
                    res.stream.on("error", (err) => reject(err));
                    res.stream.on("data", (chunk) => data.push(chunk));
                    res.stream.on("end", () => {
                        if (!data.length) {
                            return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                        }
                        resolve({
                            ...query,
                            needSession: !!data[0].pr_auth,
                            queryStr: data[0].vl_query,
                            type: data[0].kd_type,
                        });
                    });
                });
            });
        }
        return query;
    }
    async alterSchemaConnection(context, query, newSchema, oldSchema, force = false) {
        if (this.params.useAlterSchema) {
            if (force || (query.type > 0 && newSchema !== oldSchema)) {
                const sql = `alter session set current_schema = ${newSchema}`;
                return context.connection
                    .executeStmt(sql)
                    .then((res) => {
                    return new Promise((resolve, reject) => {
                        res.stream.on("data", lodash_1.noop);
                        res.stream.on("err", (err) => reject(err));
                        res.stream.on("end", () => resolve());
                    });
                })
                    .catch((err) => {
                    context.error(`Schema alteration failed ${oldSchema} to ${newSchema}`, err);
                    return context.connection
                        .rollback()
                        .then(() => context.connection.close(), () => context.connection.close())
                        .then(() => {
                        context.connection = null;
                        return Promise.reject(new ErrorException_1.default(ErrorGate_1.default.FAILED_ALTER_SCHEMA));
                    })
                        .catch(() => Promise.reject(new ErrorException_1.default(ErrorGate_1.default.FAILED_ALTER_SCHEMA)));
                });
            }
        }
        return;
    }
    checkCurrentSchema(gateContext, schema) {
        return gateContext.connection
            .executeStmt("SELECT SYS_CONTEXT('USERENV','CURRENT_SCHEMA') as schema FROM DUAL")
            .then((res) => {
            return new Promise((resolve, reject) => {
                const rows = [];
                res.stream.on("data", (chunk) => rows.push(chunk));
                res.stream.on("err", (err) => reject(err));
                res.stream.on("end", () => {
                    if (rows.length) {
                        return resolve(rows[0].schema.toLowerCase() === schema);
                    }
                    return resolve(true);
                });
            });
        }, (err) => {
            gateContext.warn("Не удалось проверить схему", err);
            return Promise.reject(err);
        });
    }
}
exports.default = OldOracle;
