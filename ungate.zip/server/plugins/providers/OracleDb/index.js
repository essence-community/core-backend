"use strict";
const OracleDb_1 = require("./OracleDb");
module.exports = OracleDb_1.default;
