"use strict";
const CoreOracleIntegration_1 = require("./CoreOracleIntegration");
module.exports = CoreOracleIntegration_1.default;
