"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BreakException_1 = require("@ungate/plugininf/lib/errors/BreakException");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const lodash_1 = require("lodash");
const IPostgreSQLController_1 = require("./IPostgreSQLController");
const Property = global.property;
const wsQuerySQL = "select cc_query from t_query where upper(ck_id) = upper(:query)";
class CorePG extends IPostgreSQLController_1.default {
    async init() {
        if (!this.dbUsers) {
            this.dbUsers = await Property.getUsers();
        }
        if (!this.dbCache) {
            this.dbCache = await Property.getCache();
        }
    }
    async getConnection(context) {
        const conn = await this.dataSource.getConnection();
        await this.initTempTableSession(context, conn.getCurrentConnection());
        return conn;
    }
    processSql(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams, {
            resultSet: true,
        });
    }
    processDml(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams);
    }
    async initContext(context, query) {
        if (!query.queryStr) {
            return this.dataSource
                .executeStmt(wsQuerySQL, context.connection.getCurrentConnection(), {
                query: context.queryName,
            })
                .then((res) => {
                return new Promise((resolve, reject) => {
                    const data = [];
                    res.stream.on("error", (err) => reject(err));
                    res.stream.on("data", (chunk) => data.push(chunk));
                    res.stream.on("end", () => {
                        if (!data.length) {
                            return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                        }
                        resolve({
                            ...query,
                            queryStr: data[0].cc_query,
                        });
                    });
                });
            });
        }
        return query;
    }
    async initTempTableSession(gateContext, connection) {
        const res = await this.dataSource.executeStmt("select pkg_json_user.f_get_context('hash_user') as hash_user, " +
            "pkg_json_user.f_get_context('hash_user_action') as hash_user_action, " +
            "pkg_json_user.f_get_context('hash_user_department') as hash_user_department", connection);
        return new Promise((resolve, reject) => {
            const data = [];
            res.stream.on("error", (err) => reject(err));
            res.stream.on("data", (chunk) => data.push(chunk));
            res.stream.on("end", () => this.updateSession(gateContext, connection, data).then(() => resolve(), (err) => reject(err)));
        });
    }
    async updateSession(gateContext, connection, data) {
        if (!data.length) {
            throw new ErrorException_1.default(-1, "Нет данных о сессии");
        }
        if (gateContext.isDebugEnabled()) {
            gateContext.debug(`Hash session ${JSON.stringify(data)}`);
        }
        const users = [];
        const userActions = [];
        const userDepartments = [];
        const row = data[0];
        let updateUser = false;
        let updateUserAction = false;
        let updateUserDepartment = false;
        const hashObj = await this.dbCache.findOne({
            ck_id: "hash_user",
        }, true);
        if (hashObj) {
            if (hashObj.hash_user !== row.hash_user) {
                updateUser = true;
                updateUserAction = true;
                updateUserDepartment = true;
            }
            if (hashObj.hash_user_action !== row.hash_user_action) {
                updateUserAction = true;
            }
            if (hashObj.hash_user_department !== row.hash_user_department) {
                updateUserDepartment = true;
            }
        }
        await Promise.all([
            updateUser || updateUserAction || updateUserDepartment
                ? this.dbUsers.find().then(async (usersRows) => {
                    let errRow;
                    const result = usersRows.every((userRow) => {
                        const item = userRow.data;
                        if (!lodash_1.isObject(item)) {
                            gateContext.error(`Bad tt_user data ${userRow}`);
                            errRow = new ErrorException_1.default(-1, "Bad tt_users data");
                            return false;
                        }
                        (item.ca_actions || []).forEach((action) => {
                            userActions.push({
                                ck_user: item.ck_id,
                                cn_action: action,
                            });
                        });
                        (item.ca_department || []).forEach((dep) => {
                            userDepartments.push({
                                ck_department: dep,
                                ck_user: item.ck_id,
                            });
                        });
                        delete item.ca_actions;
                        delete item.ca_department;
                        delete item.ck_dept;
                        delete item.cv_timezone;
                        users.push(item);
                        return true;
                    });
                    if (!result) {
                        throw errRow;
                    }
                    return;
                })
                : Promise.resolve(),
        ]);
        const actions = [];
        if (updateUser) {
            const jsonUser = JSON.stringify(users);
            actions.push(Promise.resolve({
                hashObj: hashObj.hash_user,
                json: jsonUser,
                name: "f_modify_user",
            }));
        }
        if (updateUserAction && userActions.length) {
            const jsonUserAction = JSON.stringify(userActions);
            actions.push(Promise.resolve({
                hashObj: hashObj.hash_user_action,
                json: jsonUserAction,
                name: "f_modify_user_action",
            }));
        }
        if (updateUserDepartment && userDepartments.length) {
            const jsonUserDepartment = JSON.stringify(userDepartments);
            actions.push(Promise.resolve({
                hashObj: hashObj.hash_user_department,
                json: jsonUserDepartment,
                name: "f_modify_user_department",
            }));
        }
        if (actions.length === 0) {
            return;
        }
        return actions
            .slice(1)
            .reduce((current, next) => {
            return current
                .then((obj) => this.executePkgUser(gateContext, connection, obj.name, obj.json, obj.hashObj))
                .then(() => next);
        }, actions[0])
            .then((obj) => this.executePkgUser(gateContext, connection, obj.name, obj.json, obj.hashObj));
    }
    executePkgUser(gateContext, connection, nameFunction, obj, hash) {
        if (gateContext.isDebugEnabled()) {
            gateContext.debug(`New session init ${nameFunction} Hash: ${hash} Data: ${obj}`);
        }
        return this.dataSource
            .executeStmt(`select pkg_json_user.${nameFunction}(:json, :hash) as result`, connection, {
            hash,
            json: obj,
        }, {}, {
            autoCommit: true,
        })
            .then((res) => {
            const rows = [];
            res.stream.on("data", (chunk) => rows.push(chunk));
            return new Promise((resolve, reject) => {
                res.stream.on("error", (err) => reject(err));
                res.stream.on("end", () => {
                    if (rows && rows.length) {
                        try {
                            const result = lodash_1.isObject(rows[0].result)
                                ? rows[0].result
                                : JSON.parse(rows[0].result);
                            if (result.cv_error) {
                                gateContext.error(`Provider ${this.name} Error ${nameFunction}, ${JSON.stringify(result.cv_error)}`);
                                return reject(new BreakException_1.default({
                                    data: ResultStream_1.default([result]),
                                    type: "success",
                                }));
                            }
                        }
                        catch (e) {
                            gateContext.error(`Provider ${this.name} Error ${nameFunction}: ${rows[0]}: ${rows[0].result}`, e);
                            return Promise.reject(e);
                        }
                        return resolve();
                    }
                    reject(new ErrorException_1.default(-1, `Not return result ${nameFunction}`));
                });
            });
        })
            .catch((err) => {
            gateContext.error(`Provider ${this.name} Error ${nameFunction}: ${err.message}\n
                    Hash: ${hash} Data: ${obj}`, err);
            return Promise.reject(err);
        });
    }
}
exports.default = CorePG;
