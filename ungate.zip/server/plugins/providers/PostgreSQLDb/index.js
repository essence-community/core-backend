"use strict";
const PostgreSQLDb_1 = require("./PostgreSQLDb");
module.exports = PostgreSQLDb_1.default;
