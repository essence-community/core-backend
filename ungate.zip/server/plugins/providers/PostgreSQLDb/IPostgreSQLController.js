"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class IPostgreSQLController {
    constructor(name, params, dataSource) {
        this.name = name;
        this.params = params;
        this.dataSource = dataSource;
    }
}
exports.default = IPostgreSQLController;
