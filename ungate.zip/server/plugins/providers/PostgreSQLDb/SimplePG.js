"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const IPostgreSQLController_1 = require("./IPostgreSQLController");
const wsQuerySQL = "select cc_query from t_query where upper(ck_id) = upper(:query)";
class SimplePG extends IPostgreSQLController_1.default {
    async init() {
        return;
    }
    getConnection(context) {
        return this.dataSource.getConnection();
    }
    processSql(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams, {
            resultSet: true,
        });
    }
    processDml(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams);
    }
    async initContext(context, query) {
        if (!query.queryStr && query.modifyMethod !== "_") {
            return this.dataSource
                .executeStmt(wsQuerySQL, context.connection.getCurrentConnection(), {
                query: context.queryName,
            })
                .then((res) => {
                return new Promise((resolve, reject) => {
                    const data = [];
                    res.stream.on("error", (err) => reject(err));
                    res.stream.on("data", (chunk) => data.push(chunk));
                    res.stream.on("end", () => {
                        if (!data.length) {
                            return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                        }
                        resolve({
                            ...query,
                            queryStr: data[0].cc_query,
                        });
                    });
                });
            });
        }
        return query;
    }
}
exports.default = SimplePG;
