"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const index_1 = require("@ungate/plugininf/lib/db/postgres/index");
const NullProvider_1 = require("@ungate/plugininf/lib/NullProvider");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const CorePG_1 = require("./CorePG");
const OldPG_1 = require("./OldPG");
const SimplePG_1 = require("./SimplePG");
class PostgreSQLDb extends NullProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(PostgreSQLDb.getParamsInfo(), params);
        this.dataSource = new index_1.default(`${this.name}_provider`, {
            connectString: this.params.connectString,
            connectionTimeoutMillis: this.params.connectionTimeoutMillis,
            idleTimeoutMillis: this.params.idleTimeoutMillis,
            partRows: this.params.partRows,
            poolMax: this.params.poolMax,
            queryTimeout: this.params.queryTimeout,
        });
        if (params.core) {
            this.controller = new CorePG_1.default(this.name, this.params, this.dataSource);
        }
        else if (params.old) {
            this.controller = new OldPG_1.default(this.name, this.params, this.dataSource);
        }
        else {
            this.controller = new SimplePG_1.default(this.name, this.params, this.dataSource);
        }
    }
    static getParamsInfo() {
        return {
            ...index_1.default.getParamsInfo(),
            ...NullProvider_1.default.getParamsInfo(),
            core: {
                defaultValue: false,
                name: "Инициализация согласно проекту Core",
                type: "boolean",
            },
            old: {
                defaultValue: false,
                name: "Работа по аналогии Java json",
                type: "boolean",
            },
        };
    }
    processSql(context, query) {
        return this.controller.processSql(context, query);
    }
    processDml(context, query) {
        return this.controller.processDml(context, query);
    }
    async init(reload) {
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        return this.controller.init();
    }
    async initContext(context, query) {
        const res = await super.initContext(context, query);
        context.connection = await this.controller.getConnection(context);
        if (!Util_1.isEmpty(res.modifyMethod) && res.modifyMethod !== "_") {
            res.queryStr = `select ${res.modifyMethod}(:sess_ck_id, :sess_session, :json) as result`;
            return res;
        }
        else if (res.modifyMethod === "_") {
            return res;
        }
        if (!Util_1.isEmpty(query.queryStr)) {
            return res;
        }
        return this.controller.initContext(context, res);
    }
}
exports.default = PostgreSQLDb;
