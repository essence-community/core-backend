"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const IPostgreSQLController_1 = require("./IPostgreSQLController");
const wsQuerySQL = "select vl_query, kd_type, pr_auth from report.wd_sqlstore where upper(query) = upper(:query)";
class OldPG extends IPostgreSQLController_1.default {
    async init() {
        return;
    }
    getConnection(context) {
        return this.dataSource.getConnection();
    }
    processSql(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams, {
            resultSet: true,
        });
    }
    processDml(context, query) {
        return context.connection.executeStmt(query.queryStr, query.inParams, query.outParams);
    }
    async initContext(context, query) {
        if (!query.queryStr) {
            return this.dataSource
                .executeStmt(wsQuerySQL, context.connection.getCurrentConnection(), {
                query: context.queryName,
            })
                .then((res) => {
                return new Promise((resolve, reject) => {
                    const data = [];
                    res.stream.on("error", (err) => reject(err));
                    res.stream.on("data", (chunk) => data.push(chunk));
                    res.stream.on("end", () => {
                        if (!data.length) {
                            return reject(new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY));
                        }
                        resolve({
                            ...query,
                            needSession: !!data[0].pr_auth,
                            queryStr: data[0].vl_query,
                            type: data[0].kd_type,
                        });
                    });
                });
            });
        }
        return query;
    }
}
exports.default = OldPG;
