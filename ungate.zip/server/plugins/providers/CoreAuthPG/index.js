"use strict";
const CoreAuthPg_1 = require("./CoreAuthPg");
module.exports = CoreAuthPg_1.default;
