"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const oracle_1 = require("@ungate/plugininf/lib/db/oracle");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullAuthProvider_1 = require("@ungate/plugininf/lib/NullAuthProvider");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const moment = require("moment");
const Property = global.property;
class CoreAuthOracle extends NullAuthProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = {
            ...this.params,
            ...Util_2.initParams(CoreAuthOracle.getParamsInfo(), params),
        };
        this.dataSource = new oracle_1.default(`${this.name}_provider`, {
            connectString: this.params.connectString,
            maxRows: this.params.maxRows,
            partRows: this.params.partRows,
            password: this.params.password,
            poolMax: this.params.poolMax,
            poolMin: this.params.poolMin,
            prefetchRows: this.params.prefetchRows,
            queryTimeout: this.params.queryTimeout,
            queueTimeout: this.params.queueTimeout,
            user: this.params.user,
        });
    }
    static getParamsInfo() {
        return {
            ...NullAuthProvider_1.default.getParamsInfo(),
            ...oracle_1.default.getParamsInfo(),
        };
    }
    arrayInParams(array) {
        return {
            dir: this.dataSource.oracledb.BIND_IN,
            val: array,
        };
    }
    dateInParams(value) {
        return Util_2.isEmpty(value)
            ? ""
            : {
                dir: this.dataSource.oracledb.BIND_IN,
                type: this.dataSource.oracledb.DATE,
                val: moment(value).toDate(),
            };
    }
    fileInParams(value) {
        return {
            dir: this.dataSource.oracledb.BIND_IN,
            type: this.dataSource.oracledb.BLOB,
            val: value,
        };
    }
    getConnection() {
        return this.dataSource.getConnection();
    }
    async processAuth(context, query) {
        const res = await context.connection
            .executeStmt(query.queryStr, query.inParams, query.outParams)
            .catch((err) => {
            if (err && (err.message || "").indexOf("ORA-04061") > -1) {
                return context.connection
                    .rollbackAndClose()
                    .then(async () => {
                    context.connection = await this.getConnection();
                    return;
                })
                    .then(() => this.processDml(context, query));
            }
            return Promise.reject(err);
        });
        const arr = await Util_1.ReadStreamToArray(res.stream);
        if (Util_2.isEmpty(arr)) {
            throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
        }
        return {
            ck_user: arr[0].ck_id,
            data: arr[0],
        };
    }
    async init(reload) {
        if (!this.dbDepartments) {
            this.dbDepartments = await Property.getDepartments();
        }
        if (!this.dbUsers) {
            this.dbUsers = await Property.getUsers();
        }
        await this.dataSource.createPool();
        const users = {};
        return this.dataSource
            .executeStmt("select u.ck_id, u.cv_login, u.cv_name, u.cv_surname, u.cv_patronymic\n" +
            "  from t_user u", null, null, null, {
            resultSet: true,
        })
            .then((resUser) => new Promise((resolve, reject) => {
            resUser.stream.on("error", (err) => reject(err));
            resUser.stream.on("data", (chunk) => {
                users[chunk.ck_id] = {
                    ...chunk,
                    ca_actions: [],
                    cv_timezone: "+03:00",
                };
            });
            resUser.stream.on("end", () => {
                this.dataSource
                    .executeStmt("select ur.ck_user, dra.ck_d_action from t_user_role ur\n" +
                    "  join t_d_role dr on dr.ck_id = ur.ck_d_role\n" +
                    "  join t_d_role_action dra on dra.ck_d_role = dr.ck_id", null, null, null, {
                    resultSet: true,
                })
                    .then((resAction) => new Promise((resolveAction, rejectAction) => {
                    resAction.stream.on("error", (err) => rejectAction(err));
                    resAction.stream.on("data", (val) => {
                        if (users[val.ck_user]) {
                            users[val.ck_user].ca_actions.push(parseInt(val.ck_d_action, 10));
                        }
                    });
                    resAction.stream.on("end", () => {
                        resolveAction();
                    });
                }))
                    .then(() => resolve(users), (err) => reject(err));
            });
        }))
            .then(() => Promise.all(Object.values(users).map((user) => this.authController.addUser(user.ck_id, this.name, user))))
            .then(() => this.authController.updateHashAuth())
            .then(async () => {
            await this.authController.updateUserInfo(this.name);
        });
    }
    async initContext(context, query = {}) {
        const res = await super.initContext(context, query);
        if (Util_2.isEmpty(query.queryStr)) {
            throw new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY);
        }
        if (context.actionName !== "auth") {
            throw new ErrorException_1.default(ErrorGate_1.default.UNSUPPORTED_METHOD);
        }
        context.connection = await this.getConnection();
        return res;
    }
}
exports.default = CoreAuthOracle;
