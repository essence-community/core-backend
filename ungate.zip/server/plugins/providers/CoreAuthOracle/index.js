"use strict";
const CoreAuthOracle_1 = require("./CoreAuthOracle");
module.exports = CoreAuthOracle_1.default;
