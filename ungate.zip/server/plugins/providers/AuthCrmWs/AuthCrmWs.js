"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const CrmWsCaller_1 = require("@ungate/plugininf/lib/caller/CrmWsCaller");
const JsonGateCaller_1 = require("@ungate/plugininf/lib/caller/JsonGateCaller");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullAuthProvider_1 = require("@ungate/plugininf/lib/NullAuthProvider");
const NullProvider_1 = require("@ungate/plugininf/lib/NullProvider");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
class AuthCrmWs extends NullAuthProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = {
            ...this.params,
            ...Util_2.initParams(AuthCrmWs.getParamsInfo(), params),
        };
        this.crmWSCaller = new CrmWsCaller_1.default(this.params);
        this.nsiJsonGateCaller = new JsonGateCaller_1.default({
            jsonGateUrl: this.params.nsiGateUrl,
        });
    }
    static getParamsInfo() {
        return {
            ...CrmWsCaller_1.default.getParamsInfo(),
            ...NullProvider_1.default.getParamsInfo(),
            clAudit: {
                defaultValue: true,
                name: "Признак аудита",
                type: "boolean",
            },
            cnSystem: {
                name: "Ид системы",
                required: true,
                type: "integer",
            },
            nsiGateUrl: {
                name: "Ссылка на гейт NSI",
                type: "string",
            },
            queryAuth: {
                name: "Наименовани запроса проверки авторизации",
                required: true,
                type: "string",
            },
            queryGetCrmUrl: {
                name: "Имя запроса получения ссылки на сувк",
                required: true,
                type: "string",
            },
            queryMetaUsers: {
                name: "Наименование запроса получения мета информации",
                required: true,
                type: "string",
            },
            queryToken: {
                name: "Наименование запроса получения token",
                required: true,
                type: "string",
            },
            queryUsersActions: {
                name: "Наименование запроса получения всех экшенов",
                required: true,
                type: "string",
            },
            queryUsersDepartments: {
                name: "Наименование запроса получения департаментов по юзеру",
                required: true,
                type: "string",
            },
            sessionDuration: {
                defaultValue: 60,
                name: "Время жизни сессии в минутах по умолчанию 60 минут",
                type: "integer",
            },
            urlCrmTemplate: {
                name: "Шаблон ссылки",
                type: "string",
            },
        };
    }
    async processAuth(context, query) {
        try {
            const params = Object.assign({}, query.inParams, {
                cl_audit: +this.params.clAudit,
                cn_system: this.params.cnSystem,
            });
            const result = await this.crmWSCaller.getData(this.params.queryAuth, params);
            if (!result || !result.length) {
                throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
            }
            return {
                ck_user: result[0].cn_user,
            };
        }
        catch (e) {
            context.error("Ошибка вызова внешнего сервиса авторизации", e);
            throw new ErrorException_1.default(ErrorGate_1.default.AUTH_CALL_REMOTE);
        }
    }
    processSql(context, query) {
        return this[query.queryStr](context, query);
    }
    processDml(context, query) {
        return this[query.queryStr](context, query);
    }
    async getCrmUrl(gateContext) {
        const params = {
            cn_user: gateContext.session.ck_id,
        };
        const res = await this.crmWSCaller.getData(this.params.queryToken, params);
        if (!res.length) {
            return {
                stream: ResultStream_1.default([
                    {
                        ck_id: null,
                        cv_error: {
                            513: [],
                        },
                    },
                ]),
            };
        }
        const [obj] = res;
        return {
            stream: ResultStream_1.default([
                {
                    ck_id: null,
                    cv_error: null,
                    cv_url: (this.params.urlCrmTemplate || "").replace(/{([^}]+)}/g, (req, value) => obj[value]),
                },
            ]),
        };
    }
    async getUrlForNsi(gateContext) {
        return this.getNsiUrl(gateContext, false);
    }
    async getUrlForNsiByTable(gateContext) {
        return this.getNsiUrl(gateContext, true);
    }
    async initContext(context, query = {}) {
        const res = await super.initContext(context, query);
        if (context.actionName === "auth") {
            return {
                ...res,
                queryStr: "authCrm",
            };
        }
        switch (context.queryName) {
            case this.params.queryGetCrmUrl.toLowerCase(): {
                return {
                    ...res,
                    queryStr: "getCrmUrl",
                };
            }
            case "geturlfornsi": {
                return {
                    ...res,
                    queryStr: "getUrlForNsi",
                };
            }
            case "geturlfornsibytable": {
                return {
                    ...res,
                    queryStr: "getUrlForNsiByTable",
                };
            }
            default:
                throw new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY);
        }
    }
    async init(reload) {
        await this.crmWSCaller.init();
        const params = {
            cn_system: this.params.cnSystem,
        };
        const users = {};
        const usersArr = await this.crmWSCaller.getData(this.params.queryMetaUsers, params);
        const rows = [];
        if (!usersArr.length) {
            throw new ErrorException_1.default(-1, `Данных о пользователях не вернулось, провайдер: ${this.name}`);
        }
        usersArr.forEach((item) => {
            users[item.ck_id] = {
                ...item,
                ca_actions: [],
                ca_department: [],
            };
        });
        rows.push(this.crmWSCaller
            .getData(this.params.queryUsersActions, params)
            .then((res) => {
            if (res && res.length) {
                res.forEach((item) => {
                    item.cv_actions.split(",").forEach((cnAction) => {
                        if (users[item.ck_user]) {
                            users[item.ck_user].ca_actions.push(parseInt(cnAction, 10));
                        }
                    });
                });
                return Promise.resolve();
            }
            throw new ErrorException_1.default(-1, `Данных о доступах не вернулось, провайдер: ${this.name}`);
        }));
        rows.push(this.crmWSCaller
            .getData(this.params.queryUsersDepartments, params)
            .then((res) => {
            if (res && res.length) {
                res.forEach((item) => {
                    item.cv_departments
                        .split(",")
                        .forEach((ckDepartment) => {
                        if (users[item.ck_user]) {
                            users[item.ck_user].ca_department.push(parseInt(ckDepartment, 10));
                        }
                    });
                });
            }
            return Promise.resolve();
        }));
        return Promise.all(rows)
            .then(() => Promise.all(Object.values(users).map((user) => this.authController.addUser(user.ck_id, this.name, user))))
            .then(() => this.authController.updateHashAuth())
            .then(() => {
            this.authController.updateUserInfo(this.name);
            return Promise.resolve();
        });
    }
    async getNsiUrl(gateContext, isTable = false) {
        if (Util_2.isEmpty(this.params.nsiGateUrl)) {
            throw new ErrorException_1.default(-1, "Require params(nsiGateUrl) not found");
        }
        const json = JSON.parse(gateContext.params.json || "{}");
        const params = {
            cn_user: gateContext.session.ck_id,
        };
        const jsonCaller = await this.nsiJsonGateCaller.callGet(gateContext, "sql", isTable ? "GetUrlDocReqCreate" : "GetUrlDocReqList", isTable
            ? {
                nm_table: json.filter.cv_table,
            }
            : undefined);
        const respData = await Util_1.ReadStreamToArray(jsonCaller.stream);
        if (respData.length) {
            const [urlObj] = respData;
            const resJson = await this.crmWSCaller.getData(this.params.queryToken, params);
            if (resJson.length) {
                const [obj] = resJson;
                return {
                    stream: ResultStream_1.default([
                        {
                            ck_id: null,
                            cv_error: null,
                            cv_url: urlObj.nm_url.replace(/\[token\]/g, obj.cv_token),
                        },
                    ]),
                };
            }
        }
        return {
            stream: ResultStream_1.default([
                {
                    ck_id: null,
                    cv_error: {
                        513: [],
                    },
                },
            ]),
        };
    }
}
exports.default = AuthCrmWs;
