"use strict";
const AuthCrmWs_1 = require("./AuthCrmWs");
module.exports = AuthCrmWs_1.default;
