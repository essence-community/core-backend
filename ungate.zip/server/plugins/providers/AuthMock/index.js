"use strict";
const AuthMock_1 = require("./AuthMock");
module.exports = AuthMock_1.default;
