"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullAuthProvider_1 = require("@ungate/plugininf/lib/NullAuthProvider");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const ActiveDirectory = require("activedirectory");
const lodash_1 = require("lodash");
const BASIC_PATTERN = "Basic";
const PASSWORD_PATTERN_NGINX_GSS = "bogus_auth_gss_passwd";
class AdAuth extends NullAuthProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.mapUserAttr = {};
        this.mapGroupActions = {};
        this.listDefaultActions = [];
        this.params = {
            ...this.params,
            ...Util_1.initParams(AdAuth.getParamsInfo(), params),
        };
        const userAttr = [
            "dn",
            "sAMAccountName",
            "objectSID",
            "mail",
            "sn",
            "givenName",
            "initials",
            "cn",
            "displayName",
            "comment",
            "description",
        ];
        this.params.adMapUserAttr.split(";").forEach((val) => {
            const [bdkey, adkey] = val.split("=");
            this.mapUserAttr[bdkey] = adkey;
            if (!userAttr.includes(adkey)) {
                userAttr.push(adkey);
            }
        });
        if (this.params.adMapGroups) {
            this.params.adMapGroups.split(";").forEach((val) => {
                const [bdkey, adkey] = val.split("=");
                this.mapGroupActions[bdkey] = adkey
                    .split(",")
                    .map((action) => parseInt(action, 10));
            });
        }
        if (this.params.adDefaultAction) {
            this.listDefaultActions = this.params.adDefaultAction
                .split(",")
                .map((val) => parseInt(val, 10));
        }
        this.ad = new ActiveDirectory({
            attributes: {
                user: userAttr,
            },
            baseDN: this.params.adBaseDN,
            password: this.params.adPassword,
            url: this.params.adUrl,
            username: this.params.adLogin,
        });
    }
    static getParamsInfo() {
        return {
            ...NullAuthProvider_1.default.getParamsInfo(),
            adBaseDN: {
                name: "Начальный уровень поиска в ldap",
                type: "string",
            },
            adDefaultAction: {
                description: "Список экшенов которые назначаются любому авторизованому пользователю",
                name: "Список экшенов по умолчанию",
                type: "string",
            },
            adLogin: {
                name: "Логин УЗ доступа к ldap",
                required: true,
                type: "string",
            },
            adMapGroups: {
                description: "Мапинг групп AD c Core Экшенами, Пример: NameGroup=900,200;NameGroup=100,215",
                name: "Мапинг групп и экшенов пользователя",
                required: true,
                type: "string",
            },
            adMapUserAttr: {
                defaultValue: "cv_login=sAMAccountName;cv_name=cn;cv_surname=sn;cv_email=mail;cv_cert=userCertificate",
                description: "Пример: cv_login=sAMAccountName;cv_name=cn;cv_surname=sn;cv_email=email;cv_cert=userCertificate",
                name: "Мапинг атрибутов пользователя",
                required: true,
                type: "string",
            },
            adPassword: {
                name: "Пароль УЗ доступа к ldap",
                required: true,
                type: "password",
            },
            adUrl: {
                description: "Пример: ldap://dc.domain.com",
                name: "Урл к ldap",
                required: true,
                type: "string",
            },
        };
    }
    async afterSession(gateContext, sessionId, session) {
        if (Util_1.isEmpty(session) &&
            gateContext.actionName !== "auth" &&
            gateContext.request.headers.authorization &&
            gateContext.request.headers.authorization.indexOf(BASIC_PATTERN) >
                -1) {
            return new Promise((resolve, reject) => {
                const basic = Buffer.from(gateContext.request.headers.authorization.split(" ")[1], "base64").toString("ascii");
                const [username, password] = basic.split(":");
                if (password === PASSWORD_PATTERN_NGINX_GSS) {
                    this.initSession(resolve, reject, username);
                    return;
                }
                this.ad.authenticate(username, password, (err, isAuth) => {
                    if (err || !isAuth) {
                        this.log.error(err ? err.message : "Invalid password or login");
                        reject(new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED));
                        return;
                    }
                    this.initSession(resolve, reject, username);
                });
            });
        }
        return session;
    }
    async processAuth(context, query) {
        return new Promise((resolve, reject) => {
            this.ad.authenticate(query.inParams.cv_login, query.inParams.cv_password, (err, isAuth) => {
                if (err || !isAuth) {
                    this.log.error(err ? err.message : "Invalid password or login");
                    reject(new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED));
                    return;
                }
                this.initSession(resolve, reject, query.inParams.cv_login, true);
            });
        }).then((user) => ({
            ck_user: user.ck_id,
            data: user,
        }));
    }
    async init(reload) {
        const rows = [];
        Object.keys(this.mapGroupActions).forEach((group) => {
            rows.push(new Promise((resolve, reject) => {
                this.ad.getUsersForGroup(group, (err, users) => {
                    if (err) {
                        reject(err);
                        return;
                    }
                    if (!users || users.length) {
                        return;
                    }
                    const addUsers = [];
                    users.forEach((user) => {
                        const data = Object.keys(this.mapUserAttr).reduce((obj, val) => ({
                            ...obj,
                            [val]: user[this.mapUserAttr[val]],
                        }), {
                            ca_actions: this.getActionUser(user, this.listDefaultActions),
                            ck_id: user.objectSID,
                            cv_timezone: "+03:00",
                        });
                        addUsers.push(this.authController.addUser(data.ck_id, this.name, data));
                    });
                    Promise.all(addUsers).then(() => resolve(), (errAdd) => reject(errAdd));
                });
            }));
        });
        return Promise.all(rows)
            .then(() => this.authController.updateHashAuth())
            .then(async () => {
            await this.authController.updateUserInfo(this.name);
        });
    }
    async initContext(context, query = {}) {
        const res = await super.initContext(context, query);
        if (Util_1.isEmpty(query.queryStr)) {
            throw new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY);
        }
        if (context.actionName !== "auth") {
            throw new ErrorException_1.default(ErrorGate_1.default.UNSUPPORTED_METHOD);
        }
        return res;
    }
    initSession(resolve, reject, username, isUserData = false) {
        this.ad.findUser(username, (err, user) => {
            if (err || !user) {
                this.log.error(err ? err.message : `Not found user ${username}`, err);
                reject(new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED));
                return;
            }
            this.authController
                .getUserDb()
                .findOne({
                $and: [
                    {
                        ck_d_provider: this.name,
                    },
                    {
                        "data.cv_login": username,
                    },
                ],
            }, true)
                .then(async (userData = {}) => {
                const data = Object.keys(this.mapUserAttr).reduce((obj, val) => ({
                    ...obj,
                    [val]: user[this.mapUserAttr[val]],
                }), {
                    ...userData.data,
                    ca_actions: this.getActionUser(user, [
                        ...(userData.data || {}).ca_actions,
                        ...this.listDefaultActions,
                    ]),
                    ck_id: (userData.data || {}).ck_id || user.objectSID,
                    cv_timezone: (userData.data || {}).cv_timezone || "+03:00",
                });
                if (!(userData.data || {}).ck_id) {
                    await this.authController.addUser(data.ck_id, this.name, data);
                }
                if (isUserData) {
                    return resolve(data);
                }
                const session = await this.authController.loadSession(null, userData.ck_id || user.objectSID, this.name);
                if (session) {
                    return resolve(session);
                }
                return this.createSession(data.ck_id, data)
                    .then((res) => this.authController.loadSession(res.session))
                    .then((sess) => resolve(sess));
            })
                .catch((errFind) => {
                this.log.error(errFind.message, errFind);
                reject(new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED));
            });
        });
    }
    getActionUser(user, actions) {
        const groups = Object.keys(this.mapGroupActions);
        if (groups.length) {
            return lodash_1.uniq(groups.reduce((arr, group) => user.isMemberOf(group)
                ? [...arr, this.mapGroupActions[group]]
                : arr, actions));
        }
        return actions;
    }
}
exports.default = AdAuth;
