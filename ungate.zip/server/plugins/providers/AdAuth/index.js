"use strict";
const AdAuth_1 = require("./AdAuth");
module.exports = AdAuth_1.default;
