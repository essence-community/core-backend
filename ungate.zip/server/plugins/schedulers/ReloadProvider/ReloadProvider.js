"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const NullScheduler_1 = require("@ungate/plugininf/lib/NullScheduler");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
class ReloadProvider extends NullScheduler_1.default {
    static getParamsInfo() {
        return {
            providerName: {
                name: "Наименование провайдера",
                required: true,
                type: "string",
            },
        };
    }
    constructor(name, params, cron, isEnable) {
        super(name, params, cron, isEnable);
        this.params = Util_1.initParams(ReloadProvider.getParamsInfo(), params);
    }
    async init(reload) {
        return;
    }
    execute() {
        ProcessSender_1.sendProcess({
            command: "reloadProvider",
            data: {
                name: this.params.providerName,
            },
            target: "cluster",
        });
    }
    async destroy() {
        return;
    }
}
exports.default = ReloadProvider;
