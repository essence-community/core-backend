"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const postgres_1 = require("@ungate/plugininf/lib/db/postgres");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const NullEvent_1 = require("@ungate/plugininf/lib/NullEvent");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const logger = Logger_1.default.getLogger("CorePgNotification");
class CoreSemaphore extends NullEvent_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(CoreSemaphore.getParamsInfo(), params);
        this.dataSource = new postgres_1.default(`${this.name}_semaphore`, {
            connectString: this.params.connectString,
            poolMax: 5,
        });
    }
    static getParamsInfo() {
        return {
            connectString: {
                name: "Строка подключения к БД",
                required: true,
                type: "string",
            },
        };
    }
    async init(reload) {
        if (this.eventConnect) {
            const conn = this.eventConnect;
            this.eventConnect = null;
            await conn.close();
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        this.eventConnect = await this.dataSource.open();
        this.eventConnect.getCurrentConnection().on("error", (err) => {
            logger.error(`Ошибка отслеживания семафора ${this.name} ${err.message}`, err);
            this.reload();
        });
        return this.initEvents();
    }
    initEvents() {
        logger.info(`Init event ${this.name}`);
        this.eventMask();
        const conn = this.eventConnect.getCurrentConnection();
        conn.on("notification", (msg) => {
            logger.debug("Notification %j", msg);
            const payload = JSON.parse(msg.payload);
            if (payload.table &&
                payload.table.toLowerCase().endsWith("t_semaphore")) {
                const mask = payload.data.cn_value !== 0;
                logger.debug(`Event mask ${mask}`);
                ProcessSender_1.sendProcess({
                    command: "setMask",
                    data: {
                        mask,
                    },
                    target: "cluster",
                });
            }
        });
        return conn.query("LISTEN events");
    }
    eventMask() {
        try {
            this.dataSource
                .executeStmt("select t.cn_value from t_semaphore t where t.ck_id = 'GUI_blocked'")
                .then((data) => new Promise((resolve, reject) => {
                const rows = [];
                data.stream.on("data", (chunk) => rows.push(chunk));
                data.stream.on("error", (error) => reject(error));
                data.stream.on("end", () => {
                    logger.debug(`Event rows %j`, rows);
                    if (rows.length) {
                        const mask = rows[0].cn_value != 0;
                        logger.debug(`Event mask ${mask}`);
                        ProcessSender_1.sendProcess({
                            command: "setMask",
                            data: {
                                mask,
                            },
                            target: "cluster",
                        });
                        return resolve();
                    }
                    return reject(new Error("Not found GUI_blocked"));
                });
            }))
                .catch((err) => {
                this.eventMask();
                logger.error(err);
            });
        }
        catch (e) {
            logger.error(e);
        }
    }
    reload() {
        this.init().then(lodash_1.noop, (err) => {
            logger.error(`Ошибка отслеживания семафора ${this.name} ${err.message}`, err);
            lodash_1.delay(this.reload, 15000);
        });
    }
}
exports.default = CoreSemaphore;
