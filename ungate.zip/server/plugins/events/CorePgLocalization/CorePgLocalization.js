"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const postgres_1 = require("@ungate/plugininf/lib/db/postgres");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const NullEvent_1 = require("@ungate/plugininf/lib/NullEvent");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const logger = Logger_1.default.getLogger("CorePgLocalization");
class CorePgLocalization extends NullEvent_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(CorePgLocalization.getParamsInfo(), params);
        this.dataSource = new postgres_1.default(`${this.name}_events`, {
            connectString: this.params.connectString,
            partRows: this.params.partRows,
            poolMax: this.params.poolMax,
            queryTimeout: this.params.queryTimeout,
        });
    }
    static getParamsInfo() {
        return {
            ...postgres_1.default.getParamsInfo(),
        };
    }
    async init(reload) {
        if (this.eventConnect) {
            const conn = this.eventConnect;
            this.eventConnect = null;
            await conn.close();
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        this.eventConnect = await this.dataSource.open();
        this.eventConnect.getCurrentConnection().on("error", (err) => {
            logger.error(`Ошибка отслеживания локализации ${this.name} ${err.message}`, err);
            this.reload();
        });
        return this.initEvents();
    }
    initEvents() {
        logger.info(`Init event ${this.name}`);
        const conn = this.eventConnect.getCurrentConnection();
        conn.on("notification", (msg) => {
            logger.debug("Notification %j", msg);
            const payload = JSON.parse(msg.payload);
            if (payload.table &&
                payload.table.toLowerCase().endsWith("t_localization")) {
                logger.debug(`Event localization ${payload.data.ck_id} - ${payload.data.cv_value}`);
                const text = JSON.stringify([
                    {
                        data: payload.data,
                        event: "localization",
                    },
                ]);
                ProcessSender_1.sendProcess({
                    command: "sendNotificationAll",
                    data: {
                        text,
                    },
                    target: "cluster",
                });
            }
        });
        return conn.query("LISTEN events");
    }
    reload() {
        this.init().then(lodash_1.noop, (err) => {
            logger.error(`Ошибка отслеживания локализации ${this.name} ${err.message}`, err);
            lodash_1.delay(this.reload, 15000);
        });
    }
}
exports.default = CorePgLocalization;
