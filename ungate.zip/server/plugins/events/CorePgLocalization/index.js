"use strict";
const CorePgLocalization_1 = require("./CorePgLocalization");
module.exports = CorePgLocalization_1.default;
