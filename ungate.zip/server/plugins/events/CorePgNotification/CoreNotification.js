"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const postgres_1 = require("@ungate/plugininf/lib/db/postgres");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const NullEvent_1 = require("@ungate/plugininf/lib/NullEvent");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const logger = Logger_1.default.getLogger("CoreNotification");
class CoreNotification extends NullEvent_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(CoreNotification.getParamsInfo(), params);
        this.dataSource = new postgres_1.default(`${this.name}_events`, {
            connectString: this.params.connectString,
            partRows: this.params.partRows,
            poolMax: this.params.poolMax,
            queryTimeout: this.params.queryTimeout,
        });
    }
    static getParamsInfo() {
        return {
            authProvider: {
                name: "Наименвание провайдера авторизации",
                type: "string",
            },
            ...postgres_1.default.getParamsInfo(),
        };
    }
    async init(reload) {
        if (this.eventConnect) {
            const conn = this.eventConnect;
            this.eventConnect = null;
            await conn.close();
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        this.eventConnect = await this.dataSource.open();
        this.eventConnect.getCurrentConnection().on("error", (err) => {
            logger.error(`Ошибка оповещения ${this.name} ${err.message}`, err);
            this.reload();
        });
        return this.initEvents();
    }
    initEvents() {
        logger.info(`Init event provider ${this.name}`);
        ProcessSender_1.sendProcess({
            callback: {
                command: "eventNotification",
                data: {
                    name: this.name,
                },
                target: "eventNode",
            },
            command: "getWsUsers",
            data: {
                nameProvider: this.params.authProvider,
            },
            target: "cluster",
        });
        const conn = this.eventConnect.getCurrentConnection();
        conn.on("notification", (msg) => {
            logger.debug("Notification %j", msg);
            const payload = JSON.parse(msg.payload);
            if (payload.table &&
                payload.table.toLowerCase().endsWith("t_notification")) {
                ProcessSender_1.sendProcess({
                    callback: {
                        command: "eventNotification",
                        data: {
                            name: this.name,
                        },
                        target: "eventNode",
                    },
                    command: "getWsUsers",
                    data: {
                        nameProvider: this.params.authProvider,
                    },
                    target: "cluster",
                });
            }
        });
        return conn.query("LISTEN events");
    }
    async eventNotification(ckUsers) {
        logger.debug(`LoadEventNotification: %j`, ckUsers);
        if (Util_1.isEmpty(ckUsers)) {
            return;
        }
        const json = ckUsers.map((value) => ({
            ck_id: value,
        }));
        const params = { json: JSON.stringify(json) };
        const sqlNotification = "select t.*\n" +
            "  from t_notification t\n" +
            " where current_timestamp between t.cd_st and t.cd_en\n" +
            "   and t.cl_sent = 0\n" +
            "   and t.ck_user in\n" +
            "       (select ck_id from json_to_recordset(:json) as x(ck_id text))\n" +
            "   for update skip locked";
        this.dataSource.open().then((conn) => conn
            .executeStmt(sqlNotification, params)
            .then((data) => new Promise((resolve, reject) => {
            const rows = [];
            data.stream.on("data", (chunk) => rows.push(chunk));
            data.stream.on("error", (err) => reject(err));
            data.stream.on("end", () => {
                if (rows.length) {
                    const sendRows = rows.map((row) => this.sendNotification(row.ck_user, row));
                    return Promise.all(sendRows)
                        .then((values) => this.updateNotification(conn, values.filter((value) => lodash_1.isObject(value))))
                        .then(() => resolve())
                        .catch((err) => reject(err));
                }
                return resolve();
            });
        }), (err) => {
            logger.error(`sql: ${sqlNotification} json: ${params.json}`);
            return Promise.reject(err);
        })
            .then(() => conn.commit(), (err) => {
            logger.error(err);
            return conn.rollback();
        })
            .then(() => conn.release(), () => conn.release())
            .then(lodash_1.noop)
            .catch((err) => logger.error(err)));
    }
    async updateNotification(conn, params = []) {
        if (params.length) {
            return Promise.all(params.map((param) => conn.executeStmt("select PKG_JSON_NOTIFICATION.f_modify_notification(pc_json => :json) as result", param)));
        }
        return;
    }
    sendNotification(user, row) {
        return new Promise((resolve) => {
            try {
                const msg = JSON.parse(row.cv_message);
                const text = JSON.stringify([
                    {
                        data: {
                            ck_id: row.ck_id,
                            ...msg,
                        },
                        event: "notification",
                    },
                ]);
                if (!Util_1.isEmpty(msg.export_excel)) {
                    const exportExcel = JSON.stringify([
                        {
                            data: {
                                url: msg.export_excel,
                            },
                            event: "export_excel",
                        },
                    ]);
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text: exportExcel,
                        },
                        target: "cluster",
                    });
                }
                if (!Util_1.isEmpty(msg.reloadpageobject)) {
                    const reloadMsg = JSON.stringify([
                        {
                            data: msg.reloadpageobject,
                            event: "reloadpageobject",
                        },
                    ]);
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text: reloadMsg,
                        },
                        target: "cluster",
                    });
                }
                if (!Util_1.isEmpty(msg.cv_error)) {
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text,
                        },
                        target: "cluster",
                    });
                }
                resolve({
                    json: JSON.stringify({
                        data: {
                            ...row,
                            cl_sent: 1,
                        },
                        service: {
                            cv_action: "U",
                        },
                    }),
                });
            }
            catch (e) {
                logger.error(`Message: ${JSON.stringify(row)}`, e);
                resolve();
            }
        });
    }
    reload() {
        this.init().then(lodash_1.noop, (err) => {
            logger.error(`Ошибка оповещения ${this.name} ${err.message}`, err);
            lodash_1.delay(this.reload, 15000);
        });
    }
}
exports.default = CoreNotification;
