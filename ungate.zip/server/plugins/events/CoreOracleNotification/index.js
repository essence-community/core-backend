"use strict";
const CoreNotification_1 = require("./CoreNotification");
module.exports = CoreNotification_1.default;
