"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const oracle_1 = require("@ungate/plugininf/lib/db/oracle");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const NullEvent_1 = require("@ungate/plugininf/lib/NullEvent");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const logger = Logger_1.default.getLogger("CoreNotification");
const CHECK_TIMEOUT = 15000;
class CoreNotification extends NullEvent_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_2.initParams(CoreNotification.getParamsInfo(), params);
        this.dataSource = new oracle_1.default(`${this.name}_events`, {
            connectString: this.params.connectString,
            maxRows: this.params.maxRows,
            partRows: this.params.partRows,
            password: this.params.password,
            poolMax: this.params.poolMax,
            poolMin: this.params.poolMin,
            prefetchRows: this.params.prefetchRows,
            queryTimeout: this.params.queryTimeout,
            queueTimeout: this.params.queueTimeout,
            user: this.params.user,
        });
    }
    static getParamsInfo() {
        return {
            authProvider: {
                name: "Наименвание провайдера авторизации",
                type: "string",
            },
            ...oracle_1.default.getParamsInfo(),
        };
    }
    async init(reload) {
        if (this.eventConnect) {
            const conn = this.eventConnect;
            this.eventConnect = null;
            await conn.unsubscribe(`core_notification_${this.name}`).then(() => this.dataSource.onClose(conn), () => this.dataSource.onClose(conn));
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        this.eventConnect = await this.dataSource.openEvents({
            connectString: this.params.connectString,
            password: this.params.password,
            user: this.params.user,
        });
        this.eventConnect.on("error", (err) => {
            logger.error(`Ошибка оповещения ${this.name} ${err.message}`, err);
            this.reload();
        });
        if (this.checktimer !== null) {
            clearTimeout(this.checktimer);
        }
        this.checktimer = setTimeout(() => this.checkEventConnect(), CHECK_TIMEOUT);
        return this.initEvents();
    }
    initEvents() {
        logger.info(`Init event provider ${this.name}`);
        ProcessSender_1.sendProcess({
            callback: {
                command: "eventNotification",
                data: {
                    name: this.name,
                },
                target: "eventNode",
            },
            command: "getWsUsers",
            data: {
                nameProvider: this.params.authProvider,
            },
            target: "cluster",
        });
        return this.eventConnect.subscribe(`core_notification_${this.name}`, {
            callback: (event) => {
                logger.debug(`Event provider ${this.name}: ${event}`);
                ProcessSender_1.sendProcess({
                    callback: {
                        command: "eventNotification",
                        data: {
                            name: this.name,
                        },
                        target: "eventNode",
                    },
                    command: "getWsUsers",
                    data: {
                        nameProvider: this.params.authProvider,
                    },
                    target: "cluster",
                });
            },
            qos: this.dataSource.oracledb.SUBSCR_QOS_BEST_EFFORT,
            sql: "select * from t_notification",
        });
    }
    async eventNotification(ckUsers) {
        logger.debug(`LoadEventNotification: ${ckUsers}`);
        if (Util_2.isEmpty(ckUsers)) {
            return;
        }
        const json = ckUsers.map((value) => ({
            ck_id: value,
        }));
        const params = { json: JSON.stringify(json) };
        const sqlNotification = "declare\n" +
            "  vct_users ct_number;\n" +
            "begin\n" +
            "  select distinct ck_id\n" +
            "    bulk collect\n" +
            "    into vct_users\n" +
            "    from json_table(:json, '$[*]' columns(ck_id number path '$.ck_id'));\n" +
            "\n" +
            "  open :cur for\n" +
            "    select t.*\n" +
            "      from t_notification t\n" +
            "     where sysdate between t.cd_st and t.cd_en\n" +
            "       and t.cl_sent = 0\n" +
            "       and t.ck_user in (select column_value from table(vct_users))\n" +
            "       for update;\n" +
            "end;";
        this.dataSource.open().then((conn) => conn
            .executeStmt(sqlNotification, params, {
            cur: "CURSOR",
        })
            .then((data) => new Promise((resolve, reject) => {
            const rows = [];
            data.stream.on("data", (chunk) => rows.push(chunk));
            data.stream.on("error", (err) => reject(err));
            data.stream.on("end", () => {
                if (rows.length) {
                    const sendRows = rows.map((row) => this.sendNotification(row.ck_user, row));
                    return Promise.all(sendRows)
                        .then((values) => this.updateNotification(conn.getCurrentConnection(), values.filter((value) => lodash_1.isObject(value))))
                        .then(() => resolve())
                        .catch((err) => reject(err));
                }
                return resolve();
            });
        }), (err) => {
            logger.error(`sql: ${sqlNotification} json: ${params.json}`);
            return Promise.reject(err);
        })
            .then(() => conn.commit(), (err) => {
            logger.error(err);
            return conn.rollback();
        })
            .then(() => conn.release(), () => conn.release())
            .then(lodash_1.noop)
            .catch((err) => logger.error(err)));
    }
    checkEventConnect() {
        this.dataSource
            .executeStmt("select count(*) cnt\n" +
            "  from user_change_notification_regs ucqn\n" +
            " where ucqn.table_name like upper('%t_notification')")
            .then((res) => Util_1.ReadStreamToArray(res.stream))
            .then(([row]) => {
            if (row.cnt < 1) {
                return this.reload();
            }
            this.checktimer = setTimeout(() => this.checkEventConnect(), CHECK_TIMEOUT);
        })
            .catch((err) => logger.error(err));
    }
    async updateNotification(conn, params = []) {
        if (params.length) {
            return conn.executeMany("begin\n:result := PKG_JSON_NOTIFICATION.f_modify_notification(pc_json => :json);\nend;", params, {
                autoCommit: true,
                bindDefs: {
                    json: {
                        maxSize: 4000,
                        type: this.dataSource.oracledb.STRING,
                    },
                    result: {
                        dir: this.dataSource.oracledb.BIND_OUT,
                        maxSize: 4000,
                        type: this.dataSource.oracledb.STRING,
                    },
                },
            });
        }
        return;
    }
    sendNotification(user, row) {
        return new Promise((resolve) => {
            try {
                const msg = JSON.parse(row.cv_message);
                const text = JSON.stringify([
                    {
                        data: {
                            ck_id: row.ck_id,
                            ...msg,
                        },
                        event: "notification",
                    },
                ]);
                if (!Util_2.isEmpty(msg.export_excel)) {
                    const exportExcel = JSON.stringify([
                        {
                            data: {
                                url: msg.export_excel,
                            },
                            event: "export_excel",
                        },
                    ]);
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text: exportExcel,
                        },
                        target: "cluster",
                    });
                }
                if (!Util_2.isEmpty(msg.reloadpageobject)) {
                    const reloadMsg = JSON.stringify([
                        {
                            data: msg.reloadpageobject,
                            event: "reloadpageobject",
                        },
                    ]);
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text: reloadMsg,
                        },
                        target: "cluster",
                    });
                }
                if (!Util_2.isEmpty(msg.cv_error)) {
                    ProcessSender_1.sendProcess({
                        command: "sendNotification",
                        data: {
                            ckUser: user,
                            nameProvider: this.params.authProvider,
                            text,
                        },
                        target: "cluster",
                    });
                }
                resolve({
                    json: JSON.stringify({
                        data: {
                            ...row,
                            cl_sent: 1,
                        },
                        service: {
                            cv_action: "U",
                        },
                    }),
                });
            }
            catch (e) {
                logger.error(`Message: ${JSON.stringify(row)}`, e);
                resolve();
            }
        });
    }
    reload() {
        this.init().then(lodash_1.noop, (err) => {
            logger.error(`Ошибка оповещения ${this.name} ${err.message}`, err);
            lodash_1.delay(this.reload, 15000);
        });
    }
}
exports.default = CoreNotification;
