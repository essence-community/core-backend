"use strict";
const CoreSemaphore_1 = require("./CoreSemaphore");
module.exports = CoreSemaphore_1.default;
