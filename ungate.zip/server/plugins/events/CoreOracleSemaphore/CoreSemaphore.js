"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const oracle_1 = require("@ungate/plugininf/lib/db/oracle");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const NullEvent_1 = require("@ungate/plugininf/lib/NullEvent");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const logger = Logger_1.default.getLogger("CoreNotification");
const CHECK_TIMEOUT = 15000;
class CoreSemaphore extends NullEvent_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_2.initParams(CoreSemaphore.getParamsInfo(), params);
        this.dataSource = new oracle_1.default(`${this.name}_semaphore`, {
            connectString: this.params.connectString,
            password: this.params.password,
            poolMax: 10,
            user: this.params.user,
        });
    }
    static getParamsInfo() {
        return {
            connectString: {
                name: "Строка подключения к БД",
                required: true,
                type: "string",
            },
            password: {
                name: "Пароль учетной записи БД",
                required: true,
                type: "string",
            },
            user: {
                name: "Наименвание учетной записи БД",
                required: true,
                type: "string",
            },
        };
    }
    async init(reload) {
        if (this.eventConnect) {
            const conn = this.eventConnect;
            this.eventConnect = null;
            await conn.unsubscribe(`core_semaphore_${this.name}`).then(() => this.dataSource.onClose(conn), () => this.dataSource.onClose(conn));
        }
        if (this.dataSource.pool) {
            await this.dataSource.resetPool();
        }
        await this.dataSource.createPool();
        this.eventConnect = await this.dataSource.openEvents({
            connectString: this.params.connectString,
            password: this.params.password,
            user: this.params.user,
        });
        this.eventConnect.on("error", (err) => {
            logger.error(`Ошибка отслеживания семафора ${this.name} ${err.message}`, err);
            this.reload();
        });
        if (this.checktimer !== null) {
            clearTimeout(this.checktimer);
        }
        this.checktimer = setTimeout(() => this.checkEventConnect(), CHECK_TIMEOUT);
        return this.initEvents();
    }
    initEvents() {
        logger.info(`Init event ${this.name}`);
        this.eventMask();
        return this.eventConnect.subscribe(`core_semaphore_${this.name}`, {
            callback: (event) => {
                logger.debug(`Init event ${this.name} event ${event}`);
                this.eventMask();
            },
            qos: this.dataSource.oracledb.SUBSCR_QOS_ROWIDS,
            sql: "select * from t_semaphore",
        });
    }
    eventMask() {
        try {
            this.dataSource
                .executeStmt("select t.cn_value from t_semaphore t where t.ck_id = 'GUI_blocked'")
                .then((data) => new Promise((resolve, reject) => {
                const rows = [];
                data.stream.on("data", (chunk) => rows.push(chunk));
                data.stream.on("error", (error) => reject(error));
                data.stream.on("end", () => {
                    if (rows.length) {
                        const mask = rows[0].cn_value !== 0;
                        logger.debug(`Event mask ${mask}`);
                        ProcessSender_1.sendProcess({
                            command: "setMask",
                            data: {
                                mask,
                            },
                            target: "cluster",
                        });
                        return resolve();
                    }
                    return reject(new Error("Not found GUI_blocked"));
                });
            }))
                .catch((err) => {
                this.eventMask();
                logger.error(err);
            });
        }
        catch (e) {
            logger.error(e);
        }
    }
    reload() {
        this.init().then(lodash_1.noop, (err) => {
            logger.error(`Ошибка отслеживания семафора ${this.name} ${err.message}`, err);
            lodash_1.delay(this.reload, 15000);
        });
    }
    checkEventConnect() {
        this.dataSource
            .executeStmt("select count(*) cnt\n" +
            "  from user_change_notification_regs ucqn\n" +
            " where ucqn.table_name like upper('%t_semaphore')")
            .then((res) => Util_1.ReadStreamToArray(res.stream))
            .then(([row]) => {
            if (row.cnt < 1) {
                return this.reload();
            }
            this.checktimer = setTimeout(() => this.checkEventConnect(), CHECK_TIMEOUT);
        })
            .catch((err) => logger.error(err));
    }
}
exports.default = CoreSemaphore;
