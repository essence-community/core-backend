"use strict";
const USPOIntegration_1 = require("./USPOIntegration");
module.exports = USPOIntegration_1.default;
