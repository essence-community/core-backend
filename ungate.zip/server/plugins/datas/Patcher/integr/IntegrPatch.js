"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const Utils_1 = require("../Utils");
const Interface_1 = require("./Interface");
const Provider_1 = require("./Provider");
const SqlPostgres_1 = require("./SqlPostgres");
async function patchIntegr(dir, json, conn) {
    const include = [];
    const meta = path.join(dir, "integr");
    if (!fs.existsSync(meta)) {
        fs.mkdirSync(meta);
    }
    if (json.data.cct_interface) {
        const integr = Utils_1.createWriteStream(meta, "Interface");
        include.push("Interface");
        await conn
            .executeStmt(SqlPostgres_1.sqlProvider, {
            cct_interface: JSON.stringify(json.data.cct_interface),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                integr.write(new Provider_1.Provider(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await conn
            .executeStmt(SqlPostgres_1.sqlInterface, {
            cct_interface: JSON.stringify(json.data.cct_interface),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                integr.write(new Interface_1.Interface(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await Utils_1.closeFsWriteStream(integr);
    }
    return Utils_1.createChangeXml(path.join(meta, "integr.xml"), include.map((str) => `        <include file="./integr/${str}.sql" />\n`));
}
exports.patchIntegr = patchIntegr;
