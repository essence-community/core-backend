"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const os = require("os");
const path = require("path");
class DirStorage {
    constructor(params, logger) {
        this.UPLOAD_DIR = process.env.GATE_UPLOAD_DIR || os.tmpdir();
        this.params = params;
        this.logger = logger;
    }
    saveFile(key, buffer, content, metaData = {}, size = buffer.pipe
        ? Buffer.byteLength(buffer)
        : undefined) {
        const prePath = key.startsWith("/") ? key : `/${key}`;
        return new Promise((resolve, reject) => {
            const dir = path.dirname(`${this.params.cvPath}${prePath}`);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, {
                    recursive: true,
                });
            }
            fs.writeFileSync(`${this.params.cvPath}${prePath}.meta`, JSON.stringify({
                ...metaData,
                ContentLength: size,
                ContentType: content,
            }));
            if (buffer.pipe) {
                const ws = fs.createWriteStream(`${this.params.cvPath}${prePath}`);
                ws.on("error", (err) => reject(err));
                buffer.on("error", (err) => reject(err));
                buffer.on("end", () => resolve());
                buffer.pipe(ws);
                return;
            }
            fs.writeFile(`${this.params.cvPath}${prePath}`, buffer, (err) => {
                if (err) {
                    reject(err);
                }
                resolve();
            });
        });
    }
    deletePath(key) {
        const prePath = key.startsWith("/") ? key : `/${key}`;
        return new Promise((resolve, reject) => {
            const file = `${this.params.cvPath}${prePath}`;
            if (!fs.existsSync(file)) {
                return resolve();
            }
            fs.unlink(file, (err) => {
                if (err) {
                    return reject(err);
                }
                resolve();
            });
        });
    }
    getFile(key) {
        const prePath = key.startsWith("/") ? key : `/${key}`;
        return new Promise((resolve, reject) => {
            const readMetaData = JSON.parse(fs
                .readFileSync(`${this.params.cvPath}${prePath}.meta`)
                .toString());
            resolve({
                fieldName: "upload",
                headers: {
                    "content-type": readMetaData.ContentType,
                },
                originalFilename: readMetaData.originalFilename,
                path: `${this.params.cvPath}${prePath}`,
                size: readMetaData.ContentLength,
            });
        });
    }
}
exports.DirStorage = DirStorage;
