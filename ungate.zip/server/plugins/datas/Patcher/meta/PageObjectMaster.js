"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatMPageObjectMasterSqlPostgres = "update s_mt.t_page_object set ck_master=%s where ck_id=%s;\n";
class PageObjectMaster extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatMPageObjectMasterSqlPostgres, this.toStringOrNull("ck_master"), this.toStringOrNull("ck_id"));
    }
}
exports.PageObjectMaster = PageObjectMaster;
