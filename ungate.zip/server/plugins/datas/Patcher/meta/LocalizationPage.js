"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatLocalizationSqlPostgres = "    select %s as ck_id, %s as ck_d_lang, %s as cr_namespace, %s as cv_value, %s as ck_user, %s as ct_change\n";
class LocalizationPage extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatLocalizationSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_d_lang"), this.toStringOrNull("cr_namespace"), this.toStringOrNull("cv_value"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.LocalizationPage = LocalizationPage;
