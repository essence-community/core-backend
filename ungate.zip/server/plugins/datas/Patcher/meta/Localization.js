"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatLocalizationSqlPostgres = "INSERT INTO s_mt.t_localization (ck_id, ck_d_lang, cr_namespace, cv_value, ck_user, ct_change)" +
    " VALUES(%s, %s, %s, %s, %s, %s) " +
    "on conflict on constraint cin_u_localization_1 do update set ck_id = excluded.ck_id, ck_d_lang = excluded.ck_d_lang, cr_namespace = excluded.cr_namespace, cv_value = excluded.cv_value, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n";
class Localization extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatLocalizationSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_d_lang"), this.toStringOrNull("cr_namespace"), this.toStringOrNull("cv_value"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.Localization = Localization;
