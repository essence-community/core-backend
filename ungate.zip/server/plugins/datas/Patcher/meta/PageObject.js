"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatPageObjectSqlPostgres = "INSERT INTO s_mt.t_page_object (ck_id, ck_page, ck_object, cn_order, ck_parent, ck_master, ck_user, ct_change)" +
    " VALUES (%s, %s, %s, %s, %s, %s, %s, %s) " +
    " on conflict (ck_id) do update set ck_page = excluded.ck_page, ck_object = excluded.ck_object, cn_order = excluded.cn_order, ck_parent = excluded.ck_parent, ck_master = excluded.ck_master, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n";
class PageObject extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatPageObjectSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_page"), this.toStringOrNull("ck_object"), this.row.cn_order, this.toStringOrNull("ck_parent"), "null", this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.PageObject = PageObject;
