"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatMObjectAttrSqlPostgres = "select pkg_patcher.p_merge_object_attr(%s, %s, %s, %s, %s, %s);\n";
class ObjectAttr extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatMObjectAttrSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_object"), this.toStringOrNull("ck_class_attr"), this.toStringOrNull("cv_value"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.ObjectAttr = ObjectAttr;
