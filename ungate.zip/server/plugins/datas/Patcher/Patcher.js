"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const Zip = require("adm-zip");
const crypto = require("crypto");
const fs = require("fs");
const moment = require("moment");
const path = require("path");
const uuidv4_1 = require("uuidv4");
const AuthPatch_1 = require("./auth/AuthPatch");
const DirStorage_1 = require("./DirStorage");
const IntegrPatch_1 = require("./integr/IntegrPatch");
const MetaPatch_1 = require("./meta/MetaPatch");
const S3Storage_1 = require("./S3Storage");
class Patcher extends NullPlugin_1.default {
    constructor(name, params) {
        super(name, params);
        const storage = params.cvTypeStorage === "dir"
            ? new DirStorage_1.DirStorage(this.params, this.logger)
            : new S3Storage_1.S3Storage(this.params, this.logger);
        this.saveFile = storage.saveFile.bind(storage);
        this.deletePath = storage.deletePath.bind(storage);
        this.getFile = storage.getFile.bind(storage);
    }
    static getParamsInfo() {
        return {
            cvTypeStorage: {
                defaultValue: "riak",
                name: "Тип хранилища: dir|aws|riak",
                type: "string",
            },
            cvPath: {
                name: "Адрес Riak|Dir|Aws",
                type: "string",
            },
            cvS3Bucket: {
                name: "Наименование корзины s3",
                type: "string",
            },
            cvS3KeyId: {
                name: "Id key S3 Storage",
                type: "string",
            },
            cvS3SecretKey: {
                name: "Secret key S3 Storage",
                type: "password",
            },
        };
    }
    saveFile(f, buffer, content, metaData, size) {
        throw new Error("Method not implemented.");
    }
    deletePath(f) {
        throw new Error("Method not implemented.");
    }
    getFile(key) {
        throw new Error("Method not implemented.");
    }
    async beforeQueryExecutePerform(gateContext, PRequestContext, query) {
        if (Util_1.isEmpty(query.inParams.json)) {
            throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
        }
        const json = JSON.parse(query.inParams.json);
        if (gateContext.actionName === "dml") {
            if (json.service.cv_action.toUpperCase() === "D") {
                await this.deletePath(json.data.ck_id);
                return;
            }
        }
        if (gateContext.actionName === "file" ||
            gateContext.actionName === "getfile") {
            if (json.data.ck_id) {
                return this.getFile(json.data.ck_id).then((file) => ({
                    data: ResultStream_1.default([
                        {
                            filedata: fs.readFileSync(file.path),
                            filename: file.originalFilename,
                            filetype: file.headers["content-type"],
                        },
                    ]),
                    type: "attachment",
                }));
            }
            json.data.ck_id = uuidv4_1.uuid();
            const temp = fs.mkdtempSync("patch");
            const zip = new Zip();
            zip.addLocalFile(path.join(__dirname, "assets", "update"));
            zip.addLocalFile(path.join(__dirname, "assets", "update.bat"));
            zip.addLocalFolder(path.join(__dirname, "assets", "liquibase"), "liquibase");
            const include = [];
            let nameBd = "core";
            if (json.service.cv_action === "integration") {
                await IntegrPatch_1.patchIntegr(temp, json, gateContext.connection);
                include.push("integr/integr.xml");
                nameBd = "core_integr";
                this.calcMd5(path.join(temp, "integr"));
                zip.addLocalFolder(path.join(temp, "integr"), "integr");
            }
            else if (json.service.cv_action === "auth") {
                await AuthPatch_1.patchAuth(temp, json, gateContext.connection);
                include.push("auth/auth.xml");
                nameBd = "core_auth";
                this.calcMd5(path.join(temp, "auth"));
                zip.addLocalFolder(path.join(temp, "auth"), "auth");
            }
            else {
                await MetaPatch_1.patchMeta(temp, json, gateContext.connection);
                include.push("meta/meta.xml");
                this.calcMd5(path.join(temp, "meta"));
                zip.addLocalFolder(path.join(temp, "meta"), "meta");
            }
            zip.addFile("liquibase.properties", Buffer.from("driver: org.postgresql.Driver\n" +
                `url: jdbc:postgresql://127.0.0.1:5432/${nameBd}\n` +
                "username: s_su\n" +
                "password: s_su\n", "utf-8"));
            zip.addFile("db.changelog.xml", Buffer.from('<?xml version="1.0" encoding="UTF-8"?>\n' +
                "<databaseChangeLog\n" +
                '  xmlns="http://www.liquibase.org/xml/ns/dbchangelog"\n' +
                '  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n' +
                '  xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog\n' +
                '         http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-3.1.xsd">\n' +
                include.reduce((res, str) => {
                    return `${res}        <include file="./${str}" />\n`;
                }, "") +
                "</databaseChangeLog>"));
            zip.writeZip();
            const writeZip = zip.toBuffer();
            json.data.cv_file_name = `Patch_${moment().format("YYYY-MM-DD_HH:mm:ss")}.zip`;
            await this.saveFile(json.data.ck_id, writeZip, "application/zip", {
                originalFilename: json.data.cv_file_name,
            }, writeZip.length);
            json.service.cv_action = "I";
            json.data.cn_size = writeZip.length;
            await gateContext.connection
                .executeStmt(query.queryStr, {
                ...query.inParams,
                json: JSON.stringify(json),
            }, query.outParams, {
                autoCommit: true,
            })
                .then((res) => new Promise((resolve, reject) => {
                res.stream.on("data", (row) => {
                    this.logger.debug(row);
                });
                res.stream.on("error", (err) => reject(err));
                res.stream.on("end", () => resolve());
            }));
            Util_1.deleteFolderRecursive(temp);
            gateContext.response.on("finish", () => {
                ProcessSender_1.sendProcess({
                    command: "sendNotification",
                    data: {
                        ckUser: gateContext.session.ck_id,
                        nameProvider: gateContext.session.ck_d_provider,
                        text: JSON.stringify([
                            {
                                data: {
                                    ck_page: json.service.ck_page,
                                    ck_page_object: json.service.ck_page_object,
                                },
                                event: "reloadpageobject",
                            },
                        ]),
                    },
                    target: "cluster",
                });
            });
            return {
                data: ResultStream_1.default([
                    {
                        filedata: writeZip,
                        filename: json.data.cv_file_name,
                        filetype: "application/zip",
                    },
                ]),
                type: "attachment",
            };
        }
        return;
    }
    calcMd5(dir) {
        fs.readdirSync(dir).forEach((file) => {
            const f = path.join(dir, file);
            if (fs.lstatSync(f).isFile) {
                fs.writeFileSync(path.join(dir, `${file}.md5`), crypto
                    .createHash("md5")
                    .update(fs.readFileSync(f))
                    .digest("hex"));
            }
        });
    }
}
exports.Patcher = Patcher;
