"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatRoleActionSqlPostgres = "         select (%s)::uuid as ck_id, (%s)::bigint as ck_action, (%s)::uuid as ck_role, %s as ck_user, %s as ct_change\n";
class RoleAction extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatRoleActionSqlPostgres, this.toStringOrNull("ck_id"), this.row.ck_action, this.toStringOrNull("ck_role"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.RoleAction = RoleAction;
