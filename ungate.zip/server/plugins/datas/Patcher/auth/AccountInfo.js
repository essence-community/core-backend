"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatAccountInfoSqlPostgres = "        select (%s)::uuid as ck_id, (%s)::uuid as ck_account, %s as ck_d_info, %s as cv_value, %s as ck_user, %s as ct_change\n";
class AccountInfo extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatAccountInfoSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_account"), this.toStringOrNull("ck_d_info"), this.toStringOrNull("cv_value"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.AccountInfo = AccountInfo;
