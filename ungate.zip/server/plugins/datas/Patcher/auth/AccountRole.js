"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const util_1 = require("util");
const IRowPatch_1 = require("../IRowPatch");
const formatAccountRoleSqlPostgres = "        select (%s)::uuid as ck_id, (%s)::uuid as ck_role, (%s)::uuid as ck_account, %s as ck_user, %s as ct_change\n";
class AccountRole extends IRowPatch_1.IRowPatch {
    toRow() {
        return util_1.format(formatAccountRoleSqlPostgres, this.toStringOrNull("ck_id"), this.toStringOrNull("ck_role"), this.toStringOrNull("ck_account"), this.toStringOrNull("ck_user"), this.toTimestamp("ct_change"));
    }
}
exports.AccountRole = AccountRole;
