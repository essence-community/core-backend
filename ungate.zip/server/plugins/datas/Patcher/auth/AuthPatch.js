"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
const Utils_1 = require("../Utils");
const Account_1 = require("./Account");
const AccountInfo_1 = require("./AccountInfo");
const AccountRole_1 = require("./AccountRole");
const Action_1 = require("./Action");
const Info_1 = require("./Info");
const Role_1 = require("./Role");
const RoleAction_1 = require("./RoleAction");
const SqlPostgres_1 = require("./SqlPostgres");
const SqlPostgres_2 = require("./SqlPostgres");
async function patchAuth(dir, json, conn) {
    const include = [];
    const meta = path.join(dir, "auth");
    if (!fs.existsSync(meta)) {
        fs.mkdirSync(meta);
    }
    if (json.data.cct_info) {
        const info = Utils_1.createWriteStream(meta, "Info");
        include.push("Info");
        await conn
            .executeStmt(SqlPostgres_2.sqlInfo, {
            cct_info: JSON.stringify(json.data.cct_info),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                info.write(new Info_1.Info(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await conn
            .executeStmt(SqlPostgres_1.sqlInfoAccount, {
            cct_info: JSON.stringify(json.data.cct_info),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    info.write("        union all\n");
                }
                else {
                    info.write("INSERT INTO s_at.t_account_info (ck_id, ck_account, ck_d_info, cv_value, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_account, t.ck_d_info, t.cv_value, t.ck_user, t.ct_change::timestamp from (\n");
                    isNotFirst = true;
                }
                info.write(new AccountInfo_1.AccountInfo(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    info.write(") as t \n" +
                        " join s_at.t_account ac\n" +
                        " on t.ck_account = ac.ck_id\n" +
                        "on conflict on constraint cin_u_account_info_1 do update set ck_id = excluded.ck_id, ck_account = excluded.ck_account, ck_d_info = excluded.ck_d_info, cv_value = excluded.cv_value, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await Utils_1.closeFsWriteStream(info);
    }
    if (json.data.cct_action) {
        const action = Utils_1.createWriteStream(meta, "Action");
        include.push("Action");
        await conn
            .executeStmt(SqlPostgres_2.sqlAction, {
            cct_action: JSON.stringify(json.data.cct_action),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                action.write(new Action_1.Action(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await conn
            .executeStmt(SqlPostgres_1.sqlActionRole, {
            cct_action: JSON.stringify(json.data.cct_action),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    action.write("        union all\n");
                }
                else {
                    action.write("INSERT INTO s_at.t_role_action (ck_id, ck_action, ck_role, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_action, t.ck_role, t.ck_user, t.ct_change::timestamp from (");
                    isNotFirst = true;
                }
                action.write(new RoleAction_1.RoleAction(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    action.write(") as t \n" +
                        " join s_at.t_role r\n" +
                        " on t.ck_role = r.ck_id\n" +
                        "on conflict on constraint cin_u_role_action_1 do update set ck_id = excluded.ck_id, ck_action = excluded.ck_action, ck_role = excluded.ck_role, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await Utils_1.closeFsWriteStream(action);
    }
    if (json.data.cct_role) {
        const role = Utils_1.createWriteStream(meta, "Role");
        include.push("Role");
        await conn
            .executeStmt(SqlPostgres_2.sqlRole, {
            cct_role: JSON.stringify(json.data.cct_role),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                role.write(new Role_1.Role(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await conn
            .executeStmt(SqlPostgres_2.sqlRoleAction, {
            cct_role: JSON.stringify(json.data.cct_role),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    role.write("        union all\n");
                }
                else {
                    role.write("INSERT INTO s_at.t_role_action (ck_id, ck_action, ck_role, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_action, t.ck_role, t.ck_user, t.ct_change::timestamp from (");
                    isNotFirst = true;
                }
                role.write(new RoleAction_1.RoleAction(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    role.write(") as t \n" +
                        " join s_at.t_action ac\n" +
                        " on t.ck_action = ac.ck_id\n" +
                        "on conflict on constraint cin_u_role_action_1 do update set ck_id = excluded.ck_id, ck_action = excluded.ck_action, ck_role = excluded.ck_role, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await conn
            .executeStmt(SqlPostgres_2.sqlRoleAccount, {
            cct_role: JSON.stringify(json.data.cct_role),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    role.write("        union all\n");
                }
                else {
                    role.write("INSERT INTO s_at.t_account_role (ck_id, ck_role, ck_account, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_role, t.ck_account, t.ck_user, t.ct_change::timestamp from (\n");
                    isNotFirst = true;
                }
                role.write(new AccountRole_1.AccountRole(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    role.write(") as t \n" +
                        " join s_at.t_account ac\n" +
                        " on t.ck_account = ac.ck_id\n" +
                        "on conflict on constraint cin_u_account_role_1 do update set ck_id = excluded.ck_id, ck_account = excluded.ck_account, ck_role = excluded.ck_role, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await Utils_1.closeFsWriteStream(role);
    }
    if (json.data.cct_account) {
        const account = Utils_1.createWriteStream(meta, "Account");
        include.push("Account");
        await conn
            .executeStmt(SqlPostgres_2.sqlAccount, {
            cct_account: JSON.stringify(json.data.cct_account),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            res.stream.on("data", (row) => {
                account.write(new Account_1.Account(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => resolve());
        }));
        await conn
            .executeStmt(SqlPostgres_2.sqlAccountRole, {
            cct_account: JSON.stringify(json.data.cct_account),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    account.write("        union all\n");
                }
                else {
                    account.write("INSERT INTO s_at.t_account_role (ck_id, ck_role, ck_account, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_role, t.ck_account, t.ck_user, t.ct_change::timestamp from (\n");
                    isNotFirst = true;
                }
                account.write(new AccountRole_1.AccountRole(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    account.write(") as t \n" +
                        " join s_at.t_role r\n" +
                        " on t.ck_role = r.ck_id\n" +
                        "on conflict on constraint cin_u_account_role_1 do update set ck_id = excluded.ck_id, ck_account = excluded.ck_account, ck_role = excluded.ck_role, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await conn
            .executeStmt(SqlPostgres_2.sqlAccountInfo, {
            cct_account: JSON.stringify(json.data.cct_account),
        }, {}, {
            autoCommit: true,
            resultSet: true,
        })
            .then((res) => new Promise((resolve, reject) => {
            let isNotFirst = false;
            res.stream.on("data", (row) => {
                if (isNotFirst) {
                    account.write("        union all\n");
                }
                else {
                    account.write("INSERT INTO s_at.t_account_info (ck_id, ck_account, ck_d_info, cv_value, ck_user, ct_change)\n" +
                        "    select t.ck_id, t.ck_account, t.ck_d_info, t.cv_value, t.ck_user, t.ct_change::timestamp from (\n");
                    isNotFirst = true;
                }
                account.write(new AccountInfo_1.AccountInfo(row).toRow());
            });
            res.stream.on("error", (err) => reject(err));
            res.stream.on("end", () => {
                if (isNotFirst) {
                    account.write(") as t \n" +
                        " join s_at.t_d_info inf\n" +
                        " on t.ck_d_info = inf.ck_id\n" +
                        "on conflict on constraint cin_u_account_info_1 do update set ck_id = excluded.ck_id, ck_account = excluded.ck_account, ck_d_info = excluded.ck_d_info, cv_value = excluded.cv_value, ck_user = excluded.ck_user, ct_change = excluded.ct_change;\n");
                }
                resolve();
            });
        }));
        await Utils_1.closeFsWriteStream(account);
    }
    return Utils_1.createChangeXml(path.join(meta, "auth.xml"), include.map((str) => `        <include file="./auth/${str}.sql" />\n`));
}
exports.patchAuth = patchAuth;
