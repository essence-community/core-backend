"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path = require("path");
function createWriteStream(dir, name) {
    const stream = fs.createWriteStream(path.join(dir, name + ".sql"));
    stream.write("--liquibase formatted sql\n");
    stream.write(`--changeset patcher-core:${name} dbms:postgresql runOnChange:true splitStatements:false stripComments:false\n`);
    return stream;
}
exports.createWriteStream = createWriteStream;
function closeFsWriteStream(stream) {
    return new Promise((resolve, reject) => {
        stream.end((err) => {
            if (err) {
                return reject(err);
            }
            stream.close();
            resolve();
        });
    });
}
exports.closeFsWriteStream = closeFsWriteStream;
function createChangeXml(pathFile, include) {
    return new Promise((resolve, reject) => {
        fs.writeFile(pathFile, '<?xml version="1.0" encoding="UTF-8"?>\n' +
            "<databaseChangeLog\n" +
            '  xmlns="http://www.liquibase.org/xml/ns/dbchangelog"\n' +
            '  xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n' +
            '  xsi:schemaLocation="http://www.liquibase.org/xml/ns/dbchangelog\n' +
            '         http://www.liquibase.org/xml/ns/dbchangelog/dbchangelog-3.1.xsd">\n' +
            include.join("") +
            "\n</databaseChangeLog>", (err) => {
            if (err) {
                return reject(err);
            }
            resolve();
        });
    });
}
exports.createChangeXml = createChangeXml;
