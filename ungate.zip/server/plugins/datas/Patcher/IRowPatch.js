"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const moment = require("moment");
class IRowPatch {
    constructor(row) {
        this.row = row;
    }
    toStringOrNull(key, defaultValue = "null") {
        const val = this.row[key];
        return Util_1.isEmpty(val) ? defaultValue : `'${val.replace(/'/g, "''")}'`;
    }
    toTimestamp(key) {
        const val = this.row[key];
        return Util_1.isEmpty(val)
            ? "null"
            : `'${moment(val).format("YYYY-MM-DDTHH:mm:ss.SSSZZ")}'`;
    }
}
exports.IRowPatch = IRowPatch;
