"use strict";
const Patcher_1 = require("./Patcher");
module.exports = Patcher_1.Patcher;
