"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const zip = require("adm-zip");
const AWS = require("aws-sdk");
const fs = require("fs");
const lodash_1 = require("lodash");
const mime_1 = require("mime");
const Path = require("path");
class ModuleStorage extends NullPlugin_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_1.initParams(ModuleStorage.getParamsInfo(), params);
        if (this.params.cvTypeStorage === "dir") {
            this.saveFile = this.saveFileDir.bind(this);
            this.deletePath = this.deletePathDir.bind(this);
            return;
        }
        const credentials = new AWS.Credentials({
            accessKeyId: this.params.cvS3KeyId,
            secretAccessKey: this.params.cvS3SecretKey,
        });
        if (this.params.cvTypeStorage === "riak") {
            const endpoint = new AWS.Endpoint("http://s3.amazonaws.com");
            const config = {
                apiVersion: "2006-03-01",
                credentials,
                endpoint,
                httpOptions: {
                    proxy: this.params.cvPath,
                },
                region: "us-east-1",
                s3DisableBodySigning: true,
                s3ForcePathStyle: true,
                signatureVersion: "v2",
                sslEnabled: false,
            };
            this.clients = new AWS.S3(new AWS.Config(config));
        }
        else {
            const endpoint = new AWS.Endpoint(this.params.cvPath);
            const config = {
                credentials,
                endpoint,
            };
            this.clients = new AWS.S3(new AWS.Config(config));
        }
    }
    static getParamsInfo() {
        return {
            cvTypeStorage: {
                defaultValue: "riak",
                name: "Тип хранилища: dir|aws|riak",
                type: "string",
                required: true,
            },
            cvPath: {
                name: "Адрес Riak|Dir|Aws",
                type: "string",
                required: true,
            },
            cvS3Bucket: {
                name: "Наименование корзины s3",
                type: "string",
            },
            cvS3KeyId: {
                name: "Id key S3 Storage",
                type: "string",
            },
            cvS3SecretKey: {
                name: "Id key S3 Storage",
                type: "password",
            },
        };
    }
    async beforeQueryExecutePerform(gateContext, PRequestContext, query) {
        if (gateContext.actionName === "upload") {
            if (Util_1.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            if (!lodash_1.isObject(gateContext.request.body)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require file body`));
            }
            const rows = [];
            const json = JSON.parse(query.inParams.json);
            lodash_1.forEach(gateContext.request.body, (val) => {
                if (val && val.length) {
                    val.forEach((value) => {
                        rows.push(this.extractZip(gateContext, json, value, query));
                    });
                }
            });
            return Promise.all(rows).then(() => undefined);
        }
        else if (gateContext.actionName === "dml") {
            if (Util_1.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            const json = JSON.parse(query.inParams.json);
            if (json.service.cv_action.toUpperCase() === "D") {
                return this.deletePath(`/${json.data.cv_name}/${json.data.cv_version}`);
            }
        }
        return;
    }
    async extractZip(gateContext, json, file, query) {
        const fileZip = new zip(file.path);
        const configStr = fileZip.readAsText("config.json");
        if (Util_1.isEmpty(configStr)) {
            throw new ErrorException_1.default(1000, "Not found config.json");
        }
        const config = JSON.parse(configStr);
        const rows = [];
        await this.deletePath(`/${config.name}/${config.version}`).catch((err) => {
            this.logger.error(err);
            return Promise.resolve();
        });
        config.files.forEach((item) => {
            rows.push(this.saveFile(`/${config.name}/${config.version}${item}`, fileZip.readFile(item.substr(1)), mime_1.getType(item.replace(/^.*\./, ""))));
        });
        rows.push(this.saveFile(`/${config.name}/${config.version}/module.zip`, fs.createReadStream(file.path), file.headers["content-type"], file.size));
        json.data.cv_name = config.name;
        json.data.cv_version = config.version;
        json.data.cv_version_api = config.versionapi;
        json.data.cc_manifest = fileZip.readAsText(config.manifest.substr(1));
        json.data.cc_config = configStr;
        query.inParams.json = JSON.stringify(json);
        return Promise.all(rows);
    }
    saveFile(path, buffer, content, size = Buffer.byteLength(buffer)) {
        return new Promise((resolve, reject) => {
            this.clients.putObject({
                Body: buffer,
                Bucket: this.params.cvS3Bucket,
                ContentLength: size,
                ContentType: content,
                ACL: "public-read",
                Key: path,
            }, (err) => {
                if (err) {
                    return reject(err);
                }
                resolve();
            });
        });
    }
    saveFileDir(path, buffer, content, size = Buffer.byteLength(buffer)) {
        return new Promise((resolve, reject) => {
            const param = this.params;
            const dir = Path.dirname(`${param.cvPath}${path}`);
            if (!fs.existsSync(dir)) {
                fs.mkdirSync(dir, {
                    recursive: true,
                });
            }
            if (buffer.pipe) {
                const ws = fs.createWriteStream(`${param.cvPath}${path}`);
                ws.on("error", (err) => reject(err));
                buffer.on("error", (err) => reject(err));
                buffer.on("end", () => resolve());
                buffer.pipe(ws);
                return;
            }
            fs.writeFile(`${param.cvPath}${path}`, buffer, (err) => {
                if (err) {
                    reject(err);
                }
                resolve();
            });
        });
    }
    deletePath(path) {
        return new Promise((resolve, reject) => {
            this.clients.headObject({
                Bucket: this.params.cvS3Bucket,
                Key: path,
            }, (er) => {
                if (er) {
                    this.logger.debug(er);
                    return resolve();
                }
                this.clients.deleteObject({
                    Bucket: this.params.cvS3Bucket,
                    Key: path,
                }, (err) => {
                    if (err) {
                        return reject(err);
                    }
                    return resolve();
                });
            });
        });
    }
    deletePathDir(path) {
        return new Promise((resolve, reject) => {
            const param = this.params;
            const file = `${param.cvPath}${path}`;
            if (!fs.existsSync(file)) {
                return resolve();
            }
            fs.unlink(file, (err) => {
                if (err) {
                    return reject(err);
                }
                resolve();
            });
        });
    }
}
exports.default = ModuleStorage;
