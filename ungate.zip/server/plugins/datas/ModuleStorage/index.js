"use strict";
const ModuleStorage_1 = require("./ModuleStorage");
module.exports = ModuleStorage_1.default;
