"use strict";
const PrepareQuery_1 = require("./PrepareQuery");
module.exports = PrepareQuery_1.default;
