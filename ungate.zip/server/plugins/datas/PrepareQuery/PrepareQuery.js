"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const re = /^[A-z0-9_$]{2,30}$/;
const PATTERN_FILTER = /\/\x2a\s*##\s*([^\s|\x2a]+)/gi;
const FILTER_PREFIX = "cf_filter_";
const DIRECTIONS = ["DESC", "ASC"];
class PrepareQuery extends NullPlugin_1.default {
    constructor(name, params) {
        super(name, params);
    }
    afterInitQueryPerform(gateContext, PRequestContext, query) {
        return new Promise((resolve) => {
            if (Util_1.isEmpty(query.queryStr)) {
                return resolve();
            }
            const self = this;
            let matcher = PATTERN_FILTER.exec(query.queryStr);
            let removeBlock = [];
            let vlSort;
            let vlFilter;
            if (matcher) {
                do {
                    removeBlock.push(matcher[1]);
                    matcher = PATTERN_FILTER.exec(query.queryStr);
                } while (matcher);
            }
            if (query.inParams.json) {
                const json = JSON.parse(query.inParams.json);
                removeBlock = removeBlock.filter((item) => !this.deepFindCheck(json, item));
                const { filter = {} } = json;
                const jnFetch = filter.jn_fetch;
                const jnOffset = filter.jn_offset;
                const jlFilter = filter.jl_filter;
                const jlSort = filter.jl_sort;
                if (gateContext.isDebugEnabled()) {
                    gateContext.debug(`jl_filter: ${jlFilter || ""}\njl_sort: ${jlSort ||
                        ""}`);
                }
                if (!Util_1.isEmpty(jnFetch)) {
                    query.applyMacro("&FETCH", jnFetch);
                }
                if (!Util_1.isEmpty(jnOffset)) {
                    query.applyMacro("&OFFSET", jnOffset);
                }
                if (!Util_1.isEmpty(jlFilter)) {
                    vlFilter = "1 = 1";
                    jlFilter.forEach((item) => {
                        const { datatype, format, property } = item;
                        let { operator, value } = item;
                        if (Util_1.isEmpty(property) || !re.test(property)) {
                            return true;
                        }
                        if (Util_1.isEmpty(operator)) {
                            return true;
                        }
                        operator = operator.toLowerCase();
                        let nmColumn = property.toUpperCase();
                        let key = `${FILTER_PREFIX}${property.toLowerCase()}`;
                        let param;
                        let ind = 0;
                        if (Util_1.isEmpty(value)) {
                            return true;
                        }
                        while (Object.prototype.hasOwnProperty.call(query.inParams, key)) {
                            key = `${FILTER_PREFIX}${property.toLowerCase()}_${ind}`;
                            ind += 1;
                        }
                        switch (operator) {
                            case "gt":
                            case ">":
                                if (datatype === "date" ||
                                    nmColumn.startsWith("CD") ||
                                    nmColumn.startsWith("CT")) {
                                    operator = ">=";
                                }
                                else {
                                    operator = ">";
                                }
                                break;
                            case "ge":
                                operator = ">=";
                                break;
                            case "lt":
                            case "<":
                                if (datatype === "date" ||
                                    nmColumn.startsWith("CD") ||
                                    nmColumn.startsWith("CT")) {
                                    operator = "<=";
                                }
                                else {
                                    operator = "<";
                                }
                                break;
                            case "le":
                                operator = "<=";
                                break;
                            case "eq":
                                operator = "=";
                                break;
                            case "like":
                                if (!value ||
                                    value === "" ||
                                    typeof value !== "string") {
                                    return true;
                                }
                                nmColumn = `UPPER(${nmColumn})`;
                                value = `%${value.toUpperCase()}%`;
                                break;
                            case "in":
                            case "not in": {
                                if (!value || value.length === 0) {
                                    return true;
                                }
                                let vlValue = "";
                                for (let i = 0; i < value.length; i += 1) {
                                    vlValue = `${vlValue},:${key}_${i}`;
                                }
                                param = `(${vlValue.substr(1)})`;
                                break;
                            }
                            case "=":
                            case "<=":
                            case ">=":
                                break;
                            default: {
                                return true;
                            }
                        }
                        self.toSqlValue(gateContext, query.inParams, value, property.toLowerCase(), key);
                        if (!param) {
                            param = `:${key}`;
                        }
                        if (datatype === "date" && gateContext.connection) {
                            if (gateContext.connection.name === "oracle") {
                                nmColumn = this.dateTruncOracle(nmColumn, format);
                                param = this.dateTruncOracle(param, format);
                            }
                            else if (gateContext.connection.name === "postgresql") {
                                nmColumn = this.dateTruncPostgreSQL(nmColumn, format);
                                param = this.dateTruncPostgreSQL(param, format);
                            }
                        }
                        vlFilter = `${vlFilter} and ${nmColumn} ${operator} ${param}`;
                        return true;
                    });
                }
                if (!Util_1.isEmpty(jlSort)) {
                    vlSort = "";
                    jlSort.forEach((item) => {
                        const { property, direction } = item;
                        if (Util_1.isEmpty(property) || !re.test(property)) {
                            return true;
                        }
                        if (Util_1.isEmpty(direction) ||
                            !DIRECTIONS.includes(direction.toUpperCase())) {
                            return true;
                        }
                        vlSort = `${vlSort}, ${property.toUpperCase()} ${direction.toUpperCase()}`;
                        return true;
                    });
                    if (vlSort.length <= 2) {
                        vlSort = null;
                    }
                    else {
                        vlSort = vlSort.substr(2);
                    }
                }
            }
            if (Util_1.isEmpty(vlSort)) {
                vlSort = "1";
            }
            if (Util_1.isEmpty(vlFilter)) {
                vlFilter = "1 = 1";
            }
            query.applyMacro("&SORT", vlSort);
            query.applyMacro("&FILTER", vlFilter);
            removeBlock.forEach((item) => {
                query.applyMacro(`/\x5c*\x5cs*##\x5cs*${item}\x5cs*\x5c*[\x5cs\x5cS]*?${item}\x5cs*##\x5cs*\x5c*/`, "");
            });
            if (gateContext.isDebugEnabled()) {
                gateContext.debug(`jl_filter: ${vlFilter}\n` +
                    `inParam: ${JSON.stringify(query.inParams)}\njl_sort: ${vlSort}\n${query.queryStr}`);
            }
            return resolve();
        });
    }
    toSqlValue(gateContext, inParam, value, column, param) {
        if (typeof value === "string") {
            if (column.startsWith("cd") ||
                column.startsWith("ct") ||
                column.startsWith("dt")) {
                inParam[param] = gateContext.provider.dateInParams(value);
            }
            else {
                inParam[param] = value;
            }
        }
        else if (typeof value === "boolean") {
            inParam[param] = value ? 1 : 0;
        }
        else if (Array.isArray(value)) {
            value.forEach((val, index) => {
                inParam[`${param}_${index}`] = val;
            });
        }
        else {
            inParam[param] = value;
        }
    }
    deepFindCheck(obj, path) {
        const paths = path.split(".");
        let current = obj;
        for (const val of paths) {
            if (current[val] === undefined || current[val] === null) {
                return false;
            }
            current = current[val];
        }
        return true;
    }
    dateTruncOracle(name, format) {
        switch (format) {
            case "1":
                return `trunc(${name}, 'YEAR')`;
            case "2":
                return `trunc(${name}, 'MONTH')`;
            case "3":
                return `trunc(${name}, 'DDD')`;
            case "4":
                return `trunc(${name}, 'HH')`;
            case "5":
                return `trunc(${name}, 'MI')`;
            case "6":
                return `${name}`;
            default:
                return `trunc(${name}, 'DDD')`;
        }
    }
    dateTruncPostgreSQL(name, format) {
        switch (format) {
            case "1":
                return `date_trunc('year', ${name}::timestamp)`;
            case "2":
                return `date_trunc('month', ${name}::timestamp)`;
            case "3":
                return `date_trunc('day', ${name}::timestamp)`;
            case "4":
                return `date_trunc('hour', ${name}::timestamp)`;
            case "5":
                return `date_trunc('minute', ${name}::timestamp)`;
            case "6":
                return `date_trunc('second', ${name}::timestamp)`;
            default:
                return `date_trunc('day', ${name}::timestamp)`;
        }
    }
}
exports.default = PrepareQuery;
