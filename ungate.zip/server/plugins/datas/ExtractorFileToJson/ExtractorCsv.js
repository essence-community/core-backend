"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const Сsv = require("fast-csv");
const fs = require("fs");
const lodash_1 = require("lodash");
const Utils_1 = require("./Utils");
class ExtractorCsv extends events_1.EventEmitter {
    constructor(path, packRows, options = {
        encoding: "utf-8",
        objectMode: true,
    }) {
        super();
        this.pack = [];
        this.isEventRead = false;
        this.flag = 0;
        this.packRows = packRows;
        const fileStream = lodash_1.isString(path)
            ? fs.createReadStream(path)
            : path;
        this.csv = Сsv.parse(options);
        this.csv.on("end", () => {
            if (this.pack.length) {
                this.emit("pack", [...this.pack]);
            }
        });
        fileStream.pipe(this.csv);
    }
    on(event, listener) {
        super.on(event, listener);
        if (event === "pack") {
            if (!this.isEventRead) {
                this.bindParseRow = (row) => this.parseRow(this, row);
                this.csv.on("data", this.bindParseRow);
                this.isEventRead = true;
            }
            this.flag += 1;
        }
        else if (event !== "data") {
            this.csv.on(event, listener);
        }
        return this;
    }
    removeListener(event, listener) {
        super.removeListener(event, listener);
        if (event === "pack") {
            this.flag -= 1;
            if (this.flag === 0) {
                this.csv.removeListener("data", this.bindParseRow);
                this.isEventRead = false;
            }
        }
        return this;
    }
    pause() {
        this.csv.pause();
    }
    resume() {
        this.csv.resume();
    }
    parseRow(self, row) {
        const rowData = {};
        (row || []).forEach((item, index) => {
            rowData[Utils_1.getColumnName(index + 1)] = item;
        });
        self.pack.push(rowData);
        if (self.pack.length >= self.packRows) {
            self.emit("pack", [...self.pack]);
            self.pack = [];
        }
    }
}
exports.ExtractorCsv = ExtractorCsv;
