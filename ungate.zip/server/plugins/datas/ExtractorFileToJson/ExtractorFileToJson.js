"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const BreakException_1 = require("@ungate/plugininf/lib/errors/BreakException");
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const fs = require("fs");
const lodash_1 = require("lodash");
const uuidv4_1 = require("uuidv4");
const DirStorage_1 = require("./DirStorage");
const ExtractorCsv_1 = require("./ExtractorCsv");
const ExtractorDbf_1 = require("./ExtractorDbf");
const ExtractorXlsx_1 = require("./ExtractorXlsx");
const S3Storage_1 = require("./S3Storage");
class ExtractorFileToJson extends NullPlugin_1.default {
    constructor(name, params) {
        super(name, params);
        this.saveFile = (path, buffer, content, metaData, size) => Promise.resolve();
        this.deletePath = (path) => Promise.resolve();
        this.getFile = (key) => Promise.resolve({});
        this.params = Util_2.initParams(ExtractorFileToJson.getParamsInfo(), params);
        if (Util_2.isEmpty(this.params.cvTypeStorage)) {
            return;
        }
        if (this.params.cvTypeStorage === "dir") {
            const storage = new DirStorage_1.DirStorage(this.params, this.logger);
            this.saveFile = storage.saveFile.bind(storage);
            this.deletePath = storage.deletePath.bind(storage);
            this.getFile = storage.getFile.bind(storage);
            return;
        }
        const s3storage = new S3Storage_1.S3Storage(this.params, this.logger);
        this.saveFile = s3storage.saveFile.bind(s3storage);
        this.deletePath = s3storage.deletePath.bind(s3storage);
        this.getFile = s3storage.getFile.bind(s3storage);
    }
    static getParamsInfo() {
        return {
            cvTypeStorage: {
                defaultValue: "riak",
                name: "Тип хранилища: dir|aws|riak",
                type: "string",
            },
            cvPath: {
                name: "Адрес Riak|Dir|Aws",
                type: "string",
            },
            cvS3Bucket: {
                name: "Наименование корзины s3",
                type: "string",
            },
            cvS3KeyId: {
                name: "Id key S3 Storage",
                type: "string",
            },
            cvS3SecretKey: {
                name: "Secret key S3 Storage",
                type: "password",
            },
            cnRowSize: {
                name: "Колличество строк при вызове",
                type: "integer",
                defaultValue: 500000,
            },
            clS3ReadPublic: {
                defaultValue: false,
                name: "Устанавливать права доступа public, добавляемым файлам в riak/aws",
                type: "boolean",
            },
            cvCsvDelimiter: {
                defaultValue: ";",
                name: "Разделитель колонок csv",
                type: "string",
            },
        };
    }
    async beforeQueryExecutePerform(gateContext, PRequestContext, query) {
        if (gateContext.actionName === "upload") {
            if (Util_2.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            if (!lodash_1.isObject(gateContext.request.body)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require file body`));
            }
            const rows = [];
            const json = JSON.parse(query.inParams.json);
            lodash_1.forEach(gateContext.request.body, (val) => {
                if (val && val.length) {
                    val.forEach((value) => {
                        rows.push(this.extract(gateContext, json, value, query));
                    });
                }
            });
            return Promise.all(rows).then(async (values) => ({
                data: ResultStream_1.default(values.reduce((obj, arr) => [...obj, ...arr], [])),
                type: "success",
            }));
        }
        else if (gateContext.actionName === "dml") {
            if (Util_2.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            const json = JSON.parse(query.inParams.json);
            if (json.service.cv_action.toUpperCase() === "D") {
                await this.deletePath(json.data.cv_file_guid);
                return;
            }
            else {
                const file = await this.getFile(json.data.cv_file_guid);
                const values = await this.extract(gateContext, json, file, query, false);
                fs.unlinkSync(file.path);
                return {
                    data: ResultStream_1.default(values),
                    type: "success",
                };
            }
        }
        return;
    }
    async extract(gateContext, json, file, query, isSave = true) {
        const cvFileUuid = json.data.cv_file_guid || uuidv4_1.uuid();
        if (isSave) {
            await this.saveFile(cvFileUuid, fs.createReadStream(file.path), file.headers["content-type"], {
                originalFilename: file.originalFilename,
            }, file.size);
        }
        const newJson = {
            ...json,
            data: {
                ...json.data,
                cv_file_guid: cvFileUuid,
                cv_file_mime: file.headers["content-type"],
                cv_file_name: file.originalFilename,
            },
        };
        if (file.originalFilename.toLowerCase().endsWith(".csv") ||
            file.headers["content-type"] === "text/csv" ||
            file.headers["content-type"] === "application/csv") {
            return this.parseCsv(gateContext, newJson, file, query);
        }
        if (file.originalFilename.toLowerCase().endsWith(".xlsx") ||
            file.headers["content-type"] ===
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet") {
            return this.parseXlsx(gateContext, newJson, file, query);
        }
        if (file.originalFilename.toLowerCase().endsWith(".dbf") ||
            file.headers["content-type"] === "application/dbase" ||
            file.headers["content-type"] === "application/dbf" ||
            file.headers["content-type"] === "application/x-dbf") {
            return this.parseDbf(gateContext, newJson, file, query);
        }
        throw new ErrorException_1.default(-1, `Неизвестный формат файла ${file.originalFilename} mime ${file.headers["content-type"]}`);
    }
    parseCsv(gateContext, json, file, query) {
        return new Promise((resolve, reject) => {
            let result = [];
            const extractCsv = new ExtractorCsv_1.ExtractorCsv(file.path, this.params.cnRowSize, {
                encoding: json.data.cv_file_encoding || "utf-8",
                escape: json.data.cv_csv_escape || '"',
                delimiter: json.data.cv_csv_delimiter ||
                    this.params.cvCsvDelimiter,
                quote: Object.prototype.hasOwnProperty.call(json.data, "cv_csv_quote")
                    ? json.data.cv_csv_quote
                    : '"',
                objectMode: true,
                ignoreEmpty: json.data.cv_csv_ignore_empty || false,
            });
            const queues = [];
            let numPack = -1;
            extractCsv.on("error", (err) => reject(err));
            extractCsv.on("end", () => Promise.all(queues)
                .then(() => resolve(result))
                .catch((e) => reject(e)));
            extractCsv.on("pack", (pack) => {
                extractCsv.pause();
                queues.push(this.readSheet(gateContext, json, pack, query, 1, (numPack += 1)).then((res) => {
                    result = [...result, ...res];
                    extractCsv.resume();
                    return res;
                }, (err) => {
                    extractCsv.emit("error", err);
                    extractCsv.resume();
                    throw err;
                }));
            });
        });
    }
    parseXlsx(gateContext, json, file, query) {
        return new Promise((resolve, reject) => {
            let result = [];
            const extractorXlsx = new ExtractorXlsx_1.ExtractorXlsx(file.path, this.params.cnRowSize);
            const queues = [];
            let numPack = -1;
            extractorXlsx.on("error", (err) => reject(err));
            extractorXlsx.on("end", () => Promise.all(queues)
                .then(() => resolve(result))
                .catch((e) => reject(e)));
            extractorXlsx.on("pack", (pack, id) => {
                extractorXlsx.pause();
                queues.push(this.readSheet(gateContext, json, pack, query, id, (numPack += 1)).then((res) => {
                    result = [...result, ...res];
                    extractorXlsx.resume();
                    return res;
                }, (err) => {
                    extractorXlsx.emit("error", err);
                    extractorXlsx.resume();
                    throw err;
                }));
            });
            extractorXlsx.process();
        });
    }
    parseDbf(gateContext, json, file, query) {
        return new Promise((resolve, reject) => {
            let result = [];
            const queues = [];
            let numPack = -1;
            const extractorDbf = new ExtractorDbf_1.ExtractorDbf(file.path, this.params.cnRowSize, json.data.cv_file_encoding || "utf-8");
            extractorDbf.on("error", (err) => reject(err));
            extractorDbf.on("end", () => Promise.all(queues)
                .then(() => resolve(result))
                .catch((e) => reject(e)));
            extractorDbf.on("pack", (pack) => {
                extractorDbf.pause();
                queues.push(this.readSheet(gateContext, json, pack, query, 1, (numPack += 1)).then((res) => {
                    result = [...result, ...res];
                    extractorDbf.resume();
                    return res;
                }, (err) => {
                    extractorDbf.emit("error", err);
                    extractorDbf.resume();
                    throw err;
                }));
            });
        });
    }
    readSheet(gateContext, json, pack, query, index = 1, numPack = 0) {
        if (this.logger.isDebugEnabled()) {
            this.logger.debug("Num sheet: %s, Num pack: %s\nPack: %j", index, numPack, pack);
        }
        query.inParams.json = JSON.stringify({
            ...json,
            data: {
                ...json.data,
                sheet_index: index,
                extract_rows: pack,
                num_pack: numPack,
            },
        });
        return this.callRows(gateContext, query, index, numPack);
    }
    callRows(gateContext, query, index, numPack) {
        return gateContext.provider
            .processDml(gateContext, query)
            .then((res) => Util_1.ReadStreamToArray(res.stream))
            .then((arr) => {
            if (this.logger.isDebugEnabled()) {
                this.logger.debug("Num sheet: %s, Num pack: %s\nResult: %j", index, numPack, arr);
            }
            const [row] = arr;
            if (row && row.result) {
                try {
                    const result = lodash_1.isObject(row.result)
                        ? row.result
                        : JSON.parse(row.result);
                    if (!Util_2.isEmpty(result.cv_error)) {
                        throw new BreakException_1.default({
                            data: ResultStream_1.default(arr),
                            type: "success",
                        });
                    }
                }
                catch (e) {
                    gateContext.error(`Parse error: ${row.result}\n${e.message}`, e);
                }
            }
            return arr;
        });
    }
}
exports.default = ExtractorFileToJson;
