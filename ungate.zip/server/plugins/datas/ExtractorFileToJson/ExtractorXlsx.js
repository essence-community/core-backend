"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const fs = require("fs");
const lodash_1 = require("lodash");
const XlsxStreamReader = require("xlsx-stream-reader");
const TIMEOUT = 1000;
class ExtractorXlsx extends events_1.EventEmitter {
    constructor(path, packRows) {
        super();
        this.pack = [];
        this.isEnd = false;
        this.flag = 0;
        this.worksheets = [];
        this.packRows = packRows;
        const fileStream = lodash_1.isString(path)
            ? fs.createReadStream(path)
            : path;
        this.xlsx = new XlsxStreamReader();
        this.xlsx.on("worksheet", (worksheet) => {
            this.worksheets.push(worksheet);
            this.worksheets.sort((a, b) => {
                return a.id - b.id;
            });
        });
        this.xlsx.on("end", () => {
            this.isEnd = true;
        });
        fileStream.pipe(this.xlsx);
    }
    on(event, listener) {
        super.on(event, listener);
        if (event === "pack") {
            this.bindParseRow = (row) => this.parseRow(this, row);
            if (this.flag === 0 &&
                this.worksheet &&
                !this.worksheet.isRowParse) {
                this.worksheet.on("row", this.bindParseRow);
            }
            this.flag += 1;
        }
        else if (event !== "row" && event !== "end") {
            this.xlsx.on(event, listener);
        }
        return this;
    }
    process() {
        this.worksheet = this.worksheets[0];
        if (this.worksheet) {
            this.worksheet.on("row", this.bindParseRow);
            this.worksheet.on("error", (err) => this.emit("error", err));
            this.worksheet.isRowParse = true;
            this.worksheet.on("end", () => {
                this.worksheets = this.worksheets.filter((w) => this.worksheet.id !== w.id);
                if (this.pack.length) {
                    this.emit("pack", [...this.pack], this.worksheet.id);
                    this.pack = [];
                }
                this.process();
            });
            this.worksheet.process();
        }
        else if (this.isEnd && this.worksheets.length === 0) {
            this.emit("end");
        }
        else {
            setTimeout(() => this.process(), TIMEOUT);
        }
    }
    removeListener(event, listener) {
        super.removeListener(event, listener);
        if (event === "pack") {
            this.flag -= 1;
            if (this.flag === 0) {
                this.worksheet.removeListener("row", this.bindParseRow);
                this.worksheet.isRowParse = false;
            }
        }
        return this;
    }
    pause() {
        if (this.worksheet) {
            this.worksheet.workSheetStream.pause();
        }
    }
    resume() {
        if (this.worksheet) {
            this.worksheet.workSheetStream.resume();
        }
    }
    parseRow(self, row) {
        try {
            const rowData = {};
            row.values.forEach((val, index) => {
                rowData[self.worksheet.getColumnName(index)] = val;
            });
            self.pack.push(rowData);
            if (self.pack.length >= self.packRows) {
                self.emit("pack", [...self.pack], self.worksheet.id);
                self.pack = [];
            }
        }
        catch (e) {
            self.emit("error", e);
        }
    }
}
exports.ExtractorXlsx = ExtractorXlsx;
