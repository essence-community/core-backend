"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const AWS = require("aws-sdk");
const fs = require("fs");
const os = require("os");
const path = require("path");
const uuidv4_1 = require("uuidv4");
class S3Storage {
    constructor(params, logger) {
        this.UPLOAD_DIR = process.env.GATE_UPLOAD_DIR || os.tmpdir();
        const credentials = new AWS.Credentials({
            accessKeyId: this.params.cvS3KeyId,
            secretAccessKey: this.params.cvS3SecretKey,
        });
        if (this.params.cvTypeStorage === "riak") {
            const endpoint = new AWS.Endpoint("http://s3.amazonaws.com");
            const config = {
                apiVersion: "2006-03-01",
                credentials,
                endpoint,
                httpOptions: {
                    proxy: this.params.cvPath,
                },
                region: "us-east-1",
                s3DisableBodySigning: true,
                s3ForcePathStyle: true,
                signatureVersion: "v2",
                sslEnabled: false,
            };
            this.clients = new AWS.S3(new AWS.Config(config));
        }
        else {
            const endpoint = new AWS.Endpoint(this.params.cvPath);
            const config = {
                credentials,
                endpoint,
            };
            this.clients = new AWS.S3(new AWS.Config(config));
        }
    }
    saveFile(key, buffer, content, Metadata = {}, size = buffer.pipe
        ? Buffer.byteLength(buffer)
        : undefined) {
        return new Promise((resolve, reject) => {
            this.clients.putObject({
                ...(this.params.clS3ReadPublic
                    ? { ACL: "public-read" }
                    : {}),
                Body: buffer,
                Bucket: this.params.cvS3Bucket,
                ContentLength: size,
                ContentType: content,
                Key: key,
                Metadata,
            }, (err) => {
                if (err) {
                    return reject(err);
                }
                resolve();
            });
        });
    }
    deletePath(key) {
        return new Promise((resolve, reject) => {
            this.clients.headObject({
                Bucket: this.params.cvS3Bucket,
                Key: key,
            }, (er) => {
                if (er) {
                    this.logger.debug(er);
                    return resolve();
                }
                this.clients.deleteObject({
                    Bucket: this.params.cvS3Bucket,
                    Key: key,
                }, (err) => {
                    if (err) {
                        return reject(err);
                    }
                    return resolve();
                });
            });
        });
    }
    getFile(key) {
        return new Promise((resolve, reject) => {
            this.clients.getObject({
                Bucket: this.params.cvBucket,
                Key: key,
            }, (err, response) => {
                if (err) {
                    return reject(err);
                }
                const filePath = path.join(this.UPLOAD_DIR, uuidv4_1.uuid());
                fs.writeFile(filePath, response.Body, (er) => {
                    if (er) {
                        return reject(er);
                    }
                    resolve({
                        fieldName: "upload",
                        headers: {
                            "content-type": response.ContentType,
                        },
                        originalFilename: response.Metadata &&
                            response.Metadata.originalFilename,
                        path: filePath,
                        size: response.ContentLength,
                    });
                });
            });
        });
    }
}
exports.S3Storage = S3Storage;
