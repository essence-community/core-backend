"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const ENGLISH_ALPHABET_LENGTH = 26;
const NUM_AND_ENGLISH_ALPHABET_LENGTH = 36;
exports.getColumnNumber = (columnName) => {
    let i = columnName.search(/\d/);
    let colNum = 0;
    columnName.replace(/\D/g, (letter) => {
        colNum +=
            (parseInt(letter, NUM_AND_ENGLISH_ALPHABET_LENGTH) - 9) *
                Math.pow(ENGLISH_ALPHABET_LENGTH, --i);
        return "";
    });
    return colNum;
};
exports.getColumnName = (columnNumber) => {
    if (Util_1.isEmpty(columnNumber)) {
        return "";
    }
    let columnName = "";
    let dividend = typeof columnNumber === "string"
        ? parseInt(columnNumber, 10)
        : columnNumber;
    let modulo = 0;
    while (dividend > 0) {
        modulo = (dividend - 1) % ENGLISH_ALPHABET_LENGTH;
        columnName = String.fromCharCode(65 + modulo).toString() + columnName;
        dividend = Math.floor((dividend - modulo) / ENGLISH_ALPHABET_LENGTH);
    }
    return columnName;
};
