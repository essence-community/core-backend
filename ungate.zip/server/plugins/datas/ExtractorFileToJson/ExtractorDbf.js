"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const events_1 = require("events");
const ParserDbf_1 = require("./ParserDbf");
class ExtractorDbf extends events_1.EventEmitter {
    constructor(path, packRows, encoding = "utf-8") {
        super();
        this.pack = [];
        this.isEventRead = false;
        this.flag = 0;
        this.packRows = packRows;
        this.dbf = new ParserDbf_1.ParserDbf(path, encoding);
        this.dbf.on("end", () => {
            if (this.pack.length) {
                this.emit("pack", [...this.pack]);
            }
        });
    }
    on(event, listener) {
        super.on(event, listener);
        if (event === "pack") {
            if (!this.isEventRead) {
                this.bindParseRow = (row) => this.parseRow(this, row);
                this.dbf.on("record", this.bindParseRow);
                this.isEventRead = true;
                this.dbf.parse();
            }
            this.flag += 1;
        }
        else if (event !== "record") {
            this.dbf.on(event, listener);
        }
        return this;
    }
    removeListener(event, listener) {
        super.removeListener(event, listener);
        if (event === "pack") {
            this.flag -= 1;
            if (this.flag === 0) {
                this.dbf.removeListener("record", this.bindParseRow);
                this.isEventRead = false;
            }
        }
        return this;
    }
    pause() {
        this.dbf.pause();
    }
    resume() {
        this.dbf.resume();
    }
    parseRow(self, row) {
        self.pack.push(row);
        if (self.pack.length >= self.packRows) {
            self.emit("pack", [...self.pack]);
            self.pack = [];
        }
    }
}
exports.ExtractorDbf = ExtractorDbf;
