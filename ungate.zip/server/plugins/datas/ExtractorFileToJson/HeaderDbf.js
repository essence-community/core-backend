"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const fs = require("fs");
const Utils_1 = require("./Utils");
class HeaderDbf {
    constructor(filename, encoding = "utf-8") {
        this.encoding = "utf-8";
        this.filename = filename;
        this.encoding = encoding;
    }
    parse(callback) {
        fs.readFile(this.filename, (err, buffer) => {
            if (err) {
                return callback(err);
            }
            this.type = buffer.slice(0, 1).toString(this.encoding);
            this.dateUpdated = this.parseDate(buffer.slice(1, 4));
            this.numberOfRecords = this.convertBinaryToInteger(buffer.slice(4, 8));
            this.start = this.convertBinaryToInteger(buffer.slice(8, 10));
            this.recordLength = this.convertBinaryToInteger(buffer.slice(10, 12));
            const result = [];
            for (let i = 32, end = this.start - 32; i <= end; i += 32) {
                result.push(buffer.slice(i, i + 32));
            }
            this.fields = result.map((buf, index) => this.parseFieldSubRecord(buf, index));
            callback();
        });
    }
    parseDate(buffer) {
        const year = 1900 + this.convertBinaryToInteger(buffer.slice(0, 1));
        const month = this.convertBinaryToInteger(buffer.slice(1, 2)) - 1;
        const day = this.convertBinaryToInteger(buffer.slice(2, 3));
        return new Date(year, month, day);
    }
    parseFieldSubRecord(buffer, index) {
        const name = buffer
            .slice(0, 11)
            .toString(this.encoding)
            .replace(/[\u0000]+$/, "")
            .replace(/.*(\d*).*/gi, "$1");
        return {
            name: Util_1.isEmpty(name)
                ? Utils_1.getColumnName(index + 1)
                : Utils_1.getColumnName(name),
            type: buffer.slice(11, 12).toString(this.encoding),
            displacement: this.convertBinaryToInteger(buffer.slice(12, 16)),
            length: this.convertBinaryToInteger(buffer.slice(16, 17)),
            decimalPlaces: this.convertBinaryToInteger(buffer.slice(17, 18)),
        };
    }
    convertBinaryToInteger(buffer) {
        return buffer.readIntLE(0, buffer.length);
    }
}
exports.default = HeaderDbf;
