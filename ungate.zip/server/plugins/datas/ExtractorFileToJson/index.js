"use strict";
const ExtractorFileToJson_1 = require("./ExtractorFileToJson");
module.exports = ExtractorFileToJson_1.default;
