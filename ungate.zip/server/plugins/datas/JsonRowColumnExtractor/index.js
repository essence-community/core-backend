"use strict";
const JsonRowColumnExtractor_1 = require("./JsonRowColumnExtractor");
module.exports = JsonRowColumnExtractor_1.default;
