"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const stream_1 = require("stream");
class JsonRowColumnExtractor extends NullPlugin_1.default {
    static getParamsInfo() {
        return {
            columns: {
                name: "Наименоване колонок которые надо распаковать через запятую",
                type: "string",
            },
            extractSingleColumn: {
                defaultValue: false,
                name: "Признак что надо распоковать колонку если она одна",
                type: "boolean",
            },
        };
    }
    constructor(name, params) {
        super(name, params);
        this.params = Util_2.initParams(JsonRowColumnExtractor.getParamsInfo(), params);
    }
    async afterQueryExecutePerform(gateContext, PRequestContext, result) {
        if (result.type !== "success" &&
            result.type !== "error" &&
            result.type !== "false") {
            return;
        }
        const self = this;
        const columns = (this.params.columns || "").split(",");
        let columnExtract;
        const columnObjExtract = (name) => (stream, chunk, done) => {
            try {
                const obj = lodash_1.isString(chunk[name])
                    ? JSON.parse(chunk[name])
                    : chunk[name];
                if (lodash_1.isArray(obj)) {
                    obj.forEach((val) => stream.push(val));
                    done();
                    return;
                }
                delete chunk[name];
                done(null, {
                    ...chunk,
                    ...obj,
                });
            }
            catch (e) {
                gateContext.error(e.message, e);
                done(null, chunk);
            }
        };
        const columnExist = (stream, chunk, done) => {
            done(null, chunk);
        };
        const extractor = new stream_1.Transform({
            readableObjectMode: true,
            writableObjectMode: true,
            transform(chunk, encode, done) {
                if (columnExtract) {
                    columnExtract(this, chunk, done);
                    return;
                }
                if (!lodash_1.isObject(chunk)) {
                    columnExtract = columnExist;
                    columnExtract(this, chunk, done);
                    return;
                }
                if (columns.length) {
                    const res = columns.every((val) => {
                        if (Object.prototype.hasOwnProperty.call(chunk, val)) {
                            columnExtract = columnObjExtract(val);
                            columnExtract(this, chunk, done);
                            return false;
                        }
                        return true;
                    });
                    if (!res) {
                        return;
                    }
                }
                if (self.params.extractSingleColumn) {
                    const keys = Object.keys(chunk);
                    if (keys.length === 1) {
                        const val = chunk[keys[0]];
                        if ((lodash_1.isString(val) &&
                            (val.trim()[0] === "{" ||
                                val.trim()[0] === "[")) ||
                            lodash_1.isObject(val) ||
                            lodash_1.isArray(val)) {
                            columnExtract = columnObjExtract(keys[0]);
                            columnExtract(this, chunk, done);
                            return;
                        }
                    }
                }
                columnExtract = columnExist;
                columnExtract(this, chunk, done);
                return;
            },
        });
        result.data = Util_1.safePipe(result.data, extractor);
        return;
    }
}
exports.default = JsonRowColumnExtractor;
