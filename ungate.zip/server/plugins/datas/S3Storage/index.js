"use strict";
const S3Storage_1 = require("./S3Storage");
module.exports = S3Storage_1.default;
