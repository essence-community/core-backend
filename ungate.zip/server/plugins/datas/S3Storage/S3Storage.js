"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullPlugin_1 = require("@ungate/plugininf/lib/NullPlugin");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const AWS = require("aws-sdk");
const fs = require("fs");
const lodash_1 = require("lodash");
const uuidv4_1 = require("uuidv4");
class S3Storage extends NullPlugin_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_2.initParams(S3Storage.getParamsInfo(), params);
        const endpoint = new AWS.Endpoint("http://s3.amazonaws.com");
        const credentials = new AWS.Credentials({
            accessKeyId: this.params.cvKeyId,
            secretAccessKey: this.params.cvSecretKey,
        });
        const config = {
            apiVersion: "2006-03-01",
            credentials,
            endpoint,
            httpOptions: {
                proxy: this.params.cvS3Url,
            },
            region: "us-east-1",
            s3DisableBodySigning: true,
            s3ForcePathStyle: true,
            signatureVersion: "v2",
            sslEnabled: false,
        };
        this.clients = new AWS.S3(new AWS.Config(config));
    }
    static getParamsInfo() {
        return {
            clReadPublic: {
                defaultValue: false,
                name: "Выставить права на чтение для всех",
                type: "boolean",
            },
            cvBucket: {
                name: "Наименование корзины",
                required: true,
                type: "string",
            },
            cvDir: {
                name: "Папка S3 Storage",
                type: "string",
            },
            cvDirColumn: {
                defaultValue: "cv_dir",
                name: "Наименование колонки где находится наименование папки",
                type: "string",
            },
            cvKeyId: {
                name: "Id key S3 Storage",
                required: true,
                type: "string",
            },
            cvS3Url: {
                name: "Адресс S3 Storage",
                required: true,
                type: "string",
            },
            cvSecretKey: {
                name: "Id key S3 Storage",
                required: true,
                type: "password",
            },
        };
    }
    async beforeQueryExecutePerform(gateContext, PRequestContext, query) {
        if (gateContext.actionName === "upload") {
            if (Util_2.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            if (!lodash_1.isObject(gateContext.request.body)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require file body`));
            }
            const rows = [];
            const json = JSON.parse(query.inParams.json);
            lodash_1.forEach(gateContext.request.body, (val) => {
                if (val && val.length) {
                    val.forEach((value) => {
                        rows.push(this.saveFile(gateContext, json, value, query));
                    });
                }
            });
            return Promise.all(rows).then(async (values) => ({
                data: ResultStream_1.default(values.reduce((obj, arr) => [...obj, ...arr], [])),
                type: "success",
            }));
        }
        else if (gateContext.actionName === "dml") {
            if (Util_2.isEmpty(query.inParams.json)) {
                throw new ErrorException_1.default(ErrorGate_1.default.compileErrorResult(-1, `Not found require params json`));
            }
            const json = JSON.parse(query.inParams.json);
            if (json.service.cv_action.toUpperCase() === "D") {
                return new Promise((resolve, reject) => {
                    this.clients.deleteObject({
                        Bucket: this.params.cvBucket,
                        Key: Util_2.isEmpty(json.data[this.params.cvDirColumn] ||
                            this.params.cvDir)
                            ? json.data.cv_file_guid
                            : `${json.data[this.params.cvDirColumn] ||
                                this.params.cvDir}/${json.data.cv_file_guid}`,
                    }, (err) => {
                        if (err) {
                            return reject(err);
                        }
                        return resolve();
                    });
                });
            }
        }
        if (Util_2.isEmpty(query.inParams.json) &&
            (gateContext.actionName === "file" ||
                gateContext.actionName === "getfile")) {
            const json = JSON.parse(query.inParams.json);
            if (!json.data || Util_2.isEmpty(json.data.cv_file_guid)) {
                return;
            }
            return new Promise((resolve, reject) => {
                this.clients.getObject({
                    Bucket: this.params.cvBucket,
                    Key: Util_2.isEmpty(json.data[this.params.cvDirColumn] ||
                        this.params.cvDir)
                        ? json.data.cv_file_guid
                        : `${json.data[this.params.cvDirColumn] ||
                            this.params.cvDir}/${json.data.cv_file_guid}`,
                }, (err, response) => {
                    if (err) {
                        return reject(err);
                    }
                    const row = {
                        filedata: response.Body,
                        filename: json.data.cv_file_guid,
                        filetype: response.ContentType,
                    };
                    resolve({
                        data: ResultStream_1.default([row]),
                        type: "attachment",
                    });
                });
            });
        }
        return;
    }
    async afterQueryExecutePerform(gateContext, PRequestContext, result) {
        if (gateContext.actionName === "file" ||
            gateContext.actionName === "getfile") {
            const [row] = await Util_1.ReadStreamToArray(result.data);
            if (Util_2.isEmpty(row)) {
                return;
            }
            return new Promise((resolve, reject) => {
                this.clients.getObject({
                    Bucket: this.params.cvBucket,
                    Key: Util_2.isEmpty(row[this.params.cvDirColumn] || this.params.cvDir)
                        ? row.cv_file_guid
                        : `${row[this.params.cvDirColumn] ||
                            this.params.cvDir}/${row.cv_file_guid}`,
                }, (err, response) => {
                    if (err) {
                        return reject(err);
                    }
                    row.filedata = response.Body;
                    row.filetype = response.ContentType;
                    row.filename = row.cv_file_name;
                    result.data = ResultStream_1.default([row]);
                    resolve(result);
                });
            });
        }
        return;
    }
    saveFile(gateContext, json, val, query) {
        return new Promise((resolve, reject) => {
            const cvFileUuid = json.data.cv_file_guid || uuidv4_1.uuid();
            this.clients.putObject({
                Body: fs.createReadStream(val.path),
                Bucket: this.params.cvBucket,
                ContentLength: val.size,
                ContentType: val.headers["content-type"],
                Key: Util_2.isEmpty(json.data[this.params.cvDirColumn] || this.params.cvDir)
                    ? cvFileUuid
                    : `${json.data[this.params.cvDirColumn] ||
                        this.params.cvDir}/${cvFileUuid}`,
                ...(this.params.clReadPublic
                    ? {
                        ACL: "public-read",
                    }
                    : {}),
            }, (err) => {
                if (err) {
                    return reject(err);
                }
                json.data.cv_file_guid = cvFileUuid;
                json.data.cv_file_mime = val.headers["content-type"];
                json.data.cv_file_name = val.originalFilename;
                query.inParams.json = JSON.stringify(json);
                if (Util_2.isEmpty(query.queryStr)) {
                    return resolve([
                        {
                            ck_id: cvFileUuid,
                            cv_error: null,
                        },
                    ]);
                }
                return gateContext.provider
                    .processDml(gateContext, query)
                    .then((res) => Util_1.ReadStreamToArray(res.stream))
                    .then((arr) => {
                    const [row] = arr;
                    if (row && row.result) {
                        try {
                            const result = lodash_1.isObject(row.result)
                                ? row.result
                                : JSON.parse(row.result);
                            if (!Util_2.isEmpty(result.cv_error)) {
                                this.clients.deleteObject({
                                    Bucket: this.params.cvBucket,
                                    Key: Util_2.isEmpty(json.data[this.params.cvDirColumn] || this.params.cvDir)
                                        ? cvFileUuid
                                        : `${json.data[this.params
                                            .cvDirColumn] ||
                                            this.params
                                                .cvDir}/${cvFileUuid}`,
                                }, (errDelete) => {
                                    if (errDelete) {
                                        return reject(errDelete);
                                    }
                                    return resolve(arr);
                                });
                                return;
                            }
                        }
                        catch (e) {
                            gateContext.error(`Parse error: ${row.result}\n${e.message}`, e);
                        }
                    }
                    resolve(arr);
                })
                    .catch((errProvider) => reject(errProvider));
            });
        });
    }
}
exports.default = S3Storage;
