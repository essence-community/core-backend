"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const GateSession_1 = require("../../core/session/GateSession");
const NotificationController_1 = require("./NotificationController");
function default_1() {
    global.authController = {
        addUser: GateSession_1.default.addUser.bind(GateSession_1.default),
        createSession: GateSession_1.default.createSession.bind(GateSession_1.default),
        getDataUser: GateSession_1.default.getDataUser.bind(GateSession_1.default),
        getUserDb: GateSession_1.default.getUserDb.bind(GateSession_1.default),
        loadSession: GateSession_1.default.loadSession.bind(GateSession_1.default),
        updateHashAuth: GateSession_1.default.updateHashAuth.bind(GateSession_1.default),
        updateUserInfo: NotificationController_1.default.updateUserInfo.bind(NotificationController_1.default),
    };
}
exports.default = default_1;
