"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const fs = require("fs");
const lodash_1 = require("lodash");
const Constants_1 = require("../../core/Constants");
const GateSession_1 = require("../../core/session/GateSession");
const PluginController_1 = require("./PluginController");
class ActionController {
    execute(options) {
        switch (options.gateContext.actionName) {
            case "sql":
                return this.handlerSql(options);
            case "dml":
                return this.handlerDml(options);
            case "auth":
                return this.handlerAuth(options);
            case "file":
                return this.handlerFile(options);
            case "upload":
                return this.handlerUpload(options);
            case "getfile":
                return this.handlerGetFile(options);
            default:
                throw new ErrorException_1.default(ErrorGate_1.default.NOT_IMPLEMENTED);
        }
    }
    async handlerAuth({ gateContext, provider, plugins, query, }) {
        let session;
        if (gateContext.request.method.toUpperCase() !== "POST") {
            throw new ErrorException_1.default(ErrorGate_1.default.REQUIRED_POST);
        }
        const resPlugin = await PluginController_1.default.applyPluginBeforeSession(gateContext, plugins);
        if (resPlugin) {
            session = await GateSession_1.default.createSession(null, "plugin", resPlugin);
        }
        if (!session) {
            const data = await provider.processAuth(gateContext, query);
            if (gateContext.connection) {
                const conn = gateContext.connection;
                try {
                    await conn.commit();
                    await conn.release();
                }
                catch (e) {
                    conn.release().then(lodash_1.noop, lodash_1.noop);
                    gateContext.error(e);
                }
            }
            if (!data || Util_2.isEmpty(data.ck_user)) {
                throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
            }
            if (await PluginController_1.default.applyPluginBeforeSaveSession(gateContext, plugins, data)) {
                session = await provider.createSession(data.ck_user, data.data);
            }
        }
        if (!session) {
            throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
        }
        gateContext.debug(`Success authorization: ${JSON.stringify(session)}`);
        return {
            data: ResultStream_1.default([session]),
            type: "success",
        };
    }
    handlerDml({ gateContext, provider, query, }) {
        gateContext.trace("Process Dml");
        return new Promise((resolve, reject) => {
            provider
                .processDml(gateContext, query)
                .then((data) => {
                if (Object.prototype.hasOwnProperty.call(query.outParams, "EXTRACT_META_DATA")) {
                    gateContext.metaData = Util_2.isEmpty(data.metaData)
                        ? {}
                        : {
                            columnsBc: data.metaData,
                        };
                }
                resolve({ type: "success", data: data.stream });
            })
                .catch((err) => {
                gateContext.error(`${gateContext.queryName}, Dml.processDml(${query.queryStr}): ${err.message}`, err);
                return reject(err);
            });
        });
    }
    handlerSql({ gateContext, provider, query, }) {
        gateContext.trace("Process Sql");
        return new Promise((resolve, reject) => {
            provider
                .processSql(gateContext, query)
                .then((data) => {
                if (Object.prototype.hasOwnProperty.call(query.outParams, "EXTRACT_META_DATA")) {
                    gateContext.metaData = Util_2.isEmpty(data.metaData)
                        ? {}
                        : {
                            columnsBc: data.metaData,
                        };
                }
                resolve({ type: "success", data: data.stream });
            })
                .catch((err) => {
                gateContext.error(`${gateContext.queryName}, Sql.processSql(${query.queryStr}): ${err.message}`, err);
                return reject(err);
            });
        });
    }
    handlerFile({ gateContext, provider, query, }) {
        gateContext.trace("Process File");
        return new Promise((resolve, reject) => {
            provider
                .processDml(gateContext, query)
                .then((data) => {
                resolve({ type: "attachment", data: data.stream });
            })
                .catch((err) => {
                gateContext.error(`${gateContext.queryName}, File.processFile(${query.queryStr}): ${err.message}`, err);
                return reject(err);
            });
        });
    }
    handlerUpload({ gateContext, provider, query, }) {
        gateContext.trace("Process Upload");
        const result = [];
        lodash_1.forEach(gateContext.request.body, (value, key) => {
            if (value && value.length) {
                result.push(value.reduce((prom, val) => prom.then((arr) => {
                    query.inParams[key] = provider.fileInParams(fs.readFileSync(val.path, null));
                    query.inParams[`${key}${Constants_1.default.UPLOAD_FILE_NAME_SUFFIX}`] = val.originalFilename;
                    query.inParams[`${key}${Constants_1.default.UPLOAD_FILE_MIMETYPE_SUFFIX}`] = val.headers["content-type"];
                    return provider
                        .processDml(gateContext, query)
                        .then((data) => Util_1.ReadStreamToArray(data.stream))
                        .then(async (res) => arr.concat(res));
                }), Promise.resolve([])));
            }
        });
        return Promise.all(result)
            .then(async (arr) => ({
            data: ResultStream_1.default(arr && arr.length
                ? arr.reduce((ar, val) => [...ar, ...val], [])
                : []),
            type: "success",
        }))
            .catch((err) => {
            gateContext.error(`${gateContext.queryName},` +
                ` Upload.processDml(${query.queryStr}): ${err.message}`, err);
            throw err;
        });
    }
    handlerGetFile({ gateContext, provider, query, }) {
        gateContext.trace("Process GetFile");
        return new Promise((resolve, reject) => {
            provider
                .processDml(gateContext, query)
                .then((data) => {
                resolve({ type: "file", data: data.stream });
            })
                .catch((err) => {
                gateContext.error(`${gateContext.queryName},` +
                    ` GetFile.processDml(${query.queryStr}): ${err.message}`, err);
                return reject(err);
            });
        });
    }
}
exports.default = new ActionController();
