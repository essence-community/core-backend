"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const Constants_1 = require("../../core/Constants");
const PluginManager_1 = require("../../core/pluginmanager/PluginManager");
const Property_1 = require("../../core/property/Property");
const GateSession_1 = require("../../core/session/GateSession");
const WSQuery_1 = require("../../core/WSQuery");
const Mask_1 = require("../Mask");
const ActionController_1 = require("./ActionController");
const PluginController_1 = require("./PluginController");
const ResultController_1 = require("./ResultController");
class MainController {
    async init() {
        this.providerDb = await Property_1.default.getProviders();
        this.pluginDb = await Property_1.default.getPlugins();
        this.queryDb = await Property_1.default.getQuery();
    }
    async execute(requestContext) {
        try {
            if (Mask_1.default.masked) {
                this.logParams(requestContext);
                return ResultController_1.default.responseCheck(requestContext, await requestContext.gateContextPlugin.maskResult());
            }
            let session = await PluginController_1.default.applyBeforeSession(requestContext, PluginManager_1.default.getGateAuthProviders());
            if (Util_1.isEmpty(session) && requestContext.sessionId) {
                session = await GateSession_1.default.loadSession(requestContext.sessionId);
            }
            session = await PluginController_1.default.applyAfterSession(requestContext, session, PluginManager_1.default.getGateAuthProviders());
            if (session) {
                requestContext.setSession(session);
            }
            if (requestContext.queryName === Constants_1.default.QUERY_LOGOUT) {
                if (session) {
                    await GateSession_1.default.logoutSession(session.session);
                }
                return ResultController_1.default.responseCheck(requestContext, {
                    data: ResultStream_1.default([]),
                    type: "success",
                });
            }
            if (requestContext.queryName === Constants_1.default.QUERY_GETSESSIONDATA) {
                this.logParams(requestContext);
                return ResultController_1.default.responseCheck(requestContext, {
                    data: ResultStream_1.default(session
                        ? [
                            {
                                session: session.session,
                                ...session.data,
                            },
                        ]
                        : []),
                    type: "success",
                });
            }
            let query;
            const cResult = await requestContext.gateContextPlugin.initContext(requestContext);
            if (!Util_1.isEmpty(cResult.connection)) {
                requestContext.connection = cResult.connection;
            }
            if (!Util_1.isEmpty(cResult.queryName)) {
                requestContext.setQueryName(cResult.queryName);
            }
            if (!Util_1.isEmpty(cResult.pluginName)) {
                requestContext.setPluginName(cResult.pluginName);
            }
            if (!Util_1.isEmpty(cResult.providerName)) {
                requestContext.setProviderName(cResult.providerName);
            }
            if (!Util_1.isEmpty(cResult.query)) {
                query = cResult.query;
            }
            if (!Util_1.isEmpty(cResult.metaData)) {
                requestContext.metaData = cResult.metaData;
            }
            if (!Util_1.isEmpty(cResult.actionName)) {
                requestContext.setActionName(cResult.actionName);
            }
            if (!Util_1.isEmpty(cResult.defaultActionName) &&
                Util_1.isEmpty(requestContext.actionName)) {
                requestContext.setActionName(cResult.defaultActionName);
            }
            if (!Util_1.isEmpty(cResult.defaultQueryName) &&
                Util_1.isEmpty(requestContext.queryName)) {
                requestContext.setQueryName(cResult.defaultQueryName);
            }
            if (!Util_1.isEmpty(cResult.defaultProviderName) &&
                Util_1.isEmpty(requestContext.providerName)) {
                requestContext.setProviderName(cResult.defaultProviderName);
            }
            if (!Util_1.isEmpty(cResult.defaultPluginName) &&
                Util_1.isEmpty(requestContext.pluginName)) {
                requestContext.setPluginName(cResult.defaultPluginName);
            }
            if (!Util_1.isEmpty(cResult.loginQuery) &&
                requestContext.actionName === "auth") {
                requestContext.setQueryName(cResult.loginQuery);
            }
            this.logParams(requestContext);
            const provider = await this.loadProvider(requestContext);
            requestContext.setProvider(provider);
            const plugins = await this.loadPlugins(requestContext);
            try {
                query = await PluginController_1.default.applyPluginInitQueryBefore(requestContext, plugins, query);
                query = await provider.initContext(requestContext, query);
                await this.loadQueryData(requestContext, query);
                const wsQuery = new WSQuery_1.default(requestContext, query);
                requestContext.setQuery(wsQuery);
                wsQuery.prepareParams(provider);
                if (!(await requestContext.gateContextPlugin.checkQueryAccess(requestContext, wsQuery))) {
                    throw new ErrorException_1.default(ErrorGate_1.default.REQUIRED_AUTH);
                }
                await PluginController_1.default.applyPluginInitQueryAfter(requestContext, plugins, wsQuery);
                let result = await PluginController_1.default.applyPluginQueryExecuteBefore(requestContext, plugins, wsQuery);
                if (!result) {
                    result = await ActionController_1.default.execute({
                        gateContext: requestContext,
                        plugins,
                        provider,
                        query: wsQuery,
                    });
                }
                if (!requestContext.isResponded) {
                    result = await PluginController_1.default.applyPluginAfterQueryExecute(requestContext, plugins, result);
                    await ResultController_1.default.responseCheck(requestContext, result);
                }
            }
            catch (err) {
                await this.checkError(err, requestContext, plugins);
            }
        }
        catch (err) {
            await ResultController_1.default.responseCheck(requestContext, null, err);
        }
    }
    async checkError(err, requestContext, plugins) {
        const conn = requestContext.connection;
        if (conn) {
            conn.rollbackAndRelease().then(lodash_1.noop, lodash_1.noop);
        }
        const result = await PluginController_1.default.applyPluginError(requestContext, plugins, err);
        ResultController_1.default.responseCheck(requestContext, null, result).then(lodash_1.noop, lodash_1.noop);
    }
    async logParams(gateContext) {
        const param = Object.assign({}, gateContext.params);
        if (param[Constants_1.default.PASSWORD_PARAM_PREFIX]) {
            param[Constants_1.default.PASSWORD_PARAM_PREFIX] = "***";
        }
        if (param.cv_password) {
            param.cv_password = "***";
        }
        if (gateContext.session) {
            gateContext.info(`${gateContext.request.method}(${gateContext.actionName},${gateContext.queryName}` +
                `,${gateContext.providerName || ""},${JSON.stringify(param)},${JSON.stringify(gateContext.session)})`);
        }
        else {
            gateContext.info(`${gateContext.request.method}(${gateContext.actionName},${gateContext.queryName}` +
                `,${gateContext.providerName},${JSON.stringify(param)})`);
        }
    }
    async loadProvider(gateContext) {
        if (Util_1.isEmpty(gateContext.providerName)) {
            throw new ErrorException_1.default(ErrorGate_1.default.REQUIRED_PARAM);
        }
        let provider = PluginManager_1.default.getGateProvider(gateContext.providerName);
        if (provider) {
            return provider;
        }
        const config = await this.providerDb.findOne({
            ck_id: gateContext.providerName,
        }, true);
        if (!config) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        const pluginClass = PluginManager_1.default.getGateProviderClass(config.ck_d_plugin.toLowerCase());
        provider = new pluginClass(config.ck_id, config.cct_params);
        await provider.init();
        PluginManager_1.default.setGateProvider(config.ck_id, provider);
        return provider;
    }
    async loadQueryData(gateContext, query) {
        const queryDoc = await this.queryDb.findOne({
            $and: [
                {
                    cv_name: gateContext.queryName,
                },
                {
                    ck_d_provider: gateContext.providerName,
                },
                {
                    ck_d_context: gateContext.gateContextPlugin.name,
                },
            ],
        }, true);
        if (queryDoc) {
            query.extraInParams = queryDoc.cct_inParams;
            query.extraOutParams = queryDoc.cct_outParams;
        }
        return;
    }
    async loadPlugins(gateContext) {
        const configs = await this.pluginDb.find({
            $and: [
                {
                    $or: [
                        Util_1.isEmpty(gateContext.pluginName)
                            ? { cl_default: 1 }
                            : { cv_name: { $in: gateContext.pluginName } },
                        { cl_required: 1 },
                    ],
                },
                { ck_d_provider: { $in: ["all", gateContext.providerName] } },
            ],
        });
        configs.sort((val1, val2) => val1.cn_order - val2.cn_order);
        const rows = [];
        const plugins = [];
        configs.forEach((conf) => {
            let plugin = PluginManager_1.default.getGatePlugin(conf.cv_name, gateContext.providerName);
            if (plugin) {
                plugins.push({
                    context: {},
                    plugin,
                });
                return;
            }
            const pluginClass = PluginManager_1.default.getGatePluginsClass(conf.ck_d_plugin.toLowerCase());
            plugin = new pluginClass(conf.cv_name, conf.cct_params);
            plugins.push({
                context: {},
                plugin,
            });
            rows.push(plugin.init().then(() => {
                PluginManager_1.default.setGatePlugins({
                    ...conf,
                    plugin,
                });
                return Promise.resolve();
            }));
        });
        await Promise.all(rows);
        return plugins;
    }
}
exports.default = new MainController();
