"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const lodash_1 = require("lodash");
const PluginManager_1 = require("../../core/pluginmanager/PluginManager");
const property_1 = require("../../core/property");
const Mask_1 = require("../Mask");
const NotificationController_1 = require("./NotificationController");
const log = Logger_1.default.getLogger("ProcessController");
class ProcessController {
    async init() {
        this.dbProvider = await property_1.default.getProviders();
    }
    async getWsUsers(data) {
        return {
            users: NotificationController_1.default.getIdUsers(data.nameProvider),
        };
    }
    async reloadProvider(data) {
        const provider = PluginManager_1.default.getGateProvider(data.name);
        if (provider) {
            log.info(`Start init provider ${data.name}`);
            Mask_1.default.mask(data.session)
                .then(() => provider.init(true).then(() => {
                log.info(`End init provider ${data.name}`);
                return Mask_1.default.unmask(data.session);
            }, (err) => {
                log.error(err);
                return Mask_1.default.unmask(data.session);
            }))
                .then(lodash_1.noop);
        }
    }
    async reloadAllProvider(data) {
        const rows = [];
        log.info("Start init provider all");
        Mask_1.default.mask(data.session)
            .then(() => {
            PluginManager_1.default.getGateProviders().forEach((provider) => {
                rows.push(provider.init(true));
            });
            return Promise.all(rows).then(() => {
                log.info("End init provider all");
                return Mask_1.default.unmask(data.session);
            }, (err) => {
                log.error(err);
                return Mask_1.default.unmask(data.session);
            });
        })
            .then(lodash_1.noop);
    }
    async reloadContext(data) {
        const config = PluginManager_1.default.getGateContext(data.name);
        if (config) {
            log.info(`Start init config ${data.name}`);
            Mask_1.default.mask(data.session)
                .then(() => config.init(true).then(() => {
                log.info(`End init config ${data.name}`);
                return Mask_1.default.unmask(data.session);
            }, (err) => {
                log.error(err);
                return Mask_1.default.unmask(data.session);
            }))
                .then(lodash_1.noop);
        }
    }
    async resetContextClass(data) {
        Mask_1.default.mask(data.session)
            .then(() => PluginManager_1.default.resetGateContextClass().then(() => {
            return Mask_1.default.unmask(data.session);
        }))
            .then(lodash_1.noop);
    }
    async resetProviderClass(data) {
        Mask_1.default.mask(data.session)
            .then(() => PluginManager_1.default.resetGateProviderClass().then(() => {
            return Mask_1.default.unmask(data.session);
        }))
            .then(lodash_1.noop);
    }
    async resetPluginClass(data) {
        Mask_1.default.mask(data.session)
            .then(() => PluginManager_1.default.resetGatePluginsClass().then(() => {
            return Mask_1.default.unmask(data.session);
        }))
            .then(lodash_1.noop);
    }
    async reloadAllContext(data) {
        const rows = [];
        log.info("Start init config all");
        Mask_1.default.mask(data.session)
            .then(() => {
            PluginManager_1.default.getGateContexts().forEach((config) => {
                rows.push(config.init(true));
            });
            return Promise.all(rows).then(() => {
                log.info("End init config all");
                return Mask_1.default.unmask(data.session);
            }, (err) => {
                log.error(err);
                return Mask_1.default.unmask(data.session);
            });
        })
            .then(lodash_1.noop);
    }
    async destroyProvider(data) {
        Mask_1.default.mask(data.session)
            .then(async () => {
            await PluginManager_1.default.removeGateProvider(data.name);
            return Mask_1.default.unmask(data.session);
        })
            .then(lodash_1.noop);
    }
    async destroyAllProvider(data) {
        Mask_1.default.mask(data.session)
            .then(async () => {
            await PluginManager_1.default.removeAllGateProvider();
            return Mask_1.default.unmask(data.session);
        })
            .then(lodash_1.noop);
    }
    async sendNotification(data) {
        NotificationController_1.default.sendNotification(data.ckUser, data.nameProvider, data.text);
    }
    async sendNotificationAll(data) {
        NotificationController_1.default.sendNotificationAll(data.text);
    }
    async updateUserInfo(data) {
        NotificationController_1.default.updateUserInfo(data.ckUser, data.nameProvider);
    }
    async setMask(data) {
        if (Mask_1.default.masked !== data.mask) {
            Mask_1.default.setMask(data.mask);
        }
    }
}
exports.default = new ProcessController();
