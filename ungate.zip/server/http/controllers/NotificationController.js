"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const crypto = require("crypto");
const lodash_1 = require("lodash");
const websocket = require("websocket");
const Property_1 = require("../../core/property/Property");
const GateSession_1 = require("../../core/session/GateSession");
const Mask_1 = require("../Mask");
const logger = Logger_1.default.getLogger("NotificationController");
const TIMEOUT = 30000;
class NotificationController {
    constructor() {
        this.notificationClient = {};
    }
    async init(httpServer) {
        this.wsServer = new websocket.server({
            httpServer,
        });
        this.wsServer.on("request", this.onRequest.bind(this));
        lodash_1.delay(() => this.checkConnection(), TIMEOUT);
        this.dbUsers = await Property_1.default.getUsers();
        Mask_1.default.on("change", this.changeMask, this);
    }
    changeMask(isMask) {
        setTimeout(() => {
            this.sendNotificationAll(JSON.stringify([
                {
                    data: {
                        action: isMask ? "block" : "unblock",
                        msg: isMask
                            ? "Проводятся технические работы. Пожалуйста, подождите"
                            : "Технические работы завершены, можете продолжать работу",
                    },
                    event: "mask",
                },
            ]));
        }, isMask ? 10 : 500);
    }
    onRequest(request) {
        if (!request.resourceURL.query || !request.resourceURL.query.session) {
            return;
        }
        const connection = request.accept("notification", request.origin);
        GateSession_1.default.loadSession(request.resourceURL.query.session)
            .then((session) => {
            if (session) {
                logger.info(`WS Connect ${JSON.stringify(session)}`);
                connection.sessionId = session.session;
                connection.session = session;
                const buf = Buffer.alloc(6);
                crypto.randomFillSync(buf);
                connection.uniqhash = buf.toString("hex");
                connection.on("close", () => {
                    const obj = this.notificationClient[`${session.ck_id}:${session.ck_d_provider}`];
                    delete obj[connection.uniqhash];
                });
                if (this.notificationClient[`${session.ck_id}:${session.ck_d_provider}`]) {
                    this.notificationClient[`${session.ck_id}:${session.ck_d_provider}`][connection.uniqhash] = connection;
                }
                else {
                    this.notificationClient[`${session.ck_id}:${session.ck_d_provider}`] = {
                        [connection.uniqhash]: connection,
                    };
                }
                return;
            }
            connection.close(4001, "Session not found, specified query requires authentication");
        })
            .catch((err) => logger.error(err));
    }
    getIdUsers(nameProvider) {
        const names = {};
        lodash_1.forEach(this.notificationClient || {}, (userObj) => {
            lodash_1.forEach(userObj || {}, (conn) => {
                if ((nameProvider &&
                    conn.session.ck_d_provider === nameProvider) ||
                    !nameProvider) {
                    names[conn.session.ck_id] = true;
                }
            });
        });
        return Object.keys(names);
    }
    sendNotification(idUser, nameProviderAuth, text) {
        lodash_1.forEach(this.notificationClient[`${idUser}:${nameProviderAuth}`] || {}, (conn) => conn.sendUTF(text));
    }
    sendNotificationAll(text) {
        lodash_1.forEach(this.notificationClient || {}, (userObj) => {
            lodash_1.forEach(userObj || {}, (conn) => conn.sendUTF(text));
        });
    }
    updateUserInfo(nameProvider, ckUser) {
        const allConn = Object.values(this.notificationClient || {}).reduce((arr, value) => [...arr, ...Object.values(value)], []);
        let sessions;
        if (ckUser && nameProvider) {
            sessions = allConn
                .filter((conn) => conn.session.ck_user === ckUser &&
                conn.session.ck_d_provider === nameProvider)
                .map((conn) => conn.sessionId);
        }
        else if (nameProvider) {
            sessions = allConn
                .filter((conn) => conn.session.ck_d_provider === nameProvider)
                .map((conn) => conn.sessionId);
        }
        else {
            sessions = allConn.map((conn) => conn.sessionId);
        }
        if (allConn.length) {
            GateSession_1.default.findSessions(sessions, false)
                .then((docs) => {
                const ckUsers = docs.map((doc) => `${doc.ck_id}:${doc.ck_d_provider}`);
                return this.dbUsers
                    .find({ ck_id: { $in: ckUsers } })
                    .then((users) => {
                    users.forEach((user) => {
                        Object.values(this.notificationClient[user.ck_id]).forEach((conn) => conn.sendUTF(JSON.stringify([
                            {
                                data: {
                                    ...user.data,
                                    session: conn
                                        .sessionId,
                                },
                                event: "reloaduser",
                            },
                        ])));
                    });
                });
            })
                .catch((err) => logger.error(err));
        }
    }
    checkConnection() {
        const allConn = Object.values(this.notificationClient || {}).reduce((arr, value) => [...arr, ...Object.values(value)], []);
        const sessions = allConn.map((conn) => conn.sessionId);
        if (allConn.length) {
            GateSession_1.default.findSessions(sessions, false)
                .then((docs) => {
                const getSession = docs.map((doc) => doc.ck_id);
                const disconectedSession = sessions.filter((session) => getSession.indexOf(session) === -1);
                disconectedSession.forEach((session) => {
                    allConn.forEach((conn) => {
                        if (conn.sessionId === session) {
                            conn.close(4001, "Session not found, specified query requires authentication");
                            const obj = this.notificationClient[`${conn.session.ck_id}:${conn.session.ck_d_provider}`];
                            delete obj[conn.uniqhash];
                        }
                    });
                });
            })
                .catch((err) => logger.error(err));
        }
        lodash_1.delay(() => this.checkConnection(), TIMEOUT);
    }
}
exports.default = new NotificationController();
