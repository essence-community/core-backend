"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Util_1 = require("@ungate/plugininf/lib/util/Util");
class PluginController {
    applyPluginInitQueryBefore(gateContext, plugins, query) {
        if (plugins.length) {
            let res = query;
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute beforeInitQueryPerform`);
                return plugin.plugin.beforeInitQueryPerform(gateContext, plugins[0].context, query);
            }), plugins[0].plugin.beforeInitQueryPerform(gateContext, plugins[0].context, query))
                .then((result) => Promise.resolve(Util_1.isEmpty(result) ? res : result));
        }
        return Promise.resolve(query);
    }
    applyPluginInitQueryAfter(gateContext, plugins, query) {
        if (plugins.length) {
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then(() => {
                gateContext.trace(`plugin ${plugin.plugin.name} execute afterInitQueryPerform`);
                return plugin.plugin.afterInitQueryPerform(gateContext, plugins[0].context, query);
            }), plugins[0].plugin.afterInitQueryPerform(gateContext, plugins[0].context, query))
                .then(() => Promise.resolve());
        }
        return Promise.resolve();
    }
    applyPluginQueryExecuteBefore(gateContext, plugins, query) {
        if (plugins.length) {
            let res = null;
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute beforeQueryExecutePerform`);
                return res
                    ? Promise.resolve(res)
                    : plugin.plugin.beforeQueryExecutePerform(gateContext, plugins[0].context, query);
            }), plugins[0].plugin.beforeQueryExecutePerform(gateContext, plugins[0].context, query))
                .then((result) => Promise.resolve(Util_1.isEmpty(result) ? res : result));
        }
        return Promise.resolve(null);
    }
    applyPluginBeforeSession(gateContext, plugins) {
        if (plugins.length) {
            let res = null;
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute beforeSession`);
                return res
                    ? Promise.resolve(res)
                    : plugin.plugin.beforeSession(gateContext, plugins[0].context);
            }), plugins[0].plugin.beforeSession(gateContext, plugins[0].context))
                .then((result) => Promise.resolve(Util_1.isEmpty(result) ? res : result));
        }
        return Promise.resolve(null);
    }
    applyPluginBeforeSaveSession(gateContext, plugins, data) {
        if (plugins.length) {
            let res = true;
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (res !== result) {
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute beforeSaveSession`);
                return res
                    ? plugin.plugin.beforeSaveSession(gateContext, plugins[0].context, data)
                    : Promise.resolve(res);
            }), plugins[0].plugin.beforeSaveSession(gateContext, plugins[0].context, data))
                .then((result) => Promise.resolve(Util_1.isEmpty(result) ? res : result));
        }
        return Promise.resolve(true);
    }
    applyPluginAfterQueryExecute(gateContext, plugins, resOrigin) {
        if (plugins.length) {
            let res = resOrigin;
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    if (res.data && result.data) {
                        res.data.on("error", (err) => result.data.emit("error", err));
                    }
                    else if (res.data) {
                        res.data.on("error", (err) => gateContext.warn(`${err.message}`, err));
                    }
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute afterQueryExecutePerform`);
                return plugin.plugin.afterQueryExecutePerform(gateContext, plugins[0].context, res);
            }), plugins[0].plugin.afterQueryExecutePerform(gateContext, plugins[0].context, res))
                .then((result) => Promise.resolve(Util_1.isEmpty(result) ? res : result));
        }
        return Promise.resolve(resOrigin);
    }
    applyPluginError(gateContext, plugins, err) {
        let res = err;
        if (plugins.length) {
            gateContext.trace(`Real error ${err.message}`, err);
            return plugins
                .slice(1)
                .reduce((prom, plugin) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    res = result;
                }
                gateContext.trace(`plugin ${plugin.plugin.name} execute handleError`);
                return plugin.plugin.handleError(gateContext, plugins[0].context, res);
            }), plugins[0].plugin.handleError(gateContext, plugins[0].context, res))
                .then(async (result) => (Util_1.isEmpty(result) ? res : result))
                .catch((breakErr) => Promise.resolve(breakErr));
        }
        return Promise.resolve(res);
    }
    applyBeforeSession(gateContext, providers = []) {
        if (providers.length) {
            return providers.slice(1).reduce((prom, provider) => prom.then((result) => {
                if (!Util_1.isEmpty(result)) {
                    return Promise.resolve(result);
                }
                gateContext.trace(`providerAuth ${provider.name} execute beforeSession`);
                return provider.beforeSession(gateContext, gateContext.sessionId);
            }), providers[0].beforeSession(gateContext, gateContext.sessionId));
        }
        return Promise.resolve();
    }
    applyAfterSession(gateContext, session, providers = []) {
        if (providers.length) {
            return providers.slice(1).reduce((prom, provider) => prom.then((result) => {
                gateContext.trace(`providerAuth ${provider.name} execute afterSession`);
                return provider.afterSession(gateContext, gateContext.sessionId, result);
            }), providers[0].afterSession(gateContext, gateContext.sessionId, session));
        }
        return Promise.resolve(session);
    }
}
exports.default = new PluginController();
