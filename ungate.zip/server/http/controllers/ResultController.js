"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/stream/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const accepts = require("accepts");
const js2xmlparser = require("js2xmlparser");
const JSONStream = require("JSONStream");
const lodash_1 = require("lodash");
const moment = require("moment");
const through = require("through");
const Constants_1 = require("../../core/Constants");
class ResultController {
    responseJson(gateContext, result) {
        const metaData = {
            ...result.metaData,
            ...gateContext.metaData,
        };
        const responseTime = (new Date().getTime() - gateContext.startTime) / 1000;
        let first = true;
        let total = 0;
        const ResultTransform = through(function (data) {
            let resultData = data;
            if (first) {
                resultData = `{"success":${result.type === "false" ? "false" : "true"},"data":${data}`;
                first = false;
            }
            total += 1;
            this.queue(resultData);
        }, function () {
            this.queue(`,"metaData": ${JSON.stringify({
                ...metaData,
                responseTime,
                total: total - 1,
            })}}`);
            this.queue(null);
        });
        this.setHeader(gateContext, 200);
        Util_1.safeResponsePipe(Util_1.safePipe(result.data, [
            JSONStream.stringify("[", ",", "]"),
            ResultTransform,
        ]), gateContext.response);
    }
    responseXml(gateContext, result) {
        const pepareXml = js2xmlparser.parse("response", {
            "@": {
                xmlns: "ungate.xml.api",
                "xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            },
            success: true,
            data: {},
            metaData: {},
        }, {
            declaration: {
                encoding: "UTF-8",
                include: true,
                standalone: "yes",
                version: "1.0",
            },
            format: {
                pretty: false,
            },
        });
        const [startXml, before] = pepareXml.split("<data/>");
        let total = 0;
        let first = true;
        const self = this;
        const ResultTransform = through(function (data) {
            let xml = js2xmlparser.parse("data", Object.entries(data).reduce((obj, arr) => {
                const val = self.xsiType(arr[1]);
                if (val.type === "object") {
                    obj.param.push({
                        ...val.value,
                        "@": {
                            key: arr[0],
                            "xsi:type": val.type,
                        },
                    });
                }
                else {
                    obj.param.push({
                        "#": val.value,
                        "@": {
                            key: arr[0],
                            "xsi:type": val.type,
                        },
                    });
                }
                return obj;
            }, { param: [] }), {
                declaration: {
                    include: false,
                },
                format: {
                    pretty: false,
                },
            });
            total += 1;
            if (first) {
                xml = `${startXml}${xml}`;
                first = false;
            }
            this.queue(xml);
        }, function () {
            const metaData = js2xmlparser.parse("metaData", {
                total,
            }, {
                declaration: {
                    include: false,
                },
                format: {
                    pretty: false,
                },
            });
            this.queue(before.replace("<metaData/>", metaData));
            this.queue(null);
        });
        this.setHeader(gateContext, 200, {
            "Content-Type": Constants_1.default.XML_CONTENT_TYPE,
        });
        Util_1.safeResponsePipe(Util_1.safePipe(result.data, ResultTransform), gateContext.response);
    }
    responseAttachment(gateContext, result) {
        const rows = [];
        result.data.on("data", (chunk) => {
            rows.push(chunk);
        });
        result.data.on("end", () => {
            if (rows.length === 0 || rows.length > 1) {
                return this.responseCheck(gateContext, null, new ErrorException_1.default(ErrorGate_1.default.FILE_ROW_SIZE));
            }
            const data = rows[0];
            if (data[Constants_1.default.FILE_DATA_COLUMN]) {
                if (data[Constants_1.default.FILE_DATA_COLUMN].length > 2147483648 ||
                    data[Constants_1.default.FILE_DATA_COLUMN].length <= 0) {
                    return this.responseCheck(gateContext, null, new ErrorException_1.default(ErrorGate_1.default.FILE_SIZE));
                }
                let contentDisposition;
                if (gateContext.gateContextPlugin.attachmentType === "inline") {
                    contentDisposition = "inline";
                }
                else {
                    contentDisposition = `attachment; filename="${encodeURI(data[Constants_1.default.FILE_NAME_COLUMN])}"`;
                }
                this.setHeader(gateContext, 200, {
                    "Content-Disposition": contentDisposition,
                    "Content-Length": data[Constants_1.default.FILE_DATA_COLUMN].length,
                    "Content-Type": data[Constants_1.default.FILE_MIME_COLUMN] ||
                        Constants_1.default.FILE_CONTENT_TYPE,
                });
                gateContext.response.end(data[Constants_1.default.FILE_DATA_COLUMN]);
                if (gateContext.isDebugEnabled()) {
                    gateContext.debug(`Ответ: FileName: ${data[Constants_1.default.FILE_NAME_COLUMN]}, FileMimeType: ${data[Constants_1.default.FILE_MIME_COLUMN] ||
                        Constants_1.default.FILE_CONTENT_TYPE}`);
                }
            }
            else {
                const error = `Ошибка загрузки файла (${moment().format("DD.MM.YYYY HH:mm:ss")})`;
                this.setHeader(gateContext, 200, {
                    "Content-Disposition": `attachment; filename="${data[Constants_1.default.ERROR_FILE_NAME]}"`,
                    "Content-Length": Buffer.byteLength(error),
                    "Content-Type": Constants_1.default.ERROR_FILE_MIME,
                });
                gateContext.response.end(error);
            }
        });
    }
    responseFile(gateContext, result) {
        const rows = [];
        result.data.on("data", (chunk) => {
            rows.push(chunk);
        });
        result.data.on("end", () => {
            if (rows.length === 0 || rows.length > 1) {
                return this.responseCheck(gateContext, null, new ErrorException_1.default(ErrorGate_1.default.FILE_ROW_SIZE));
            }
            const data = rows[0];
            if (data[Constants_1.default.FILE_DATA_COLUMN] &&
                data[Constants_1.default.FILE_MIME_COLUMN] &&
                typeof data[Constants_1.default.FILE_MIME_COLUMN] === "string" &&
                data[Constants_1.default.FILE_NAME_COLUMN] &&
                typeof data[Constants_1.default.FILE_NAME_COLUMN] === "string") {
                if (data[Constants_1.default.FILE_DATA_COLUMN].length > 2147483648 ||
                    data[Constants_1.default.FILE_DATA_COLUMN].length <= 0) {
                    return this.responseCheck(gateContext, null, new ErrorException_1.default(ErrorGate_1.default.FILE_SIZE));
                }
                this.setHeader(gateContext, 200, {
                    "Content-Length": data[Constants_1.default.FILE_DATA_COLUMN].length,
                    "Content-Type": data[Constants_1.default.FILE_MIME_COLUMN],
                });
                gateContext.response.end(data[Constants_1.default.FILE_DATA_COLUMN]);
                if (gateContext.isDebugEnabled()) {
                    gateContext.debug(`Ответ: FileName: ${data[Constants_1.default.FILE_NAME_COLUMN]}, FileMimeType: ${data[Constants_1.default.FILE_MIME_COLUMN]}`);
                }
            }
            else {
                this.responseCheck(gateContext, null, new ErrorException_1.default(ErrorGate_1.default.INVALID_FILE_RESULT));
            }
        });
    }
    responseErrorJson(gateContext, result) {
        const endTime = new Date();
        const rows = [];
        result.data.on("data", (chunk) => {
            rows.push(chunk);
        });
        result.data.on("end", () => {
            const [error] = rows;
            error.err_id += ` ${moment(endTime).format("DD.MM.YYYY HH:mm:ss")}`;
            error.metaData.responseTime =
                (new Date().getTime() - gateContext.startTime) / 1000;
            const json = JSON.stringify(error);
            const headers = {
                "Content-Length": Buffer.byteLength(json),
            };
            this.setHeader(gateContext, 200, headers);
            gateContext.response.end(json);
            if (gateContext.isDebugEnabled()) {
                gateContext.debug(`Ответ: ${json}`);
            }
        });
    }
    responseErrorXml(gateContext, result) {
        const endTime = new Date();
        const rows = [];
        result.data.on("data", (chunk) => {
            rows.push(chunk);
        });
        result.data.on("end", () => {
            const [error] = rows;
            error.err_id += ` ${moment(endTime).format("DD.MM.YYYY HH:mm:ss")}`;
            error.metaData.responseTime =
                (new Date().getTime() - gateContext.startTime) / 1000;
            const xml = js2xmlparser.parse("response", {
                "@": {
                    xmlns: "ungate.xml.api",
                    "xmlns:xs": "http://www.w3.org/2001/XMLSchema",
                    "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
                },
                ...error,
            }, {
                declaration: {
                    encoding: "UTF-8",
                    include: true,
                    standalone: "yes",
                    version: "1.0",
                },
            });
            const headers = {
                "Content-Length": Buffer.byteLength(xml),
                "Content-Type": Constants_1.default.XML_CONTENT_TYPE,
            };
            this.setHeader(gateContext, 200, headers);
            gateContext.response.end(xml);
            if (gateContext.isDebugEnabled()) {
                gateContext.debug(`Ответ: ${xml}`);
            }
        });
    }
    async responseCheck(gateContext, res, err) {
        let result = res;
        if (gateContext.isResponded) {
            return;
        }
        if (result && result.type === "break") {
            gateContext.info(`${gateContext.request.method}(${gateContext.actionName},${gateContext.queryName}` +
                `,${gateContext.providerName}) time execute ${(new Date().getTime() -
                    gateContext.startTime) /
                    1000}`);
            return;
        }
        const accept = accepts(gateContext.request);
        if (err && err.break) {
            if (err.resultData) {
                result = err.resultData;
            }
        }
        else if (err) {
            if (!err.result) {
                gateContext.error(`${err.message}`, err);
            }
            result = {
                data: ResultStream_1.default(err
                    ? [
                        err.result ||
                            ErrorGate_1.default.compileErrorResult(-1, err.message || ""),
                    ]
                    : [ErrorGate_1.default.JSON_PARSE]),
                type: "error",
            };
        }
        try {
            result = await gateContext.gateContextPlugin.handleResult(gateContext, result);
        }
        catch (errContext) {
            if (errContext && errContext.break) {
                if (errContext.resultData) {
                    result = errContext.resultData;
                }
            }
            else if (errContext) {
                if (!errContext.result) {
                    gateContext.error(`${errContext.message}`, errContext);
                }
                result = {
                    data: ResultStream_1.default(err
                        ? [
                            errContext.result ||
                                ErrorGate_1.default.compileErrorResult(-1, errContext.message || ""),
                        ]
                        : [ErrorGate_1.default.JSON_PARSE]),
                    type: "error",
                };
            }
        }
        return new Promise((resolve, reject) => {
            switch (result.type) {
                case "success":
                case "false": {
                    switch (accept.type(["json", "xml"])) {
                        case "json":
                            this.responseJson(gateContext, result);
                            break;
                        case "xml":
                            this.responseXml(gateContext, result);
                            break;
                        default:
                            this.responseJson(gateContext, result);
                            break;
                    }
                    break;
                }
                case "break":
                    break;
                case "attachment":
                    this.responseAttachment(gateContext, result);
                    break;
                case "file":
                    this.responseFile(gateContext, result);
                    break;
                case "error": {
                    switch (accept.type(["json", "xml"])) {
                        case "json":
                            this.responseErrorJson(gateContext, result);
                            break;
                        case "xml":
                            this.responseErrorXml(gateContext, result);
                            break;
                        default:
                            this.responseErrorJson(gateContext, result);
                            break;
                    }
                    break;
                }
                default:
                    gateContext.error(`Не поддерживаемый вид ответа ${result.type}`, err);
                    result = {
                        data: ResultStream_1.default([
                            ErrorGate_1.default.compileErrorResult(-1, "Unsupported response type"),
                        ]),
                        type: "error",
                    };
                    this.responseErrorJson(gateContext, result);
                    break;
            }
            if (result.data) {
                result.data.on("error", (errStream) => {
                    reject(errStream);
                });
                result.data.on("end", () => {
                    resolve();
                });
            }
            else {
                resolve();
            }
            return;
        });
    }
    xsiType(val) {
        const result = { type: "", value: null };
        if (lodash_1.isDate(val)) {
            result.type = "xs:dateTime";
            result.value = moment(val).format();
        }
        else if (lodash_1.isNumber(val)) {
            result.type = "xs:decimal";
            result.value = `${val}`;
        }
        else if (lodash_1.isBoolean(val)) {
            result.type = "xs:boolean";
            result.value = `${val}`;
        }
        else if (lodash_1.isArray(val)) {
            result.type = "object";
            result.value = val.reduce((obj, arr) => {
                const types = this.xsiType(arr);
                obj.param.push(types.value);
                return obj;
            }, { param: [] });
        }
        else if (lodash_1.isObject(val)) {
            result.type = "object";
            result.value = Object.entries(val).reduce((obj, arr) => {
                const types = this.xsiType(val[1]);
                if (types.type === "object") {
                    obj.param.push({
                        ...types.value,
                        "@": {
                            key: types[0],
                            "xsi:type": types.type,
                        },
                    });
                }
                else {
                    obj.param.push({
                        "#": types.value,
                        "@": {
                            key: arr[0],
                            "xsi:type": types.type,
                        },
                    });
                }
                return obj;
            }, { param: [] });
        }
        else {
            result.type = "xs:string";
            result.value = Util_2.isEmpty(val) ? "" : val;
        }
        return result;
    }
    setHeader(gateContext, code, extraHeaders = {}) {
        gateContext.response.writeHead(code, {
            "Content-Type": Constants_1.default.JSON_CONTENT_TYPE,
            ...extraHeaders,
            ...gateContext.extraHeaders,
        });
    }
}
exports.default = new ResultController();
