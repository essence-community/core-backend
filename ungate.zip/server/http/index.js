"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const cluster = require("cluster");
const Constants_1 = require("../core/Constants");
const logger = Logger_1.default.getLogger("Http");
function initNodeHttp() {
    const node = cluster.fork();
    node.on("message", (message) => {
        if (message.target === "cluster") {
            Object.values(cluster.workers).forEach((nodeCluster) => {
                if (nodeCluster) {
                    nodeCluster.send(message);
                }
            });
        }
        else if (message.target) {
            process.send(message);
        }
    });
}
if (cluster.isMaster) {
    process.on("message", (message) => {
        if (message.target === "cluster") {
            Object.values(cluster.workers).forEach((node) => {
                if (node) {
                    node.send(message);
                }
            });
        }
    });
    cluster.on("exit", (worker, code, signal) => {
        logger.warn("Worker die %s, code %s, signal %s", worker.process.pid, code, signal);
        initNodeHttp();
    });
    for (let i = 0; i < Constants_1.default.CLUSTER_NUM; i += 1) {
        initNodeHttp();
    }
}
else {
    Promise.resolve().then(() => require("./httpNode"));
}
