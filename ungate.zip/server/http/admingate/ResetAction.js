"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const Constants_1 = require("../../core/Constants");
async function resetAction(gateContext, column, command, target, serverColumn = "ck_main") {
    if (Util_1.isEmpty(gateContext.query.inParams.json)) {
        return Promise.reject(new ErrorException_1.default(-1, `Нет такого обработчика ${gateContext.queryName}`));
    }
    const json = JSON.parse(gateContext.query.inParams.json || "{}");
    const serverName = json.service[serverColumn] || json.data[serverColumn];
    const cvName = json.data[column];
    if (!serverName || serverName === Constants_1.default.GATE_NODE_NAME) {
        ProcessSender_1.sendProcess({
            command,
            data: {
                name: cvName,
                session: gateContext.session,
            },
            target,
        });
    }
    else {
        ProcessSender_1.sendProcess({
            command: "sendServerAdminCmd",
            data: {
                command,
                data: {
                    name: cvName,
                    session: gateContext.session,
                },
                server: serverName,
                target,
            },
            target: "clusterAdmin",
        });
    }
    return [
        {
            ck_id: json.data.ck_id,
            cv_error: null,
        },
    ];
}
exports.default = resetAction;
