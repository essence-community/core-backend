"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const AWS = require("aws-sdk");
const lodash_1 = require("lodash");
class RiakAction {
    constructor(params) {
        this.clients = {};
        this.gtgetriakbuckets = () => Promise.resolve(Object.keys(this.cctBuckets || {}).map((val) => ({ ck_id: val })));
        this.params = params;
        if (!Util_1.isEmpty(this.params.cctBuckets)) {
            this.cctBuckets = JSON.parse(this.params.cctBuckets);
            lodash_1.forEach(this.cctBuckets, (val, key) => {
                const ep = new AWS.Endpoint("http://s3.amazonaws.com");
                const credentials = new AWS.Credentials(val);
                const config = {
                    apiVersion: "2006-03-01",
                    credentials,
                    endpoint: ep,
                    httpOptions: {
                        proxy: this.params.cvRiakUrl,
                    },
                    region: "us-east-1",
                    s3DisableBodySigning: true,
                    s3ForcePathStyle: true,
                    signatureVersion: "v2",
                    sslEnabled: false,
                };
                this.clients[key] = new AWS.S3(new AWS.Config(config));
            });
        }
    }
    async loadRiakFiles(gateContext) {
        if (Util_1.isEmpty(gateContext.query.inParams.json)) {
            return Promise.reject(new ErrorException_1.default(ErrorGate_1.default.JSON_PARSE));
        }
        const json = JSON.parse(gateContext.query.inParams.json, (key, value) => {
            if (value === null) {
                return undefined;
            }
            return value;
        });
        const s3 = this.clients[json.filter.cv_bucket];
        const params = {
            Bucket: json.filter.cv_bucket,
        };
        return new Promise((resolve, reject) => {
            s3.listObjects(params, (err, data) => {
                if (err) {
                    return reject(err);
                }
                return resolve(data
                    ? data.Contents.map((obj) => {
                        return {
                            ...obj,
                            ck_id: obj.Key,
                            cv_bucket: json.filter.cv_bucket,
                        };
                    })
                        .sort(Util_1.sortFilesData(gateContext))
                        .filter(Util_1.filterFilesData(gateContext))
                    : []);
            });
        });
    }
    async loadRiakFileInfo(gateContext) {
        if (Util_1.isEmpty(gateContext.query.inParams.json)) {
            return Promise.reject(ErrorGate_1.default.JSON_PARSE);
        }
        const json = JSON.parse(gateContext.query.inParams.json, (key, value) => {
            if (value === null) {
                return undefined;
            }
            return value;
        });
        const s3 = this.clients[json.filter.cv_bucket];
        const params = {
            Bucket: json.filter.cv_bucket,
            Key: json.master.ck_id,
        };
        return new Promise((resolve, reject) => {
            s3.headObject(params, (err, data) => {
                if (err) {
                    return reject(err);
                }
                return resolve(data
                    ? Object.entries(data.Metadata)
                        .map((value) => ({
                        ck_id: value[0],
                        cv_value: value[0] === "filename"
                            ? decodeURI(value[1])
                            : value[1],
                    }))
                        .sort(Util_1.sortFilesData(gateContext))
                        .filter(Util_1.filterFilesData(gateContext))
                    : []);
            });
        });
    }
    async deleteRiakFile(gateContext, json) {
        const s3 = this.clients[json.data.cv_bucket];
        const params = {
            Bucket: json.data.cv_bucket,
            Key: json.data.ck_id,
        };
        return new Promise((resolve, reject) => {
            s3.deleteObject(params, (err) => {
                if (err) {
                    return reject(err);
                }
                return resolve([
                    {
                        ck_id: null,
                        cv_error: null,
                    },
                ]);
            });
        });
    }
    async downloadRiakFile(gateContext) {
        if (Util_1.isEmpty(gateContext.query.inParams.json)) {
            return Promise.reject(ErrorGate_1.default.JSON_PARSE);
        }
        const json = JSON.parse(gateContext.query.inParams.json, (key, value) => {
            if (value === null) {
                return undefined;
            }
            return value;
        });
        const s3 = this.clients[json.data.cv_bucket];
        const params = {
            Bucket: json.data.cv_bucket,
            Key: json.data.ck_id,
        };
        return new Promise((resolve, reject) => {
            s3.getObject(params, (err, data) => {
                if (err) {
                    return reject(err);
                }
                return resolve([
                    {
                        filedata: data.Body,
                        filename: data.Metadata.filename
                            ? decodeURI(data.Metadata.filename)
                            : json.data.ck_id,
                        filetype: data.ContentType,
                    },
                ]);
            });
        });
    }
}
exports.default = RiakAction;
