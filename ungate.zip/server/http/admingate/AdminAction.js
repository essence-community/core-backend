"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const uuidv4_1 = require("uuidv4");
const PluginManager_1 = require("../../core/pluginmanager/PluginManager");
const Property_1 = require("../../core/property/Property");
const ResetAction_1 = require("./ResetAction");
const RiakAction_1 = require("./RiakAction");
class AdminAction {
    constructor(name, params) {
        this.name = name;
        this.params = params;
        this.riakAction = new RiakAction_1.default(params);
    }
    async init() {
        this.dbUsers = await Property_1.default.getUsers();
        this.dbContexts = await Property_1.default.getContext();
        this.dbEvents = await Property_1.default.getEvents();
        this.dbSessions = await Property_1.default.getSessions();
        this.dbProviders = await Property_1.default.getProviders();
        this.dbSchedulers = await Property_1.default.getSchedulers();
        this.dbPlugins = await Property_1.default.getPlugins();
        this.dbQuerys = await Property_1.default.getQuery();
        this.dbServers = await Property_1.default.getServers();
    }
    get handlers() {
        return {
            gtresetdefaultconfig: (gateContext) => gateContext.gateContextPlugin.init(true).then(() => Promise.resolve([
                {
                    ck_id: undefined,
                    cv_error: null,
                },
            ])),
            gtrestartgate: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "restartCluster", "master", "ck_id"),
            gtrestartfullgate: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "restartAll", "master", "ck_id"),
            gtgetusers: (gateContext) => this.dbUsers.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                ...Object.entries(val.data).reduce((obj, arr) => ({
                    ...obj,
                    [`data_${arr[0]}`]: arr[1],
                }), {}),
                cv_actions: val.data && val.data.ca_actions
                    ? val.data.ca_actions.join(", ")
                    : "",
                cv_departments: val.data && val.data.ca_department
                    ? val.data.ca_department.join(", ")
                    : "",
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetsessions: (gateContext) => this.dbSessions.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                data: undefined,
                ...Object.entries(val.data).reduce((obj, arr) => ({
                    ...obj,
                    [`data.${arr[0]}`]: arr[1],
                }), {}),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetservers: (gateContext) => this.dbServers
                .find()
                .then((docs) => Promise.resolve(docs
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetconfproviders: (gateContext) => this.dbProviders.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                cv_params: this.ParamsToString(PluginManager_1.default.getGateProviderClass, val.ck_d_plugin, val.cct_params),
                cct_params: undefined,
                ck_d_plugin: val.ck_d_plugin.toLowerCase(),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetevent: (gateContext) => this.dbEvents.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                cv_params: this.ParamsToString(PluginManager_1.default.getGateEventsClass, val.ck_d_plugin, val.cct_params),
                cct_params: undefined,
                ck_d_plugin: val.ck_d_plugin.toLowerCase(),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetconfigs: (gateContext) => this.dbContexts.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                cv_params: this.ParamsToString(PluginManager_1.default.getGateContextClass, val.ck_d_plugin, val.cct_params),
                cct_params: undefined,
                ck_d_plugin: val.ck_d_plugin.toLowerCase(),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetconfplugins: (gateContext) => this.dbPlugins.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                cv_params: this.ParamsToString(PluginManager_1.default.getGatePluginsClass, val.ck_d_plugin, val.cct_params),
                cct_params: undefined,
                ck_d_plugin: val.ck_d_plugin.toLowerCase(),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetconfquery: (gateContext) => this.dbQuerys.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetschedulers: (gateContext) => this.dbSchedulers.find().then((docs) => Promise.resolve(docs
                .map((val) => ({
                ...val,
                cv_params: this.ParamsToString(PluginManager_1.default.getGateSchedulerClass, val.ck_d_plugin, val.cct_params),
                cct_params: undefined,
                ck_d_plugin: val.ck_d_plugin.toLowerCase(),
            }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext)))),
            gtgetpluginsclass: (gateContext) => Promise.resolve(PluginManager_1.default.getGateAllPluginsClass()
                .map((val) => ({ ck_id: val }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext))),
            gtgetprovidersclass: (gateContext) => Promise.resolve(PluginManager_1.default.getGateAllProvidersClass()
                .map((val) => ({ ck_id: val }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext))),
            gtgetconfigclass: (gateContext) => Promise.resolve(PluginManager_1.default.getGateAllContextClass()
                .map((val) => ({ ck_id: val }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext))),
            gtgetschedulerclass: (gateContext) => Promise.resolve(PluginManager_1.default.getGateAllSchedulersClass()
                .map((val) => ({ ck_id: val }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext))),
            gtgeteventclass: (gateContext) => Promise.resolve(PluginManager_1.default.getGateAllEventsClass()
                .map((val) => ({ ck_id: val }))
                .sort(Util_1.sortFilesData(gateContext))
                .filter(Util_1.filterFilesData(gateContext))),
            gtreloadpluginsclass: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "resetPluginClass", "cluster"),
            gtreloadprovidersclass: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "resetProviderClass", "cluster"),
            gtreloadconfigclass: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "resetContextClass", "cluster"),
            gtresetprovider: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadProvider", "cluster"),
            gtresetallprovider: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadAllProvider", "cluster"),
            gtresetconfig: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadContext", "cluster"),
            gtresetallconfig: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadAllContext", "cluster"),
            gtresetscheduler: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadScheduler", "schedulerNode"),
            gtresetallscheduler: (gateContext) => ResetAction_1.default(gateContext, "ck_id", "reloadAllScheduler", "schedulerNode"),
            gtgetriakbuckets: (...arg) => this.riakAction.gtgetriakbuckets.apply(this.riakAction, arg),
            gtgetriakfiles: (gateContext) => this.riakAction.loadRiakFiles(gateContext),
            gtgetriakfileinfo: (gateContext) => this.riakAction.loadRiakFileInfo(gateContext),
            gtdownloadriakfile: (gateContext) => this.riakAction.downloadRiakFile(gateContext),
            gtgetprovidersetting: (gateContext) => this.loadSetting(gateContext, "ck_id", PluginManager_1.default.getGateProviderClass, this.dbProviders),
            gtgetcontextsetting: (gateContext) => this.loadSetting(gateContext, "ck_id", PluginManager_1.default.getGateContextClass, this.dbContexts),
            gtgetpluginsetting: (gateContext) => this.loadSetting(gateContext, "ck_id", PluginManager_1.default.getGatePluginsClass, this.dbPlugins),
            gtgetschedulersetting: (gateContext) => this.loadSetting(gateContext, "ck_id", PluginManager_1.default.getGateSchedulerClass, this.dbSchedulers),
            gtgeteventsetting: (gateContext) => this.loadSetting(gateContext, "ck_id", PluginManager_1.default.getGateEventsClass, this.dbEvents),
            gtgetboolean: () => Promise.resolve([
                {
                    ck_id: true,
                },
                {
                    ck_id: false,
                },
            ]),
        };
    }
    ParamsToString(method, ckDPlugin, cctParams = {}) {
        const PClass = method(ckDPlugin.toLowerCase());
        let params = {};
        if (PClass && PClass.getParamsInfo) {
            params = PClass.getParamsInfo();
        }
        return Object.entries(cctParams).reduce((str, arr) => {
            if (params[arr[0]] && params[arr[0]].type === "password") {
                return `${str}${arr[0]}=***<br/>`;
            }
            return `${str}${arr[0]}=${lodash_1.isObject(arr[1]) ? JSON.stringify(arr[1]) : arr[1]}<br/>`;
        }, "");
    }
    loadSetting(gateContext, column, method, db) {
        if (Util_1.isEmpty(gateContext.query.inParams.json)) {
            return Promise.reject(new ErrorException_1.default(ErrorGate_1.default.JSON_PARSE));
        }
        const json = JSON.parse(gateContext.query.inParams.json, (key, value) => {
            if (value === null) {
                return undefined;
            }
            return value;
        });
        const PClass = method(json.master.ck_id);
        if (PClass && PClass.getParamsInfo) {
            const params = PClass.getParamsInfo();
            return (json.filter.cv_name
                ? db.findOne({
                    [column]: json.filter.cv_name,
                })
                : Promise.resolve({})).then((doc) => Promise.resolve([
                {
                    childs: Object.entries(params)
                        .map((arr) => this.createFields(gateContext, arr[0], json.filter.ck_page, (json.filter.childs || [])[0], arr[1], doc.cct_params))
                        .filter((val) => !Util_1.isEmpty(val)),
                    ck_page: json.filter.ck_page,
                    ck_page_object: uuidv4_1.uuid(),
                    column: "cct_params",
                    contentview: "vbox",
                    datatype: "array",
                    type: "FIELDSET",
                },
            ]));
        }
        return Promise.resolve([]);
    }
    createFields(gateContext, name, ckPage, child = {
        ck_page_object: uuidv4_1.uuid(),
    }, conf, params = {}) {
        switch (conf.type) {
            case "string": {
                return {
                    ck_page: ckPage,
                    ck_page_object: uuidv4_1.uuid(),
                    column: name,
                    cv_displayed: conf.name,
                    datatype: "text",
                    defaultvalue: lodash_1.isObject(params[name])
                        ? JSON.stringify(params[name])
                        : params[name] || conf.defaultValue,
                    info: conf.description,
                    required: conf.required ? "true" : "false",
                    type: "IFIELD",
                };
            }
            case "password": {
                return {
                    ck_page: ckPage,
                    ck_page_object: uuidv4_1.uuid(),
                    column: name,
                    cv_displayed: conf.name,
                    datatype: "password",
                    defaultvalue: Util_1.isEmpty(params[name])
                        ? ""
                        : "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8",
                    info: conf.description,
                    required: conf.required ? "true" : "false",
                    type: "IFIELD",
                };
            }
            case "integer": {
                return {
                    ck_page: ckPage,
                    ck_page_object: uuidv4_1.uuid(),
                    column: name,
                    cv_displayed: conf.name,
                    datatype: "integer",
                    defaultvalue: params[name] || conf.defaultValue,
                    info: conf.description,
                    required: conf.required ? "true" : "false",
                    type: "IFIELD",
                };
            }
            case "boolean": {
                if (Util_1.isEmpty(conf.defaultValue)) {
                    return {
                        autoload: "true",
                        ck_page: ckPage,
                        ck_page_object: child.ck_page_object,
                        ck_query: "GTGetBoolean",
                        cl_dataset: 1,
                        column: name,
                        cv_displayed: conf.name,
                        datatype: "combo",
                        defaultvalue: params[name] || conf.defaultValue,
                        displayfield: "ck_id",
                        info: conf.description,
                        required: conf.required ? "true" : "false",
                        type: "IFIELD",
                        valuefield: "ck_id",
                    };
                }
                return {
                    ck_page: ckPage,
                    ck_page_object: uuidv4_1.uuid(),
                    column: name,
                    cv_displayed: conf.name,
                    datatype: "checkbox",
                    defaultvalue: +(params[name] || conf.defaultValue),
                    info: conf.description,
                    required: conf.required ? "true" : "false",
                    type: "IFIELD",
                };
            }
            default: {
                gateContext.warn(name, conf.type);
                return undefined;
            }
        }
    }
}
exports.default = AdminAction;
