"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
const index_1 = require("../../core/property/index");
const RiakAction_1 = require("./RiakAction");
const actions = ["i", "u", "d"];
class AdminModify {
    constructor(name, params) {
        this.name = name;
        this.params = params;
        this.riakAction = new RiakAction_1.default(params);
    }
    async init() {
        this.dbUsers = await index_1.default.getUsers();
        this.dbContexts = await index_1.default.getContext();
        this.dbEvents = await index_1.default.getEvents();
        this.dbSessions = await index_1.default.getSessions();
        this.dbProviders = await index_1.default.getProviders();
        this.dbSchedulers = await index_1.default.getSchedulers();
        this.dbPlugins = await index_1.default.getPlugins();
        this.dbQuerys = await index_1.default.getQuery();
        this.dbServers = await index_1.default.getServers();
    }
    async checkModify(gateContext, query) {
        if (Util_1.isEmpty(query.inParams.json) || Util_1.isEmpty(query.queryStr)) {
            gateContext.warn(`Require params isEmpty:\njson: ${query.inParams.json}\nqueryStr: ${query.queryStr}`);
            throw new ErrorException_1.default(ErrorGate_1.default.JSON_PARSE);
        }
        const json = JSON.parse(query.inParams.json, (key, value) => {
            if (value === null) {
                return undefined;
            }
            return value;
        });
        if (this.riakAction[query.queryStr]) {
            return this.riakAction[query.queryStr](gateContext, json);
        }
        if (actions.includes(json.service.cv_action.toLowerCase())) {
            const localDb = this[query.queryStr];
            if (Util_1.isEmpty(localDb)) {
                gateContext.warn(`LocalDb not found: ${query.queryStr}`);
                throw new ErrorException_1.default(ErrorGate_1.default.JSON_PARSE);
            }
            if (query.queryStr === "dbPlugins" &&
                json.service.cv_action.toLowerCase() === "i") {
                json.data.ck_id = `${json.data.cv_name}:${json.data.ck_d_provider}`;
            }
            return this.callLocalDb(localDb, json);
        }
        return [];
    }
    callLocalDb(localDb, json) {
        if (json.data.cct_params) {
            const cctParams = json.data.cct_params;
            json.data.cct_params = {};
            (lodash_1.isArray(cctParams)
                ? cctParams
                : Object.values(cctParams || {})).forEach((val) => {
                if (!Util_1.isEmpty(val.value)) {
                    switch (val.datatype) {
                        case "text": {
                            json.data.cct_params[val.column] = val.value;
                            break;
                        }
                        case "integer": {
                            json.data.cct_params[val.column] = parseInt(val.value, 10);
                            break;
                        }
                        case "checkbox": {
                            json.data.cct_params[val.column] = !!val.value;
                            break;
                        }
                        case "combo": {
                            if (val.value === "true" || val.value === "false") {
                                json.data.cct_params[val.column] =
                                    val.value === "true";
                            }
                            else {
                                json.data.cct_params[val.column] = val.value;
                            }
                            break;
                        }
                        case "password": {
                            if (val.value !==
                                "5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8") {
                                json.data.cct_params[val.column] = val.value;
                            }
                            break;
                        }
                        default: {
                            json.data.cct_params[val.column] = val.value;
                            break;
                        }
                    }
                }
                else if (json.service.cv_action.toLowerCase() === "u") {
                    json.data.cct_params[val.column] = undefined;
                }
            });
        }
        switch (json.service.cv_action.toLowerCase()) {
            case "i": {
                return localDb.insert(json.data).then(async () => {
                    await localDb.compactDatafile();
                    return [
                        {
                            ck_id: json.data.ck_id,
                            cv_error: null,
                        },
                    ];
                });
            }
            case "u": {
                const ckId = json.data.ck_id;
                if (json.data.cct_params) {
                    lodash_1.forEach(json.data.cct_params, (val, key) => {
                        json.data[`cct_params.${key}`] = val;
                    });
                    delete json.data.cct_params;
                }
                return localDb
                    .update({
                    ck_id: ckId,
                }, {
                    $set: json.data,
                })
                    .then(async () => {
                    await localDb.compactDatafile();
                    return [
                        {
                            ck_id: ckId,
                            cv_error: null,
                        },
                    ];
                });
            }
            case "d": {
                return localDb
                    .remove({
                    ck_id: json.data.ck_id,
                })
                    .then(async () => {
                    await localDb.compactDatafile();
                    return [
                        {
                            ck_id: json.data.ck_id,
                            cv_error: null,
                        },
                    ];
                });
            }
            default:
                return Promise.reject(new ErrorException_1.default(-1, "Нет такого обработчика"));
        }
    }
}
exports.default = AdminModify;
