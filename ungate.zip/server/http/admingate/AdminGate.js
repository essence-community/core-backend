"use strict";
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const NullProvider_1 = require("@ungate/plugininf/lib/NullProvider");
const ResultStream_1 = require("@ungate/plugininf/lib/stream/ResultStream");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const Util_2 = require("@ungate/plugininf/lib/util/Util");
const AdminAction_1 = require("./AdminAction");
const AdminModify_1 = require("./AdminModify");
module.exports = class AdminGate extends NullProvider_1.default {
    constructor(name, params) {
        super(name, params);
        this.params = Util_2.initParams(AdminGate.getParamsInfo(), params);
        this.adminAction = new AdminAction_1.default(name, this.params);
        this.adminModify = new AdminModify_1.default(name, this.params);
    }
    static getParamsInfo() {
        return {
            ...NullProvider_1.default.getParamsInfo(),
            cctBuckets: {
                name: "Настройки хранилища",
                type: "string",
            },
            cvRiakUrl: {
                name: "Ссылка на riak",
                type: "string",
            },
        };
    }
    async processSql(context, query) {
        let result = [];
        if (context.queryName === "modify") {
            result = await this.adminModify.checkModify(context, query);
        }
        if (this.adminAction.handlers[context.queryName]) {
            result = await this.adminAction.handlers[context.queryName].call(this.adminAction, context, query);
        }
        return {
            stream: ResultStream_1.default(result),
        };
    }
    async processDml(context, query) {
        let result = [];
        if (context.queryName === "modify") {
            result = await this.adminModify.checkModify(context, query);
        }
        if (this.adminAction.handlers[context.queryName]) {
            result = await this.adminAction.handlers[context.queryName].call(this.adminAction, context, query);
        }
        return {
            stream: ResultStream_1.default(result),
        };
    }
    async initContext(context, query) {
        const res = await super.initContext(context, query);
        if (context.queryName !== "modify" &&
            Util_1.isEmpty(this.adminAction.handlers[context.queryName])) {
            throw new ErrorException_1.default(ErrorGate_1.default.NOTFOUND_QUERY);
        }
        if (context.queryName === "modify") {
            res.queryStr = res.modifyMethod;
        }
        return res;
    }
    async init(reload) {
        await this.adminAction.init();
        await this.adminModify.init();
    }
};
