"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const compression = require("compression");
const http = require("http");
const lodash_1 = require("lodash");
const Router = require("router");
const Constants_1 = require("../core/Constants");
const PluginManager_1 = require("../core/pluginmanager/PluginManager");
const Property_1 = require("../core/property/Property");
const RequestContext_1 = require("../core/request/RequestContext");
const GateSession_1 = require("../core/session/GateSession");
const BodyParse_1 = require("./BodyParse");
const GlobalController_1 = require("./controllers/GlobalController");
const MainController_1 = require("./controllers/MainController");
const NotificationController_1 = require("./controllers/NotificationController");
const ProcessController_1 = require("./controllers/ProcessController");
const ResultController_1 = require("./controllers/ResultController");
const log = Logger_1.default.getLogger("HttpServer");
class HttpServer {
    async initRoute() {
        this.route = Router();
        this.route.use(compression());
        const contextDb = await Property_1.default.getContext();
        const contexts = await contextDb.find({});
        contexts.forEach((obj) => {
            const doc = obj;
            const gateContext = PluginManager_1.default.getGateContext(doc.ck_id);
            const route = Router({
                mergeParams: true,
            });
            this.route.use(doc.cv_path, route);
            route.use(BodyParse_1.default(gateContext));
            route.all("/", (req, res) => {
                MainController_1.default.execute(new RequestContext_1.default(req, res, gateContext)).then(lodash_1.noop, (err) => log.trace(err));
            });
        });
    }
    async start() {
        await GateSession_1.default.init();
        GlobalController_1.default();
        await PluginManager_1.default.initGate();
        await this.initRoute();
        await MainController_1.default.init();
        await ProcessController_1.default.init();
        ProcessSender_1.initProcess(ProcessController_1.default, "cluster");
        const HttpServer = http.createServer((req, res) => {
            this.route(req, res, (err) => {
                if (err) {
                    log.warn(err);
                }
                if (err && err.gateContext) {
                    ResultController_1.default.responseCheck(new RequestContext_1.default(req, res, err.gateContext), null, err);
                    return;
                }
                const error = JSON.stringify({
                    err_code: 404,
                    err_text: `\`${req.url}\` is not an implemented route`,
                    metaData: { responseTime: 0.0 },
                    success: false,
                });
                res.writeHead(404, {
                    "Content-Length": Buffer.byteLength(error),
                    "Content-Type": Constants_1.default.JSON_CONTENT_TYPE,
                });
                res.end(error);
            });
        });
        HttpServer.timeout = 86400000;
        HttpServer.setTimeout(86400000);
        await NotificationController_1.default.init(HttpServer);
        HttpServer.listen(Constants_1.default.HTTP_PORT);
    }
}
const server = new HttpServer();
server.start().then(() => {
    ProcessSender_1.sendProcess({
        command: "startedCluster",
        data: {},
        target: "master",
    });
    log.info("HTTP server started!");
}, (err) => log.error(`HTTP Server fail start\n${err.message}`, err));
exports.default = server;
