"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const lodash_1 = require("lodash");
class BMask {
    constructor() {
        this.maskFlag = false;
        this._events = {};
    }
    get masked() {
        return this.maskFlag;
    }
    mask(session) {
        const old = this.maskFlag;
        return this.fireEvent("beforechange", true, old, session)
            .then(() => {
            this.maskFlag = true;
            if (!old) {
                return this.fireEvent("change", true, old, session);
            }
            return Promise.resolve();
        })
            .catch(() => Promise.resolve());
    }
    unmask(session) {
        const old = this.maskFlag;
        return this.fireEvent("beforechange", false, old, session)
            .then(() => {
            this.maskFlag = false;
            if (old) {
                return this.fireEvent("change", false, old, session);
            }
            return Promise.resolve();
        })
            .catch(() => Promise.resolve());
    }
    setMask(isMask, session) {
        const old = this.maskFlag;
        this.maskFlag = isMask;
        if (old !== isMask) {
            this.fireEvent("change", isMask, old, session).then(lodash_1.noop, lodash_1.noop);
        }
    }
    isEvent(event, callback) {
        if (arguments.length !== 2 || !lodash_1.isFunction(callback)) {
            return false;
        }
        if (this._events[event]) {
            return (this._events[event].filter((fn) => fn.callback === callback)
                .length > 0);
        }
        return false;
    }
    on(event, callback, scope = null) {
        if (arguments.length < 2 || !lodash_1.isFunction(callback)) {
            return;
        }
        if (this._events[event]) {
            this._events[event].push({
                callback,
                scope,
            });
        }
        else {
            this._events[event] = [
                {
                    callback,
                    scope,
                },
            ];
        }
    }
    un(event, callback) {
        if (arguments.length < 2 || !lodash_1.isFunction(callback)) {
            return;
        }
        if (this._events[event]) {
            this._events[event] = this._events[event].filter((fn) => fn.callback !== callback);
        }
    }
    fireEvent(event, ...arg) {
        if (this._events[event]) {
            return this._events[event].reduce((obj, val) => obj.then(async () => {
                const result = val.callback.call(val.scope, ...arg);
                if (lodash_1.isObject(result) &&
                    result.constructor.name === "Promise") {
                    return result;
                }
                return result === false
                    ? Promise.reject()
                    : Promise.resolve();
            }), Promise.resolve());
        }
        return Promise.resolve();
    }
}
const Mask = new BMask();
global.maskgate = Mask;
exports.default = Mask;
