"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const pluginmanager_1 = require("../core/pluginmanager");
const property_1 = require("../core/property");
const ProcessController_1 = require("./controllers/ProcessController");
const logger = Logger_1.default.getLogger("EventsNode");
class EventsNode {
    async start() {
        const dbEvents = await property_1.default.getEvents();
        await ProcessController_1.default.init();
        ProcessSender_1.initProcess(ProcessController_1.default, "eventNode");
        await pluginmanager_1.default.resetEventsClass();
        const confEvents = await dbEvents.find();
        return Promise.all(confEvents.map(async (conf) => {
            const pluginClass = pluginmanager_1.default.getGateEventsClass(conf.ck_d_plugin.toLowerCase());
            if (pluginClass) {
                const plugin = new pluginClass(conf.ck_id, conf.cct_params);
                return plugin.init().then(() => {
                    pluginmanager_1.default.setGateEvent(conf.ck_id, plugin);
                    return Promise.resolve();
                }, (err) => {
                    logger.error(`Not init event plugin ${conf.ck_id}\n${err.message}`, err);
                    return Promise.resolve();
                });
            }
            return;
        }));
    }
}
const eventNode = new EventsNode();
eventNode.start().then(() => {
    ProcessSender_1.sendProcess({
        command: "startedEventNode",
        data: {},
        target: "master",
    });
    logger.info("Events node started!");
}, (err) => logger.error(`Events node fail start\n${err.message}`, err));
exports.default = eventNode;
