"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const pluginmanager_1 = require("../../core/pluginmanager");
class ProcessController {
    async init() {
        return;
    }
    async eventNotification(data) {
        const plugin = pluginmanager_1.default.getGateEvent(data.name);
        if (plugin && plugin.eventNotification) {
            plugin.eventNotification(data.users);
        }
    }
}
exports.default = new ProcessController();
