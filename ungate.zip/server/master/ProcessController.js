"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ChildProcess = require("child_process");
const path = require("path");
const Constants_1 = require("../core/Constants");
const logger = Logger_1.default.getLogger("master");
const checkMessage = (nodes, name, id) => (message) => {
    if (logger.isDebugEnabled() &&
        message.target &&
        message.command !== "sendAllServerCallDb") {
        logger.debug(`Process receive nameNode: ${name} pid: ${id} message ${JSON.stringify(message)}`);
    }
    switch (message.target) {
        case "cluster":
            if (nodes.http && id !== nodes.http.pid) {
                nodes.http.send(message);
            }
            break;
        case "clusterAdmin":
            if (nodes.admin && id !== nodes.admin.pid) {
                nodes.admin.send(message);
            }
            break;
        case "eventNode":
            if (nodes.events && id !== nodes.events.pid) {
                nodes.events.send(message);
            }
            break;
        case "localDbNode":
            if (nodes.localDbNode && id !== nodes.localDbNode.pid) {
                nodes.localDbNode.send(message);
            }
            break;
        case "schedulerNode":
            if (nodes.schedulers && id !== nodes.schedulers.pid) {
                nodes.schedulers.send(message);
            }
            break;
        case "master": {
            if (ProcessController[message.command]) {
                ProcessController[message.command].call(ProcessController, message.data);
            }
            break;
        }
        default:
            break;
    }
};
function killNode(nodes, name) {
    const node = nodes[name];
    delete nodes[name];
    if (!node) {
        return Promise.resolve();
    }
    return new Promise((resolve) => {
        node.removeAllListeners("close");
        node.on("close", () => resolve());
        node.on("exit", () => resolve());
        node.kill("SIGKILL");
    });
}
function initNode(nodes, name, paths) {
    const node = ChildProcess.fork(paths);
    node.on("message", checkMessage(nodes, name, node.pid));
    node.on("close", () => {
        delete nodes[name];
        initNode(nodes, name, paths);
    });
    nodes[name] = node;
}
class BuilderProcessController {
    constructor() {
        this.isClusterStarted = false;
        this.nodes = {};
    }
    init() {
        if (Constants_1.default.LOCAL_DB === "nedb") {
            initNode(this.nodes, "localDbNode", path.join(Constants_1.default.HOME_DIR, "localDbNode", "index.js"));
        }
        else {
            initNode(this.nodes, "http", path.join(Constants_1.default.HOME_DIR, "http", "index.js"));
        }
    }
    startedLocalDbNode() {
        initNode(this.nodes, "http", path.join(Constants_1.default.HOME_DIR, "http", "index.js"));
    }
    startedCluster() {
        if (!this.isClusterStarted) {
            this.isClusterStarted = true;
            initNode(this.nodes, "events", path.join(Constants_1.default.HOME_DIR, "events", "index.js"));
            initNode(this.nodes, "schedulers", path.join(Constants_1.default.HOME_DIR, "schedulers", "index.js"));
            initNode(this.nodes, "admin", path.join(Constants_1.default.HOME_DIR, "admin", "index.js"));
        }
    }
    startedEventNode() {
        return;
    }
    startedSchedulerNode() {
        return;
    }
    restartCluster() {
        this.isClusterStarted = false;
        const killNodes = [
            killNode(this.nodes, "events"),
            killNode(this.nodes, "schedulers"),
            killNode(this.nodes, "admin"),
            killNode(this.nodes, "http"),
        ];
        Promise.all(killNodes).then(() => {
            setTimeout(() => this.startedLocalDbNode(), 500);
        });
    }
    restartAll() {
        this.isClusterStarted = false;
        const killNodes = [
            killNode(this.nodes, "localDbNode"),
            killNode(this.nodes, "events"),
            killNode(this.nodes, "schedulers"),
            killNode(this.nodes, "admin"),
            killNode(this.nodes, "http"),
        ];
        Promise.all(killNodes).then(() => {
            setTimeout(() => this.init(), 500);
        });
    }
}
const ProcessController = new BuilderProcessController();
exports.default = ProcessController;
