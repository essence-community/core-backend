"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const fs = require("fs");
const https = require("https");
const MSG = require("msgpack-lite");
const websocket = require("websocket");
const Constants_1 = require("../../core/Constants");
const Property_1 = require("../../core/property/Property");
const logger = Logger_1.default.getLogger("AdminEventController");
const TIMEOUT_CONNECT = 15000;
function sendAllDate(conn, db) {
    return db.find().then(async (docs) => {
        conn.sendBytes(MSG.encode({
            data: {
                action: "insert",
                args: [docs],
                isTemp: db.isTemp,
                name: db.dbname,
            },
            event: "callDb",
        }));
    });
}
class AdminEventController {
    constructor() {
        this.serversSend = {};
        this.serversReceive = {};
    }
    async init() {
        if (!(fs.existsSync(Constants_1.default.GATE_ADMIN_CLUSTER_KEY) &&
            fs.existsSync(Constants_1.default.GATE_ADMIN_CLUSTER_CERT) &&
            fs.existsSync(Constants_1.default.GATE_ADMIN_CLUSTER_CA))) {
            throw new Error(`Not found ${Constants_1.default.GATE_ADMIN_CLUSTER_KEY} ${Constants_1.default.GATE_ADMIN_CLUSTER_CERT} ${Constants_1.default.GATE_ADMIN_CLUSTER_CA}`);
        }
        this.key = fs.readFileSync(Constants_1.default.GATE_ADMIN_CLUSTER_KEY, {
            encoding: "UTF-8",
            flag: "r",
        });
        this.cert = fs.readFileSync(Constants_1.default.GATE_ADMIN_CLUSTER_CERT, {
            encoding: "UTF-8",
            flag: "r",
        });
        this.ca = fs.readFileSync(Constants_1.default.GATE_ADMIN_CLUSTER_CA, {
            encoding: "UTF-8",
            flag: "r",
        });
        await new Promise((resolve, reject) => {
            const server = https.createServer({
                ca: this.ca,
                cert: this.cert,
                key: this.key,
                requestCert: true,
            }, (req, res) => {
                const error = JSON.stringify({
                    err_code: 404,
                    err_text: `\`${req.url}\` is not an implemented route`,
                    metaData: { responseTime: 0.0 },
                    success: false,
                });
                res.writeHead(404, {
                    "Content-Length": Buffer.byteLength(error),
                    "Content-Type": Constants_1.default.JSON_CONTENT_TYPE,
                });
                res.end(error);
            });
            this.wsServer = new websocket.server({
                httpServer: server,
            });
            server.listen(Constants_1.default.GATE_ADMIN_CLUSTER_PORT, (err) => {
                if (err) {
                    return reject(err);
                }
                return resolve();
            });
            this.server = server;
        });
        this.wsServer.on("request", this.onRequest.bind(this));
        this.dbServers = await Property_1.default.getServers();
        const configs = await this.dbServers.find({
            ck_id: {
                $ne: Constants_1.default.GATE_NODE_NAME,
            },
        });
        configs.forEach((conf) => {
            this.onConnectServer(conf.ck_id, conf.cv_ip, conf.cn_port);
        });
    }
    loadProperty(conn) {
        const rows = [];
        rows.push(Property_1.default.getProviders().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getContext().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getPlugins().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getServers().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getSchedulers().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getEvents().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getSessions().then((db) => sendAllDate(conn, db)));
        rows.push(Property_1.default.getQuery().then((db) => sendAllDate(conn, db)));
        return Promise.all(rows);
    }
    async callDb(conn, data) {
        const db = await Property_1.getLocalDb(data.name, data.isTemp);
        if (db) {
            return db[data.action](...data.args);
        }
    }
    async sendServerCallDb(data) {
        const conn = this.serversSend[data.server];
        if (!conn) {
            return;
        }
        conn.sendBytes(MSG.encode({
            data: {
                action: data.action,
                args: data.args,
                isTemp: data.isTemp,
                name: data.name,
            },
            event: "callDb",
        }));
    }
    async sendAllServerCallDb(data) {
        const conns = Object.values(this.serversSend);
        if (conns.length === 0) {
            return;
        }
        conns.forEach((conn) => {
            conn.sendBytes(MSG.encode({
                data: {
                    action: data.action,
                    args: data.args,
                    isTemp: data.isTemp,
                    name: data.name,
                },
                event: "callDb",
            }));
        });
    }
    async sendServerAdminCmd(data) {
        const conn = this.serversSend[data.server];
        if (!conn) {
            return;
        }
        conn.sendBytes(MSG.encode({
            data: {
                command: data.command,
                data: data.data,
                target: data.target,
            },
            event: "callProcess",
        }));
    }
    async callProcess(conn, data) {
        ProcessSender_1.sendProcess({
            command: data.command,
            data: data.data,
            target: data.target,
        });
    }
    onRequest(request) {
        const name = request.resourceURL.query.server;
        const connection = request.accept("adminevents", request.origin);
        this.serversReceive[name] = connection;
        connection.on("error", (error) => {
            logger.warn(error.message, error);
            delete this.serversReceive[name];
        });
        connection.on("close", () => {
            delete this.serversReceive[name];
        });
        connection.on("message", async (message) => {
            if (message.type === "binary") {
                try {
                    const command = MSG.decode(message.binaryData);
                    await this[command.event](connection, command.data);
                }
                catch (err) {
                    logger.warn(`Cluster message: ${message.utf8Data}\nError: ${err.message}`, err);
                }
            }
        });
    }
    onConnectServer(name, ip, port = Constants_1.default.GATE_ADMIN_CLUSTER_PORT, first = true) {
        logger.info(`Connect to ${name} ${ip} ${port}`);
        const client = new websocket.client({
            tlsOptions: {
                ca: this.ca,
                cert: this.cert,
                checkServerIdentity: () => null,
                key: this.key,
            },
        });
        client.on("connectFailed", (error) => {
            logger.warn(error.message, error);
            setTimeout(() => this.onConnectServer(name, ip, port, false), TIMEOUT_CONNECT);
        });
        client.on("connect", (connection) => {
            logger.info(`Connected to ${name} ${ip} ${port}`);
            this.serversSend[name] = connection;
            connection.on("error", (error) => {
                logger.warn(error.message, error);
                delete this.serversSend[name];
                setTimeout(() => this.onConnectServer(name, ip, port, false), TIMEOUT_CONNECT);
            });
            connection.on("close", (code) => {
                delete this.serversSend[name];
                setTimeout(() => this.onConnectServer(name, ip, port, false), TIMEOUT_CONNECT);
            });
            if (first) {
                connection.sendBytes(MSG.encode({
                    data: {},
                    event: "loadProperty",
                }));
            }
        });
        client.connect(`wss://${ip}:${port}/?server=${Constants_1.default.GATE_NODE_NAME}`, "adminevents");
    }
}
exports.default = new AdminEventController();
