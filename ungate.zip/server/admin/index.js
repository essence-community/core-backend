"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const AdminEventController_1 = require("./controllers/AdminEventController");
const logger = Logger_1.default.getLogger("Admin");
ProcessSender_1.initProcess(AdminEventController_1.default, "clusterAdmin");
AdminEventController_1.default.init().then(() => logger.info("Init Admin Notification Server"), (err) => logger.warn(`Error init Admin Notification Server ${err.message}`, err));
