"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ProcessController_1 = require("./master/ProcessController");
ProcessController_1.default.init();
