"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Property_1 = require("./Property");
exports.default = Property_1.default;
