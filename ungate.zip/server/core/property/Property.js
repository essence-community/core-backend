"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const nedb = require("@ungate/nedb-multi");
const path = require("path");
const Constants_1 = require("../Constants");
const NeDBImpl_1 = require("../db/nedblocal/NeDBImpl");
let DataStore;
const LocalProperty = new Map();
const TempTable = new Map();
async function getLocalDb(name, isTemp) {
    if (typeof isTemp === "undefined" &&
        LocalProperty.has(name) &&
        TempTable.has(name)) {
        throw new Error(`A lot of db: ${name}`);
    }
    if (typeof isTemp !== "undefined") {
        return loadProperty(name, isTemp);
    }
    return TempTable.get(name) || LocalProperty.get(name);
}
exports.getLocalDb = getLocalDb;
function loadProperty(name, isTemp = false) {
    return new Promise(async (resolve, reject) => {
        if (LocalProperty.has(name) || TempTable.has(name)) {
            return resolve(isTemp ? TempTable.get(name) : LocalProperty.get(name));
        }
        if (Constants_1.default.LOCAL_DB === "nedb") {
            if (!DataStore) {
                DataStore = nedb.NeDbProxy(Constants_1.default.NEDB_MULTI_PORT, Constants_1.default.NEDB_MULTI_HOST);
            }
            const db = new DataStore({
                filename: isTemp
                    ? path.join(Constants_1.default.NEDB_TEMP_DB, `${name}.yaml`)
                    : path.join(Constants_1.default.PROPERTY_DIR, `${name}.toml`),
                indexs: [{ fieldName: "ck_id", unique: true }],
                nameDb: name,
                tempDb: isTemp,
            });
            db.loadDatabase((err) => {
                if (err) {
                    err.message = `Ошибка инициализации ${name}\n${err.message}`;
                    return reject(err);
                }
                db.persistence.setAutocompactionInterval(5000);
                const localDb = new NeDBImpl_1.NeDBImpl(name, db, isTemp);
                if (isTemp) {
                    TempTable.set(name, localDb);
                    return resolve(localDb);
                }
                LocalProperty.set(name, localDb);
                resolve(localDb);
            });
        }
    });
}
class BuildProperty {
    getConfig() {
        return loadProperty("t_config");
    }
    getContext() {
        return loadProperty("t_context");
    }
    getProviders() {
        return loadProperty("t_providers");
    }
    getPlugins() {
        return loadProperty("t_plugins");
    }
    getQuery() {
        return loadProperty("t_query");
    }
    getServers() {
        return loadProperty("t_servers");
    }
    getEvents() {
        return loadProperty("t_events");
    }
    getSchedulers() {
        return loadProperty("t_schedulers");
    }
    getCache() {
        return loadProperty("tt_cache", true);
    }
    getUsers() {
        return loadProperty("tt_users", true);
    }
    getSessions() {
        return loadProperty("tt_sessions", true);
    }
}
global.createTempTable = (name) => {
    return loadProperty(name, true);
};
const Property = new BuildProperty();
global.property = Property;
exports.default = Property;
