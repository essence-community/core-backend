"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const crypto = require("crypto");
const lodash_1 = require("lodash");
const Constants_1 = require("../Constants");
const log = Logger_1.default.getLogger("RequestContext");
function prePareMsg(context, str) {
    return str && str.length > context.gateContextPlugin.maxLogParamLen
        ? `${str.substr(0, context.gateContextPlugin.maxLogParamLen)}...`
        : str;
}
class RequestContext {
    constructor(request, response, context) {
        this._isResponded = false;
        this._extraHeaders = {};
        this._metaData = {};
        this.isDebugEnabled = () => log.isDebugEnabled();
        this.isTraceEnabled = () => log.isTraceEnabled();
        this.isWarnEnabled = () => log.isWarnEnabled();
        this.isInfoEnabled = () => log.isInfoEnabled();
        const buf = Buffer.alloc(6);
        crypto.randomFillSync(buf);
        this._hash = buf.toString("hex");
        this._gateContextPlugin = context;
        this._startTime = new Date().getTime();
        this._gateVersion = Constants_1.default.GATE_VERSION;
        this._request = request;
        this._response = response;
        const writeHead = response.writeHead;
        let isWriteHead = false;
        response.writeHead = (...args) => {
            if (!isWriteHead) {
                writeHead.apply(response, args);
                isWriteHead = true;
            }
        };
        response.once("finish", () => {
            this.info(`${this.request.method}(${this.actionName},${this.queryName}` +
                `,${this.providerName}) time execute ${(new Date().getTime() - this.startTime) /
                    1000}`);
        });
        this._params = {
            ...request.params,
            ...request.preParams,
        };
        this._actionName = (this.params[Constants_1.default.ACTION_PARAM] || "").toLocaleLowerCase();
        delete this.params[Constants_1.default.ACTION_PARAM];
        this._queryName = (this.params[Constants_1.default.QUERYNAME_PARAM] || "").toLocaleLowerCase();
        delete this.params[Constants_1.default.QUERYNAME_PARAM];
        this._sessionId = this.params[Constants_1.default.SESSION_PARAM];
        delete this.params[Constants_1.default.SESSION_PARAM];
        this._providerName = (this.params[Constants_1.default.PROVIDER_PARAM] || "").toLocaleLowerCase();
        delete this.params[Constants_1.default.PROVIDER_PARAM];
        this._pluginName = (this.params[Constants_1.default.PLUGIN_PARAM] || "")
            .toLocaleLowerCase()
            .split(",");
        delete this.params[Constants_1.default.PLUGIN_PARAM];
        this.response.once("finish", () => {
            this.setIsResponded(true);
        });
    }
    get isResponded() {
        return this._isResponded;
    }
    set isResponded(res) {
        return;
    }
    get query() {
        return this._query;
    }
    set query(value) {
        return;
    }
    get provider() {
        return this._provider;
    }
    set provider(value) {
        return;
    }
    get gateVersion() {
        return this._gateVersion;
    }
    set gateVersion(value) {
        return;
    }
    get startTime() {
        return this._startTime;
    }
    set startTime(value) {
        return;
    }
    get hash() {
        return this._hash;
    }
    set hash(value) {
        return;
    }
    get session() {
        return this._session;
    }
    set session(value) {
        return;
    }
    get sessionId() {
        return this._sessionId;
    }
    set sessionId(value) {
        return;
    }
    get extraHeaders() {
        return this._extraHeaders;
    }
    set extraHeaders(value) {
        this._extraHeaders = {
            ...this._extraHeaders,
            ...value,
        };
    }
    get gateContextPlugin() {
        return this._gateContextPlugin;
    }
    set gateContextPlugin(value) {
        return;
    }
    get request() {
        return this._request;
    }
    set request(value) {
        return;
    }
    get response() {
        return this._response;
    }
    set response(value) {
        return;
    }
    get params() {
        return this._params;
    }
    set params(value) {
        this._params = {
            ...this._params,
            ...value,
        };
    }
    get actionName() {
        return this._actionName;
    }
    set actionName(value) {
        return;
    }
    get providerName() {
        return this._providerName;
    }
    set providerName(value) {
        return;
    }
    get queryName() {
        return this._queryName;
    }
    set queryName(value) {
        return;
    }
    get pluginName() {
        return this._pluginName;
    }
    set pluginName(value) {
        return;
    }
    get metaData() {
        return this._metaData;
    }
    set metaData(value) {
        this._metaData = {
            ...this._metaData,
            ...value,
        };
    }
    get connection() {
        return this._connection;
    }
    set connection(conn) {
        if (conn) {
            const commitAndRelease = async () => {
                this._response.removeListener("pipe", commitAndRelease);
                this._response.removeListener("finish", commitAndRelease);
                this._response.removeListener("close", commitAndRelease);
                try {
                    await conn.commit();
                    await conn.release();
                }
                catch (e) {
                    conn.rollbackAndRelease().then(lodash_1.noop, lodash_1.noop);
                    this.error(e);
                }
            };
            this._response.once("finish", commitAndRelease);
            this._response.once("pipe", commitAndRelease);
            this._response.once("close", commitAndRelease);
        }
        this._connection = conn;
    }
    setIsResponded(res) {
        this._isResponded = res;
    }
    setProvider(value) {
        this._provider = value;
    }
    setQuery(value) {
        this._query = value;
    }
    setSession(value) {
        this._session = value;
    }
    setActionName(value) {
        this._actionName = value;
    }
    setProviderName(value) {
        this._providerName = value;
    }
    setQueryName(value) {
        this._queryName = value;
    }
    setPluginName(value) {
        this._pluginName = value;
    }
    info(str, ...args) {
        log.info(`${this.hash} - ${prePareMsg(this, str)}`, ...args);
    }
    warn(str, ...args) {
        log.warn(`${this.hash} - ${prePareMsg(this, str)}`, ...args);
    }
    error(str, ...args) {
        log.error(`${this.hash} - ${prePareMsg(this, str)}`, ...args);
    }
    debug(str, ...args) {
        log.debug(`${this.hash} - ${prePareMsg(this, str)}`, ...args);
    }
    trace(str, ...args) {
        log.trace(`${this.hash} - ${prePareMsg(this, str)}`, ...args);
    }
}
exports.default = RequestContext;
