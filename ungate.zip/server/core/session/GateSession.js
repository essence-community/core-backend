"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const crypto = require("crypto");
const lodash_1 = require("lodash");
const moment = require("moment");
const uuidv4_1 = require("uuidv4");
const Constants_1 = require("../Constants");
const Property_1 = require("../property/Property");
const logger = Logger_1.default.getLogger("GateSession");
class GateSession {
    async init() {
        this.dbUsers = await Property_1.default.getUsers();
        this.dbSession = await Property_1.default.getSessions();
        this.dbCache = await Property_1.default.getCache();
    }
    sha1(buf) {
        return new Promise((resolve) => {
            const shasum = crypto.createHash("sha1");
            shasum.update(buf);
            return resolve(shasum.digest("hex"));
        });
    }
    sha256(buf) {
        return new Promise((resolve) => {
            const shasum = crypto.createHash("sha256");
            shasum.update(buf);
            return resolve(shasum.digest("hex"));
        });
    }
    createSession(idUser, nameProvider, data, sessionDuration = 60) {
        if (!idUser) {
            idUser = uuidv4_1.uuid();
            idUser = idUser.replace(/-/g, "");
        }
        return this.generateIdSession(idUser).then((sessionId) => {
            const param = {};
            const now = new Date();
            param.ck_id = sessionId;
            param.ck_user = idUser;
            param.ck_d_provider = nameProvider;
            param.cd_create = now;
            param.cn_session_duration = sessionDuration;
            param.cd_expire = new Date(now.getTime() + sessionDuration * 60000);
            param.data = data;
            return this.dbSession.insert(param).then(async () => ({
                ...data,
                session: sessionId,
            }));
        });
    }
    loadSession(sessionId, idUser, nameProvider) {
        const now = new Date();
        if (sessionId || (idUser && nameProvider)) {
            return this.dbSession
                .findOne({
                $and: [
                    ...(sessionId
                        ? [{ ck_id: sessionId }]
                        : [
                            { ck_user: idUser },
                            { ck_d_provider: nameProvider },
                        ]),
                    {
                        cd_expire: {
                            $gte: now,
                        },
                    },
                ],
            }, true)
                .then((doc) => {
                if (doc) {
                    const cdExpire = moment(doc.cd_expire);
                    if (cdExpire.isBefore(now)) {
                        return Promise.reject(new ErrorException_1.default(ErrorGate_1.default.REQUIRED_AUTH));
                    }
                    if (Util_1.dateBetween(now, new Date(cdExpire.toDate().getTime() -
                        (doc.cn_session_duration || 60) *
                            60000 *
                            0.2), cdExpire.toDate())) {
                        this.renewSession(doc.ck_id, doc.cn_session_duration);
                    }
                    return this.dbUsers
                        .findOne({
                        ck_id: `${doc.ck_user}:${doc.ck_d_provider}`,
                    }, true)
                        .then(async (user) => ({
                        ck_d_provider: doc.ck_d_provider,
                        ck_id: doc.ck_user,
                        data: (user && user.data) || doc.data,
                        session: sessionId,
                    }));
                }
                return Promise.resolve(null);
            });
        }
        return Promise.resolve(null);
    }
    logoutSession(sessionId) {
        return this.dbSession.update({
            ck_id: sessionId,
        }, {
            $set: { cd_expire: new Date() },
        });
    }
    findSessions(sessionId, isExpired = false) {
        const now = new Date();
        return this.dbSession.find({
            $and: [
                {
                    ck_id: lodash_1.isArray(sessionId)
                        ? {
                            $in: sessionId,
                        }
                        : sessionId,
                },
                {
                    cd_expire: {
                        [isExpired ? "$lt" : "$gte"]: now,
                    },
                },
            ],
        });
    }
    addUser(idUser, nameProvider, data) {
        return this.dbUsers.insert({
            ck_d_provider: nameProvider,
            ck_id: `${idUser}:${nameProvider}`,
            data,
        });
    }
    async getDataUser(idUser, nameProvider, isAccessErrorNotFound = false) {
        const data = await this.dbUsers.findOne({
            ck_id: `${idUser}:${nameProvider}`,
        }, true);
        if (data) {
            return data.data;
        }
        if (isAccessErrorNotFound) {
            throw new ErrorException_1.default(ErrorGate_1.default.AUTH_DENIED);
        }
        return null;
    }
    getUserDb() {
        return this.dbUsers;
    }
    async renewSession(sessionId, sessionDuration = 60) {
        const now = new Date();
        try {
            await this.dbSession.update({ ck_id: sessionId }, {
                $set: {
                    cd_expire: new Date(now.getTime() + sessionDuration * 60000),
                },
            });
        }
        catch (e) {
            logger.error("Ошибка обновление сессии", e);
        }
    }
    updateHashAuth() {
        return this.dbUsers.find().then((data) => {
            const users = [];
            const userActions = [];
            const userDepartments = [];
            data.forEach((row) => {
                const item = row.data || {};
                (item.ca_actions || []).forEach((action) => {
                    userActions.push({
                        ck_user: item.ck_id,
                        cn_action: action,
                    });
                });
                (item.ca_department || []).forEach((dep) => {
                    userDepartments.push({
                        ck_department: dep,
                        ck_user: item.ck_id,
                    });
                });
                delete item.ca_actions;
                delete item.ca_department;
                delete item.ck_dept;
                delete item.cv_timezone;
                users.push(item);
            });
            const usersJson = JSON.stringify(users);
            const userActionsJson = JSON.stringify(userActions);
            const userDepartmentsJson = JSON.stringify(userDepartments);
            return Promise.all([
                this.sha1(usersJson).then((sha) => Promise.resolve({
                    hash_user: sha,
                })),
                userActions.length
                    ? this.sha1(userActionsJson).then((sha) => Promise.resolve({
                        hash_user_action: sha,
                    }))
                    : Promise.resolve({
                        hash_user_action: null,
                    }),
                userDepartments.length
                    ? this.sha1(userDepartmentsJson).then((sha) => Promise.resolve({
                        hash_user_department: sha,
                    }))
                    : Promise.resolve({
                        hash_user_department: null,
                    }),
            ]).then((values) => this.dbCache.insert({
                ck_id: "hash_user",
                ...values[0],
                ...values[1],
                ...values[2],
            }));
        });
    }
    getHashSalt() {
        let hashSalt = Constants_1.default.HASH_SALT;
        if (!hashSalt) {
            const hashLocalSalt = Constants_1.default.APP_START_TIME.toString(16);
            const buf = Buffer.alloc(8);
            crypto.randomFillSync(buf).toString("hex");
            hashSalt =
                hashLocalSalt + crypto.randomFillSync(buf).toString("hex");
            Constants_1.default.HASH_SALT = hashSalt;
        }
        return hashSalt;
    }
    generateRandom() {
        return new Promise((resolve, reject) => {
            const buf = Buffer.alloc(10);
            crypto.randomFill(buf, (err, newBuf) => {
                if (err) {
                    return reject(err);
                }
                return resolve(newBuf.toString("hex"));
            });
        });
    }
    async generateIdSession(id) {
        return new Promise((resolve, reject) => {
            let buf = "";
            this.generateRandom()
                .then((rnd) => {
                buf += rnd;
                buf += this.getHashSalt();
                return this.sha256(buf);
            })
                .then((str) => {
                buf += str;
                return this.generateRandom();
            })
                .then((rnd) => {
                buf += rnd;
                buf += id;
                return this.generateRandom();
            })
                .then((rnd) => {
                buf += rnd;
                return this.generateRandom();
            })
                .then((rnd) => {
                buf += rnd;
                return this.generateRandom();
            })
                .then((rnd) => {
                buf += rnd;
                return this.sha256(buf);
            })
                .then((hash) => {
                buf = hash;
                const sessionId = buf.toUpperCase();
                logger.trace(`generated session id: ${sessionId}`);
                return resolve(sessionId);
            })
                .catch((err) => {
                logger.error(err);
                return reject(err);
            });
        });
    }
}
exports.default = new GateSession();
