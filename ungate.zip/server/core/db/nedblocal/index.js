"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const NeDBImpl_1 = require("./NeDBImpl");
exports.default = NeDBImpl_1.NeDBImpl;
