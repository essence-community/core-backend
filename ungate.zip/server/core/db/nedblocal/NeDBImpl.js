"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const Util_1 = require("@ungate/plugininf/lib/util/Util");
const lodash_1 = require("lodash");
class NeDBImpl {
    constructor(dbname, db, isTemp) {
        this.dbname = dbname;
        this.db = db;
        this.isTemp = isTemp;
    }
    find(object = {}) {
        return new Promise((resolve, reject) => {
            this.db.find(object, (err, docs) => {
                if (err) {
                    err.message += ` db ${this.dbname}`;
                    return reject(err);
                }
                return resolve(docs.map((item) => ({
                    ...item,
                    _id: undefined,
                })));
            });
        });
    }
    findOne(object, noErrorNotFound) {
        return new Promise((resolve, reject) => {
            this.db.findOne(object, (err, doc) => {
                let res = null;
                if (err) {
                    err.message += ` db ${this.dbname}`;
                    return reject(err);
                }
                else if (!doc && !noErrorNotFound) {
                    return reject(new Error(`Not Found Data in db ${this.dbname}`));
                }
                else if (doc) {
                    res = {
                        ...doc,
                        _id: undefined,
                    };
                }
                return resolve(res);
            });
        });
    }
    insert(object) {
        return new Promise((resolve, reject) => {
            if (lodash_1.isArray(object)) {
                Promise.all(object.map((item) => this.insert(item)))
                    .then(() => resolve())
                    .catch((err) => reject(err));
                return;
            }
            if (!Util_1.isEmpty(object.ck_id)) {
                object._id = object.ck_id;
            }
            if (!Util_1.isEmpty(object._id)) {
                this.update({
                    _id: object._id,
                }, {
                    $set: object,
                }, { multi: true, upsert: true, returnUpdatedDocs: false })
                    .then(() => resolve())
                    .catch((err) => reject(err));
            }
            else {
                ProcessSender_1.sendProcess({
                    command: "sendAllServerCallDb",
                    data: {
                        action: "insert",
                        args: [object],
                        isTemp: this.isTemp,
                        name: this.dbname,
                    },
                    target: "clusterAdmin",
                });
                this.db.insert(object, (err) => {
                    if (err) {
                        err.message += ` db ${this.dbname}`;
                        return reject(err);
                    }
                    return resolve();
                });
            }
        });
    }
    update(object1, object2, opts = { multi: false, upsert: false, returnUpdatedDocs: true }) {
        ProcessSender_1.sendProcess({
            command: "sendAllServerCallDb",
            data: {
                action: "update",
                args: [object1, object2, opts],
                isTemp: this.isTemp,
                name: this.dbname,
            },
            target: "clusterAdmin",
        });
        return new Promise((resolve, reject) => {
            this.db.update(object1, object2, opts, (err) => {
                if (err) {
                    err.message += ` db ${this.dbname}`;
                    return reject(err);
                }
                return resolve();
            });
        });
    }
    remove(object1, object2 = {}) {
        ProcessSender_1.sendProcess({
            command: "sendAllServerCallDb",
            data: {
                action: "remove",
                args: [object1, object2],
                isTemp: this.isTemp,
                name: this.dbname,
            },
            target: "clusterAdmin",
        });
        return new Promise((resolve, reject) => {
            this.db.remove(object1, object2, (err) => {
                if (err) {
                    err.message += ` db ${this.dbname}`;
                    return reject(err);
                }
                return resolve();
            });
        });
    }
    count(object = {}) {
        return new Promise((resolve, reject) => {
            this.db.count(object, (err, count) => {
                if (err) {
                    err.message += ` db ${this.dbname}`;
                    return reject(err);
                }
                return resolve(count);
            });
        });
    }
    compactDatafile() {
        return new Promise((resolve) => {
            this.db.persistence.compactDatafile();
            return resolve();
        });
    }
}
exports.NeDBImpl = NeDBImpl;
