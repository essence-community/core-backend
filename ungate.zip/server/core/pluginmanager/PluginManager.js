"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const ErrorException_1 = require("@ungate/plugininf/lib/errors/ErrorException");
const ErrorGate_1 = require("@ungate/plugininf/lib/errors/ErrorGate");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const fs = require("fs");
const Constants_1 = require("../Constants");
const Property_1 = require("../property/Property");
const logger = Logger_1.default.getLogger("PluginManager");
let GatePluginsClass = {};
let GateProviderClass = {};
let GateContextClass = {};
let GateSchedulersClass = {};
let GateEventsClass = {};
let GateProvider = {};
let GatePlugins = [];
let GateContext = {};
const GateEvents = {};
const GateSchedulers = {};
class PluginManager {
    initGate() {
        return Promise.all([
            this.resetGateContextClass(),
            this.resetGatePluginsClass(),
            this.resetGateProviderClass(),
            this.resetEventsClass(),
            this.resetSchedulersClass(),
        ]);
    }
    resetSchedulersClass() {
        GateSchedulersClass = {};
        const rows = [];
        if (!fs.existsSync(Constants_1.default.SCHEDULER_PLUGIN_DIR)) {
            logger.error(`Нет папки ${Constants_1.default.SCHEDULER_PLUGIN_DIR}`);
            return;
        }
        fs.readdirSync(Constants_1.default.SCHEDULER_PLUGIN_DIR).forEach((file) => {
            if (!fs.existsSync(`${Constants_1.default.SCHEDULER_PLUGIN_DIR}/${file}/index.js`)) {
                return;
            }
            const name = file.replace(".js", "").toLowerCase();
            rows.push(new Promise((resolve) => {
                const Class = require(`${Constants_1.default.SCHEDULER_PLUGIN_DIR}/${file}`);
                GateSchedulersClass[name] = Class;
                logger.info(`Найден класс scheduler ${name}`);
                return resolve();
            }));
        });
        return Promise.all(rows);
    }
    getGateAllSchedulersClass() {
        return Object.keys(GateSchedulersClass);
    }
    getGateSchedulerClass(key) {
        if (!GateSchedulersClass[key]) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        return GateSchedulersClass[key];
    }
    getGateScheduler(key) {
        return GateSchedulers[key];
    }
    setGateScheduler(key, value) {
        GateSchedulers[key] = value;
    }
    async removeGateScheduler(key) {
        await GateSchedulers[key].destroy();
        delete GateSchedulers[key];
        return true;
    }
    resetEventsClass() {
        GateEventsClass = {};
        const rows = [];
        if (!fs.existsSync(Constants_1.default.EVENT_PLUGIN_DIR)) {
            logger.error(`Нет папки ${Constants_1.default.EVENT_PLUGIN_DIR}`);
            return;
        }
        fs.readdirSync(Constants_1.default.EVENT_PLUGIN_DIR).forEach((file) => {
            if (!fs.existsSync(`${Constants_1.default.EVENT_PLUGIN_DIR}/${file}/index.js`)) {
                return;
            }
            const name = file.replace(".js", "").toLowerCase();
            rows.push(new Promise((resolve) => {
                const Class = require(`${Constants_1.default.EVENT_PLUGIN_DIR}/${file}`);
                GateEventsClass[name] = Class;
                logger.info(`Найден класс events ${name}`);
                return resolve();
            }));
        });
        return Promise.all(rows);
    }
    getGateAllEventsClass() {
        return Object.keys(GateEventsClass);
    }
    getGateEventsClass(key) {
        if (!GateEventsClass[key]) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        return GateEventsClass[key];
    }
    getGateEvent(key) {
        return GateEvents[key];
    }
    setGateEvent(key, value) {
        GateEvents[key] = value;
    }
    async removeGateEvent(key) {
        await GateEvents[key].destroy();
        delete GateEvents[key];
        return true;
    }
    async resetGateProviderClass() {
        GateProviderClass = {
            admingate: require("../../http/admingate/AdminGate"),
        };
        const rows = [];
        if (!fs.existsSync(Constants_1.default.PROVIDER_PLUGIN_DIR)) {
            logger.error(`Нет папки ${Constants_1.default.PROVIDER_PLUGIN_DIR}`);
            return;
        }
        fs.readdirSync(Constants_1.default.PROVIDER_PLUGIN_DIR).forEach((file) => {
            if (!fs.existsSync(`${Constants_1.default.PROVIDER_PLUGIN_DIR}/${file}/index.js`)) {
                return;
            }
            const name = file.replace(".js", "").toLowerCase();
            rows.push(new Promise((resolve) => {
                const Class = require(`${Constants_1.default.PROVIDER_PLUGIN_DIR}/${file}`);
                GateProviderClass[name] = Class;
                logger.info(`Найден класс провайдера ${name}`);
                return resolve();
            }));
        });
        await Promise.all(rows);
        GateProvider = {};
        await this.removeAllGateProvider();
        const db = await Property_1.default.getProviders();
        const docs = await db.find();
        const rowsInit = [];
        if (docs) {
            docs.forEach((doc) => {
                if (doc.cl_autoload) {
                    const PluginClass = GateProviderClass[doc.ck_d_plugin.toLowerCase()];
                    if (PluginClass) {
                        GateProvider[doc.ck_id] = new PluginClass(doc.ck_id, doc.cct_params);
                        rowsInit.push(GateProvider[doc.ck_id].init().then(() => {
                            logger.info(`Загружен провайдер ${doc.ck_id}`);
                            return Promise.resolve();
                        }, (err) => {
                            logger.error(err);
                            return Promise.resolve();
                        }));
                    }
                }
            });
        }
        return Promise.all(rowsInit);
    }
    getGateProviderClass(key) {
        if (!GateProviderClass[key]) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        return GateProviderClass[key];
    }
    getGateAllProvidersClass() {
        return Object.keys(GateProviderClass);
    }
    getGateProvider(key) {
        return GateProvider[key];
    }
    getGateAuthProviders() {
        return Object.values(GateProvider).filter((provider) => provider.isAuth);
    }
    getGateProviders() {
        return Object.values(GateProvider) || [];
    }
    setGateProvider(key, value) {
        GateProvider[key] = value;
    }
    async removeGateProvider(key) {
        await GateProvider[key].destroy();
        delete GateProvider[key];
        return true;
    }
    async removeAllGateProvider() {
        const rows = [];
        Object.values(GateProvider).forEach((pl) => {
            rows.push(pl.destroy());
        });
        await Promise.all(rows);
        GateProvider = {};
        return true;
    }
    async resetGatePluginsClass() {
        GatePluginsClass = {};
        const rows = [];
        if (!fs.existsSync(Constants_1.default.DATA_PLUGIN_DIR)) {
            logger.error(`Нет папки ${Constants_1.default.DATA_PLUGIN_DIR}`);
            return;
        }
        fs.readdirSync(Constants_1.default.DATA_PLUGIN_DIR).forEach((file) => {
            if (!fs.existsSync(`${Constants_1.default.DATA_PLUGIN_DIR}/${file}/index.js`)) {
                return;
            }
            const name = file.replace(".js", "").toLowerCase();
            rows.push(new Promise((resolve) => {
                const Class = require(`${Constants_1.default.DATA_PLUGIN_DIR}/${file}`);
                GatePluginsClass[name] = Class;
                logger.info(`Найден класс плагина ${name}`);
                return resolve();
            }));
        });
        await Promise.all(rows);
        const plugins = GatePlugins;
        GatePlugins = [];
        return Promise.all(plugins.map((conf) => conf.plugin.destroy()));
    }
    getGateAllPluginsClass() {
        return Object.keys(GatePluginsClass);
    }
    getGatePluginsClass(key) {
        if (!GatePluginsClass[key]) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        return GatePluginsClass[key];
    }
    getGateAllPlugins() {
        return GatePlugins.map((val) => val.plugin);
    }
    getGatePlugins(names, provider) {
        return GatePlugins.filter((val) => names.includes(val.cv_name) &&
            ["all", provider].includes(val.ck_d_provider)).map((obj) => obj.plugin);
    }
    getGatePlugin(name, provider) {
        return GatePlugins.filter((val) => name === val.cv_name &&
            ["all", provider].includes(val.ck_d_provider)).map((obj) => obj.plugin)[0];
    }
    setGatePlugins(obj) {
        GatePlugins.push(obj);
        GatePlugins.sort((val1, val2) => val1.cn_order - val2.cn_order);
    }
    async removeAllGatePlugins() {
        const rows = [];
        GatePlugins.forEach((pl) => {
            rows.push(pl.plugin.destroy());
        });
        await Promise.all(rows);
        GatePlugins = [];
        return true;
    }
    async resetGateContextClass() {
        GateContextClass = {};
        const rows = [];
        if (!fs.existsSync(Constants_1.default.CONTEXT_PLUGIN_DIR)) {
            logger.error(`Нет папки ${Constants_1.default.CONTEXT_PLUGIN_DIR}`);
            return;
        }
        fs.readdirSync(Constants_1.default.CONTEXT_PLUGIN_DIR).forEach((file) => {
            if (!fs.existsSync(`${Constants_1.default.CONTEXT_PLUGIN_DIR}/${file}/index.js`)) {
                return;
            }
            const name = file.replace(".js", "").toLowerCase();
            rows.push(new Promise((resolve) => {
                const Class = require(`${Constants_1.default.CONTEXT_PLUGIN_DIR}/${file}`);
                GateContextClass[name] = Class;
                logger.info(`Найден класс плагина контекста ${name}`);
                return resolve();
            }));
        });
        await Promise.all(rows);
        await this.removeAllGateContext();
        const tContext = await Property_1.default.getContext();
        const docs = await tContext.find({});
        const rowContext = [];
        if (docs) {
            docs.forEach((doc) => {
                const PluginClass = GateContextClass[doc.ck_d_plugin.toLowerCase()];
                if (PluginClass) {
                    GateContext[doc.ck_id] = new PluginClass(doc.ck_id, doc.cct_params);
                    rowContext.push(GateContext[doc.ck_id].init().then(() => {
                        logger.info(`Загружен контекст ${doc.ck_id}`);
                        return Promise.resolve();
                    }, (err) => {
                        logger.error(err);
                        return Promise.resolve();
                    }));
                }
            });
        }
        return Promise.all(rowContext);
    }
    getGateContextClass(key) {
        if (!GateContextClass[key]) {
            throw new ErrorException_1.default(ErrorGate_1.default.PLUGIN_NOT_FOUND);
        }
        return GateContextClass[key];
    }
    getGateAllContextClass() {
        return Object.keys(GateContextClass);
    }
    getGateContext(key) {
        return GateContext[key];
    }
    setGateContext(key, value) {
        GateContext[key] = value;
    }
    async removeGateContext(key) {
        await GateContext[key].destroy();
        delete GateContext[key];
        return true;
    }
    async removeAllGateContext() {
        const rows = [];
        Object.values(GateContext).forEach((pl) => {
            rows.push(pl.destroy());
        });
        await Promise.all(rows);
        GateContext = {};
        return true;
    }
    getGateContexts() {
        return Object.values(GateContext);
    }
}
exports.default = new PluginManager();
