"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const moment = require("moment-timezone");
const os = require("os");
const path = require("path");
const HOME_DIR = process.env.GATE_HOME_DIR || path.join(__dirname, "..");
global.homedir = HOME_DIR;
class Constants {
    constructor() {
        this.CLUSTER_NUM = process.env.GATE_CLUSTER_NUM
            ? parseInt(process.env.GATE_CLUSTER_NUM, 10)
            : os.cpus().length;
        this.HTTP_PORT = process.env.GATE_HTTP_PORT
            ? parseInt(process.env.GATE_HTTP_PORT, 10)
            : 8080;
        this.UPLOAD_DIR = process.env.GATE_UPLOAD_DIR || os.tmpdir();
        this.LOCAL_DB = (process.env.GATE_LOCAL_DB || "nedb").toLocaleLowerCase();
        this.NEDB_MULTI_PORT = process.env.NEDB_MULTI_PORT
            ? parseInt(process.env.NEDB_MULTI_PORT, 10)
            : 33030;
        this.NEDB_MULTI_HOST = process.env.NEDB_MULTI_HOST || "127.0.0.1";
        this.NEDB_TEMP_DB = process.env.NEDB_TEMP_DB || path.join(os.tmpdir(), "db");
        this.HOME_DIR = HOME_DIR;
        this.CONTEXT_PLUGIN_DIR = process.env.CONTEXT_PLUGIN_DIR ||
            path.join(HOME_DIR, "plugins", "contexts");
        this.PROVIDER_PLUGIN_DIR = process.env.PROVIDER_PLUGIN_DIR ||
            path.join(HOME_DIR, "plugins", "providers");
        this.DATA_PLUGIN_DIR = process.env.DATA_PLUGIN_DIR || path.join(HOME_DIR, "plugins", "datas");
        this.EVENT_PLUGIN_DIR = process.env.EVENT_PLUGIN_DIR ||
            path.join(HOME_DIR, "plugins", "events");
        this.SCHEDULER_PLUGIN_DIR = process.env.SCHEDULER_PLUGIN_DIR ||
            path.join(HOME_DIR, "plugins", "schedulers");
        this.PROPERTY_DIR = process.env.PROPERTY_DIR || path.join(HOME_DIR, "resources", "config");
        this.APP_START_TIME = new Date().getTime();
        this.GATE_ADMIN_CLUSTER_CERT = process.env.GATE_ADMIN_CLUSTER_CERT ||
            path.join(HOME_DIR, "cert", "server.crt");
        this.GATE_ADMIN_CLUSTER_KEY = process.env.GATE_ADMIN_CLUSTER_KEY ||
            path.join(HOME_DIR, "cert", "server.key");
        this.GATE_ADMIN_CLUSTER_CA = process.env.GATE_ADMIN_CLUSTER_CA
            ? process.env.GATE_ADMIN_CLUSTER_CA
            : path.join(HOME_DIR, "cert", "ca.crt");
        this.GATE_ADMIN_CLUSTER_PORT = process.env.GATE_ADMIN_CLUSTER_PORT
            ? parseInt(process.env.GATE_ADMIN_CLUSTER_PORT, 10)
            : 43090;
        this.GATE_NODE_NAME = process.env.GATE_NODE_NAME || os.hostname();
        this.JSON_DATE_FORMAT = "YYYY-MM-DDTHH:mm:ss";
        this.JSON_ENCODING = "utf-8";
        this.JSON_CONTENT_TYPE = "application/json; charset=utf-8";
        this.XML_CONTENT_TYPE = "application/xml; charset=utf-8";
        this.FILE_CONTENT_TYPE = "application/octet-stream";
        this.ACTION_PARAM = "action";
        this.QUERYNAME_PARAM = "query";
        this.SCHEMA_PARAM = "schema";
        this.SESSION_PARAM = "session";
        this.RESPONSE_CONTENT_TYPE = "answerContentType";
        this.RESPONSE_CONTENT_DISPOSITION = "answerContentDisposition";
        this.PASSWORD_PARAM_PREFIX = "pwd";
        this.PLUGIN_PARAM = "plugin";
        this.PROVIDER_PARAM = "provider";
        this.SESSION_PARAM_PREFIX = "sess_";
        this.OUT_PARAM_PREFIX = "out_";
        this.AUTH_NOT_AUTH_PARAM = "not_authorized";
        this.AUTH_NO_SESSION_PREFIX = "ns_";
        this.PLUGIN_OUTPUT_PARAM = "output";
        this.FILE_NAME_COLUMN = "filename";
        this.FILE_MIME_COLUMN = "filetype";
        this.FILE_DATA_COLUMN = "filedata";
        this.UPLOAD_FILE_NAME_SUFFIX = "_name";
        this.UPLOAD_FILE_MIMETYPE_SUFFIX = "_type";
        this.ERROR_FILE_NAME = "error.txt";
        this.ERROR_FILE_MIME = "text/plain";
        this.GATE_VERSION = process.env.GATE_VERSION || "1.25.0";
        this.HASH_SALT = "";
        this.QUERY_GETSESSIONDATA = "getsessiondata";
        this.QUERY_LOGOUT = "logout";
        this.RESERVED_PARAMS = [
            this.ACTION_PARAM,
            this.QUERYNAME_PARAM,
            this.SESSION_PARAM,
            this.RESPONSE_CONTENT_TYPE,
            this.RESPONSE_CONTENT_DISPOSITION,
            this.PROVIDER_PARAM,
        ];
    }
}
const constants = new Constants();
Date.prototype.toJSON = function () {
    return moment(this)
        .clone()
        .tz("Etc/GMT-3")
        .format(constants.JSON_DATE_FORMAT);
};
exports.default = constants;
