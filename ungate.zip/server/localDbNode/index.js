"use strict";
const nedb = require("@ungate/nedb-multi");
const Logger_1 = require("@ungate/plugininf/lib/Logger");
const ProcessSender_1 = require("@ungate/plugininf/lib/util/ProcessSender");
const axon = require("axon");
const fs = require("fs");
const Constants_1 = require("../core/Constants");
const logger = Logger_1.default.getLogger("LocalDbNode");
class BuilderLocalDbNode {
    start() {
        const repSocket = axon.socket("rep");
        const messagesHandler = nedb.HandlerNeDb.create(new Map());
        this.deleteFolderRecursive(Constants_1.default.NEDB_TEMP_DB);
        if (Constants_1.default.NEDB_MULTI_HOST) {
            if (Constants_1.default.NEDB_MULTI_HOST.startsWith("unix:") ||
                Constants_1.default.NEDB_MULTI_HOST.startsWith("tcp:")) {
                repSocket.bind(Constants_1.default.NEDB_MULTI_HOST);
            }
            else {
                repSocket.bind(Constants_1.default.NEDB_MULTI_PORT, Constants_1.default.NEDB_MULTI_HOST);
            }
        }
        else {
            repSocket.bind(Constants_1.default.NEDB_MULTI_PORT);
        }
        repSocket.on("message", messagesHandler);
        logger.info("LocalDbNode started");
        ProcessSender_1.sendProcess({
            command: "startedLocalDbNode",
            data: {},
            target: "master",
        });
    }
    deleteFolderRecursive(pathDir) {
        if (fs.existsSync(pathDir)) {
            fs.readdirSync(pathDir).forEach((file) => {
                const curPath = `${pathDir}/${file}`;
                if (fs.lstatSync(curPath).isDirectory()) {
                    this.deleteFolderRecursive(curPath);
                }
                else {
                    fs.unlinkSync(curPath);
                }
            });
            fs.rmdirSync(pathDir);
        }
    }
}
const LocalDbNode = new BuilderLocalDbNode();
LocalDbNode.start();
module.exports = LocalDbNode;
